package com.personal.launcher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Atajo de hardware: dos pulsaciones seguidas de «bajar volumen» apagan la asistente si está
 * encendida, o la encienden si está apagada (al encenderla solo escucha su nombre).
 *
 * Android no deja a una app leer botones físicos en cualquier pantalla salvo con un servicio de
 * accesibilidad; este solo mira esa tecla y no lee nada de la pantalla.
 */
class VolumeKeyService : AccessibilityService() {

    companion object {
        @Volatile var running = false

        fun isOn(c: Context): Boolean =
            (Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
                .contains(c.packageName + "/" + VolumeKeyService::class.java.name)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        running = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        // Solo la segunda pulsación se consume (para que no baje otro punto el volumen)
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            if (NovaToggle.onVolumeDown(this)) { swallowUp = true; return true }
        } else if (event.action == KeyEvent.ACTION_UP && swallowUp) {
            swallowUp = false
            return true
        }
        return false
    }

    private var swallowUp = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}

/** Alterna a la asistente. Lo usan el servicio de accesibilidad y el launcher. */
object NovaToggle {
    private const val WINDOW_MS = 450L
    private var last = 0L

    /** Llamar en cada pulsación de «bajar volumen». Devuelve true si completó el doble toque. */
    fun onVolumeDown(c: Context): Boolean {
        val now = SystemClock.uptimeMillis()
        if (last != 0L && now - last <= WINDOW_MS) {
            last = 0L
            toggle(c.applicationContext)
            return true
        }
        last = now
        return false
    }

    fun toggle(c: Context) {
        val name = BernadetteService.name(c)
        if (BernadetteService.enabled(c)) {
            Prefs.setBool(c, "bern_on", false)
            BernadetteService.stop(c)
            Prefs.say(c, "$name desactivada")
        } else {
            if (!BernadetteService.hasMic(c)) {
                Prefs.say(c, "Falta el permiso del micrófono. Actívalo en Ajustes › IA")
                return
            }
            // Queda marcada como activa; si Android no deja arrancar el micrófono desde segundo
            // plano, arranca sola en cuanto vuelvas al launcher.
            Prefs.setBool(c, "bern_on", true)
            BernadetteService.sync(c)
            Prefs.say(c, "$name activada. Di «$name» para hablarle")
        }
    }
}
