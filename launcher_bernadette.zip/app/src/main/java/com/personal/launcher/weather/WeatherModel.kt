package com.personal.launcher.weather

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.roundToInt

/** Familia visual de una condición meteorológica (decide icono, esfera y fondo). */
enum class WxKind { CLEAR, PARTLY, CLOUDY, FOG, RAIN, STORM, SNOW }

/** Ciudad o pueblo elegido por el usuario. */
class WxPlace(val name: String, val region: String, val country: String, val lat: Double, val lon: Double) {
    /** «Provincia, País» sin repetir el nombre. */
    fun subtitle(): String =
        listOf(region, country).filter { it.isNotBlank() && it != name }.joinToString(", ")

    fun toJson(): JSONObject = JSONObject()
        .put("name", name).put("region", region).put("country", country)
        .put("lat", lat).put("lon", lon)

    fun same(o: WxPlace?): Boolean = o != null && o.lat == lat && o.lon == lon

    companion object {
        fun fromJson(o: JSONObject): WxPlace =
            WxPlace(o.optString("name"), o.optString("region"), o.optString("country"), o.getDouble("lat"), o.getDouble("lon"))
    }
}

/** Condiciones actuales (Open-Meteo `current`). Los valores ausentes son NaN / -1. */
class WxNow(
    val temp: Double, val feels: Double, val humidity: Int,
    val wind: Double, val windDir: Int, val code: Int, val isDay: Boolean
)

/** Un día del pronóstico (Open-Meteo `daily` + humedad media calculada de `hourly`). */
class WxDay(
    val date: LocalDate, val code: Int,
    val tMax: Double, val tMin: Double, val feelMax: Double, val feelMin: Double,
    val rainProb: Int, val rainMm: Double,
    val wind: Double, val windDir: Int, val humidity: Int
)

/** Una hora del pronóstico, en la hora local del lugar (Open-Meteo `hourly`, zona `auto`). */
class WxHour(
    val date: LocalDate, val hour: Int,
    val temp: Double, val code: Int, val isDay: Boolean, val rainProb: Int
)

class WxReport(
    val place: WxPlace, val now: WxNow, val days: List<WxDay>, val fetchedAt: Long,
    /** Todas las horas disponibles, en orden. Vacía si la caché es antigua. */
    val hours: List<WxHour> = emptyList(),
    /** Fecha y hora local actuales del lugar (no las del teléfono). */
    val nowDate: LocalDate? = null, val nowHour: Int = -1
)

/** Códigos WMO → texto en español y familia visual. */
object Wmo {
    fun kind(code: Int): WxKind = when (code) {
        0, 1 -> WxKind.CLEAR
        2 -> WxKind.PARTLY
        3 -> WxKind.CLOUDY
        45, 48 -> WxKind.FOG
        51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> WxKind.RAIN
        71, 73, 75, 77, 85, 86 -> WxKind.SNOW
        95, 96, 99 -> WxKind.STORM
        else -> WxKind.CLOUDY
    }

    /** 1 = ligera, 2 = moderada, 3 = intensa (solo para dosificar gotas/copos). */
    fun intensity(code: Int): Int = when (code) {
        51, 56, 61, 66, 71, 77, 80, 85 -> 1
        53, 63, 73, 81 -> 2
        55, 57, 65, 67, 75, 82, 86, 95, 96, 99 -> 3
        else -> 2
    }

    fun text(code: Int): String = when (code) {
        0 -> "Despejado"
        1 -> "Mayormente despejado"
        2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45 -> "Niebla"
        48 -> "Niebla con escarcha"
        51 -> "Llovizna ligera"
        53 -> "Llovizna"
        55 -> "Llovizna intensa"
        56, 57 -> "Llovizna helada"
        61 -> "Lluvia ligera"
        63 -> "Lluvia moderada"
        65 -> "Lluvia intensa"
        66, 67 -> "Lluvia helada"
        71 -> "Nevada ligera"
        73 -> "Nevada moderada"
        75 -> "Nevada intensa"
        77 -> "Granizo fino"
        80 -> "Chubascos ligeros"
        81 -> "Chubascos"
        82 -> "Chubascos violentos"
        85 -> "Chubascos de nieve"
        86 -> "Fuertes chubascos de nieve"
        95 -> "Tormenta"
        96, 99 -> "Tormenta con granizo"
        else -> "Nublado"
    }
}

/** Formato y textos en español (sin depender del idioma del sistema). */
object WxText {
    private val DAY_S = arrayOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")
    private val DAY_L = arrayOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
    private val MONTH = arrayOf(
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    )
    private val DIR = arrayOf("N", "NE", "E", "SE", "S", "SO", "O", "NO")

    fun dayShort(d: LocalDate): String = DAY_S[d.dayOfWeek.value - 1]
    fun dayLong(d: LocalDate): String = DAY_L[d.dayOfWeek.value - 1]
    fun dateLong(d: LocalDate): String = "${d.dayOfMonth} de ${MONTH[d.monthValue - 1]}"

    fun dir(deg: Int): String =
        if (deg < 0) "" else DIR[(((deg % 360) + 22.5) / 45.0).toInt() % 8]

    fun temp(v: Double): String = if (v.isNaN()) "—" else v.roundToInt().toString()
    fun tempC(v: Double): String = if (v.isNaN()) "—" else "${v.roundToInt()} °C"
    fun deg(v: Double): String = if (v.isNaN()) "—" else "${v.roundToInt()}°"
    fun pct(v: Int): String = if (v < 0) "—" else "$v%"
    fun kmh(v: Double): String = if (v.isNaN()) "—" else "${v.roundToInt()} km/h"

    /** Descripción generada SOLO con los datos reales del día (sin texto inventado). */
    fun describe(d: WxDay, kind: WxKind): String {
        val sky = when (kind) {
            WxKind.CLEAR -> "Cielo despejado."
            WxKind.PARTLY -> "Mezcla de sol y nubes."
            WxKind.CLOUDY -> "Cielos cubiertos."
            WxKind.FOG -> "Niebla o neblina en la zona."
            WxKind.RAIN -> when {
                d.rainProb >= 70 -> "Lluvias muy probables."
                d.rainProb >= 40 -> "Lluvias probables."
                else -> "Posibles lluvias aisladas."
            }
            WxKind.STORM -> "Tormentas eléctricas previstas."
            WxKind.SNOW -> "Nevadas previstas."
        }
        val feel = when {
            d.tMax.isNaN() -> ""
            d.tMax < 10 -> " Ambiente frío."
            d.tMax < 18 -> " Ambiente fresco."
            d.tMax < 26 -> " Ambiente templado."
            d.tMax < 32 -> " Ambiente cálido."
            else -> " Calor intenso."
        }
        val sb = StringBuilder(sky).append(feel)
        if (d.rainMm >= 0.1) sb.append("\nPrecipitación acumulada: ").append("%.1f".format(java.util.Locale("es"), d.rainMm)).append(" mm.")
        if (!d.wind.isNaN()) {
            sb.append("\nViento ")
            val dr = dir(d.windDir)
            if (dr.isNotEmpty()) sb.append("del ").append(dr).append(' ')
            sb.append("hasta ").append(kmh(d.wind)).append('.')
        }
        return sb.toString()
    }
}

/** Convierte la respuesta cruda de Open-Meteo en un [WxReport]. Lanza excepción si el JSON no es válido. */
object WxParser {
    private fun JSONArray.dbl(i: Int): Double =
        if (i < length() && !isNull(i)) optDouble(i, Double.NaN) else Double.NaN

    private fun JSONArray.int(i: Int): Int =
        if (i < length() && !isNull(i)) optInt(i, -1) else -1

    fun parse(place: WxPlace, raw: String, at: Long): WxReport = parse(place, JSONObject(raw), at)

    fun parse(place: WxPlace, root: JSONObject, at: Long): WxReport {
        val cur = root.getJSONObject("current")
        val now = WxNow(
            temp = cur.optDouble("temperature_2m", Double.NaN),
            feels = cur.optDouble("apparent_temperature", Double.NaN),
            humidity = if (cur.has("relative_humidity_2m") && !cur.isNull("relative_humidity_2m")) cur.optInt("relative_humidity_2m", -1) else -1,
            wind = cur.optDouble("wind_speed_10m", Double.NaN),
            windDir = if (cur.has("wind_direction_10m") && !cur.isNull("wind_direction_10m")) cur.optInt("wind_direction_10m", -1) else -1,
            code = cur.optInt("weather_code", 3),
            isDay = cur.optInt("is_day", 1) == 1
        )

        // Humedad media de cada día a partir de los valores horarios.
        val hum = HashMap<String, IntArray>()   // fecha -> [suma, cantidad]
        val hourly = root.optJSONObject("hourly")
        val ht = hourly?.optJSONArray("time")
        val hh = hourly?.optJSONArray("relative_humidity_2m")
        if (ht != null && hh != null) {
            for (i in 0 until minOf(ht.length(), hh.length())) {
                if (hh.isNull(i)) continue
                val key = ht.optString(i).take(10)
                val a = hum.getOrPut(key) { IntArray(2) }
                a[0] += hh.optInt(i)
                a[1] += 1
            }
        }

        // Horas sueltas (temperatura, estado del cielo, lluvia) en la hora local del lugar.
        val hours = ArrayList<WxHour>()
        val hTemp = hourly?.optJSONArray("temperature_2m")
        val hCode = hourly?.optJSONArray("weather_code")
        val hDay = hourly?.optJSONArray("is_day")
        val hRain = hourly?.optJSONArray("precipitation_probability")
        if (ht != null && hTemp != null && hCode != null) {
            for (i in 0 until ht.length()) {
                val s = ht.optString(i)
                if (s.length < 13) continue
                val date = try { LocalDate.parse(s.substring(0, 10)) } catch (e: Exception) { continue }
                val hr = s.substring(11, 13).toIntOrNull() ?: continue
                val cd = hCode.int(i)
                hours.add(
                    WxHour(
                        date = date, hour = hr,
                        temp = hTemp.dbl(i),
                        code = if (cd < 0) 3 else cd,
                        isDay = if (hDay != null) hDay.int(i) != 0 else hr in 7..19,
                        rainProb = hRain?.int(i) ?: -1
                    )
                )
            }
        }
        val nowStr = cur.optString("time", "")
        var nowDate: LocalDate? = null
        var nowHour = -1
        if (nowStr.length >= 13) {
            nowDate = try { LocalDate.parse(nowStr.substring(0, 10)) } catch (e: Exception) { null }
            nowHour = nowStr.substring(11, 13).toIntOrNull() ?: -1
        }

        val d = root.getJSONObject("daily")
        val time = d.getJSONArray("time")
        val code = d.optJSONArray("weather_code") ?: JSONArray()
        val tmax = d.optJSONArray("temperature_2m_max") ?: JSONArray()
        val tmin = d.optJSONArray("temperature_2m_min") ?: JSONArray()
        val fmax = d.optJSONArray("apparent_temperature_max") ?: JSONArray()
        val fmin = d.optJSONArray("apparent_temperature_min") ?: JSONArray()
        val rp = d.optJSONArray("precipitation_probability_max") ?: JSONArray()
        val rs = d.optJSONArray("precipitation_sum") ?: JSONArray()
        val wm = d.optJSONArray("wind_speed_10m_max") ?: JSONArray()
        val wd = d.optJSONArray("wind_direction_10m_dominant") ?: JSONArray()

        val days = ArrayList<WxDay>()
        for (i in 0 until time.length()) {
            val ds = time.optString(i)
            val date = try { LocalDate.parse(ds) } catch (e: Exception) { continue }
            val h = hum[ds]
            val cd = code.int(i)
            days.add(
                WxDay(
                    date = date,
                    code = if (cd < 0) 3 else cd,
                    tMax = tmax.dbl(i), tMin = tmin.dbl(i),
                    feelMax = fmax.dbl(i), feelMin = fmin.dbl(i),
                    rainProb = rp.int(i),
                    rainMm = rs.dbl(i).let { if (it.isNaN()) 0.0 else it },
                    wind = wm.dbl(i), windDir = wd.int(i),
                    humidity = if (h != null && h[1] > 0) (h[0].toDouble() / h[1]).roundToInt() else -1
                )
            )
        }
        if (days.isEmpty()) throw IllegalStateException("Sin datos diarios")
        return WxReport(place, now, days, at, hours, nowDate, nowHour)
    }
}
