package com.personal.launcher.weather

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Datos meteorológicos REALES de Open-Meteo (https://open-meteo.com): gratuito y sin clave.
 *  · Búsqueda de ciudades: geocoding-api.open-meteo.com
 *  · Pronóstico:           api.open-meteo.com
 * Todo se llama desde hilos secundarios; nunca desde el hilo principal.
 */
object WeatherApi {
    private const val GEO = "https://geocoding-api.open-meteo.com/v1/search"
    private const val FC = "https://api.open-meteo.com/v1/forecast"

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10000
            c.readTimeout = 12000
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("User-Agent", "VERDANT-Launcher")
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun search(query: String): List<WxPlace> {
        val url = GEO + "?name=" + URLEncoder.encode(query.trim(), "UTF-8") + "&count=8&language=es&format=json"
        val arr = JSONObject(get(url)).optJSONArray("results") ?: return emptyList()
        val out = ArrayList<WxPlace>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!o.has("latitude") || !o.has("longitude")) continue
            out.add(
                WxPlace(
                    o.optString("name"), o.optString("admin1"), o.optString("country"),
                    o.getDouble("latitude"), o.getDouble("longitude")
                )
            )
        }
        return out
    }

    /** Respuesta cruda del pronóstico: 14 días + condiciones actuales. */
    fun forecast(p: WxPlace): String {
        val url = FC +
            "?latitude=" + String.format(Locale.US, "%.4f", p.lat) +
            "&longitude=" + String.format(Locale.US, "%.4f", p.lon) +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m" +
            "&hourly=relative_humidity_2m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min," +
            "precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_direction_10m_dominant" +
            "&timezone=auto&forecast_days=14&wind_speed_unit=kmh&temperature_unit=celsius"
        return get(url)
    }
}

/**
 * Ubicación elegida y última respuesta (caché). Archivos propios, independientes de [com.personal.launcher.Prefs],
 * para no inflar las preferencias del launcher.
 */
object WeatherStore {
    private fun sp(c: Context) = c.getSharedPreferences("verdant_weather", Context.MODE_PRIVATE)
    private fun file(c: Context) = File(c.filesDir, "weather_cache.json")

    fun place(c: Context): WxPlace? {
        val s = sp(c).getString("place", null) ?: return null
        return try { WxPlace.fromJson(JSONObject(s)) } catch (e: Exception) { null }
    }

    fun savePlace(c: Context, p: WxPlace) {
        sp(c).edit().putString("place", p.toJson().toString()).apply()
        try { file(c).delete() } catch (e: Exception) { }
    }

    /** Se llama desde un hilo secundario. */
    fun saveCache(c: Context, p: WxPlace, raw: String, at: Long) {
        try {
            val o = JSONObject().put("at", at).put("lat", p.lat).put("lon", p.lon).put("data", JSONObject(raw))
            file(c).writeText(o.toString())
        } catch (e: Exception) { }
    }

    /** Caché válida para ese lugar, o null. */
    fun loadCache(c: Context, p: WxPlace): WxReport? {
        return try {
            val f = file(c)
            if (!f.exists()) return null
            val o = JSONObject(f.readText())
            if (o.getDouble("lat") != p.lat || o.getDouble("lon") != p.lon) return null
            WxParser.parse(p, o.getJSONObject("data"), o.getLong("at"))
        } catch (e: Exception) {
            null
        }
    }
}
