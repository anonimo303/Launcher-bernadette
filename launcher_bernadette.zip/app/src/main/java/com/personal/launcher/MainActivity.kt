package com.personal.launcher

import android.app.Activity
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private const val NAV_H = 86
private const val NAV_MARGIN = 10

private class Cell(val icon: ImageView, val label: TextView)

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var homeLayer: HomeLayer
    private lateinit var removeZone: TextView
    private lateinit var drawer: LinearLayout
    private lateinit var host: PagerHost
    private lateinit var navBar: NavBar
    private lateinit var resPanel: ResourcesPanel
    private lateinit var weather: com.personal.launcher.weather.WeatherPanel
    private lateinit var searchBox: EditText
    private lateinit var grid: GridView
    private val adapter = DrawerAdapter()

    private var items: MutableList<HomeItem> = mutableListOf()
    // --- navegación (común a los tres estilos de barra) ---
    private var hList: List<PageId> = listOf(PageId.HOME)   // pantallas que se recorren en horizontal
    private var barList: List<PageId> = emptyList()         // pestañas de la barra
    private var swipeMode = false
    private var hpos = 0f                                   // posición horizontal continua
    private var appsP = 0f                                  // progreso del cajón cuando es superpuesto
    private var cur = PageId.HOME
    private var hAnim: ValueAnimator? = null
    private var appsAnim: ValueAnimator? = null
    private var resumed = false
    private var navSig: String? = null
    private var lastPack: String? = null
    private val drawerOpen: Boolean get() = cur == PageId.APPS
    private var dragActive = false
    private var itemTouched = false
    private var pendingRefresh = false

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            reloadApps()
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lastPack = Prefs.str(this, "icon_pack")
        root = FrameLayout(this)

        // Capa de la pantalla principal (iconos libres)
        homeLayer = HomeLayer(this)
        homeLayer.isClickable = true
        homeLayer.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (pendingRefresh && homeLayer.width > 0) {
                pendingRefresh = false
                homeLayer.post { refreshHome() }
            }
        }
        host = PagerHost(this)
        // El pager no permite overscroll ni dibujar páginas fuera del viewport.
        host.clipChildren = true
        host.clipToPadding = true
        host.overScrollMode = View.OVER_SCROLL_NEVER
        host.addView(homeLayer, FrameLayout.LayoutParams(MATCH, MATCH))
        resPanel = ResourcesPanel(this)
        resPanel.visibility = View.GONE
        host.addView(resPanel, FrameLayout.LayoutParams(MATCH, MATCH))
        weather = com.personal.launcher.weather.WeatherPanel(this)
        weather.visibility = View.GONE
        host.addView(weather, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(host, FrameLayout.LayoutParams(MATCH, MATCH))

        // Zona "Quitar" (aparece al arrastrar un icono)
        removeZone = TextView(this)
        removeZone.text = "✕  Quitar de la pantalla"
        removeZone.setTextColor(Color.WHITE)
        removeZone.textSize = 16f
        removeZone.gravity = Gravity.CENTER
        val rz = GradientDrawable()
        rz.setColor(Color.parseColor("#88B71C1C"))
        rz.setStroke(Ui.dp(this, 2), Color.parseColor("#FFFF6B6B"))
        removeZone.background = rz
        removeZone.visibility = View.GONE
        root.addView(removeZone, FrameLayout.LayoutParams(MATCH, Ui.dp(this, 64)))

        // Cajón de aplicaciones
        drawer = LinearLayout(this)
        drawer.orientation = LinearLayout.VERTICAL
        // Totalmente opaco: con transparencia se veía el menú de atrás (Recursos/Inicio) a través del cajón.
        drawer.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#FF04140C"), Color.parseColor("#FF020B06"))
        )
        drawer.isClickable = true
        drawer.visibility = View.GONE
        drawer.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), 0)

        searchBox = EditText(this)
        searchBox.hint = "Buscar aplicaciones"
        searchBox.setHintTextColor(Color.parseColor("#7FA894"))
        searchBox.setTextColor(Ui.TEXT)
        searchBox.setSingleLine(true)
        searchBox.imeOptions = EditorInfo.IME_ACTION_SEARCH
        searchBox.background = Ui.glass(this, 18)
        searchBox.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12))
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                adapter.setFilter(s?.toString() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        searchBox.setOnEditorActionListener { _, _, _ ->
            val l = adapter.data
            if (l.isNotEmpty()) {
                launch(l[0], null)
                dismissApps()
            }
            true
        }
        drawer.addView(searchBox, LinearLayout.LayoutParams(MATCH, WRAP))

        grid = GridView(this)
        grid.adapter = adapter
        grid.selector = ColorDrawable(Color.TRANSPARENT)
        grid.verticalSpacing = Ui.dp(this, 10)
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.isVerticalScrollBarEnabled = false
        grid.setPadding(0, 0, 0, 0)
        // Los iconos se desvanecen suavemente en los bordes en vez de cortarse en seco
        grid.isVerticalFadingEdgeEnabled = true
        grid.setFadingEdgeLength(Ui.dp(this, 28))
        grid.setOnItemClickListener { _, view, pos, _ ->
            launch(adapter.data[pos], view)
            dismissApps()
        }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            showAppMenu(adapter.data[pos])
            true
        }
        val glp = LinearLayout.LayoutParams(MATCH, 0, 1f)
        glp.topMargin = Ui.dp(this, 10)
        drawer.addView(grid, glp)
        host.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))

        // Barra de navegación animada (Arco / Haz / Burbuja)
        navBar = NavBar(this)
        navBar.onSelect = { i -> if (i in barList.indices) goTo(barList[i]) }
        val nlp = FrameLayout.LayoutParams(MATCH, Ui.dp(this, NAV_H), Gravity.BOTTOM)
        nlp.leftMargin = Ui.dp(this, 14)
        nlp.rightMargin = Ui.dp(this, 14)
        nlp.bottomMargin = Ui.dp(this, NAV_MARGIN)
        root.addView(navBar, nlp)

        host.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or2, ob ->
            if (r - l != or2 - ol || b - t != ob - ot) layoutPages()
        }

        setContentView(root)

        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addAction(Intent.ACTION_PACKAGE_REPLACED)
        f.addDataScheme("package")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(pkgReceiver, f)
        }

        reloadApps()
    }

    override fun onResume() {
        super.onResume()
        applyBars()
        val dimAlpha = intArrayOf(0, 70, 140)[Prefs.int(this, "dim", 0).coerceIn(0, 2)]
        root.setBackgroundColor(Color.argb(dimAlpha, 0, 0, 0))
        grid.numColumns = Prefs.int(this, "drawer_cols", 4).coerceIn(3, 6)
        searchBox.visibility = if (Prefs.bool(this, "drawer_search", true)) View.VISIBLE else View.GONE
        adapter.setFilter(searchBox.text.toString())
        refreshHome()
        resumed = true
        val pack = Prefs.str(this, "icon_pack")
        if (pack != lastPack || Prefs.bool(this, "reload_req", false)) {
            lastPack = pack
            Prefs.setBool(this, "reload_req", false)
            reloadApps()
        }
        applyNavConfig()
        applyInsets()
    }

    override fun onPause() {
        resumed = false
        resPanel.stop()
        weather.stop()
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        goTo(PageId.HOME)
    }

    override fun onBackPressed() {
        if (isOverlay()) closeOverlayApps()
        else if (cur == PageId.WEATHER && weather.onBack()) { /* Clima cerró su detalle o su búsqueda */ }
        else if (cur != PageId.HOME) goTo(PageId.HOME)
        // Es el launcher: no se cierra.
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- utilidades

    private fun toast(s: String) {
        Prefs.say(this, s)
    }

    private fun startSafe(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("No se pudo abrir")
        }
    }

    private fun applyBars() {
        val hs = Prefs.bool(this, "hide_status", false)
        val hn = Prefs.bool(this, "hide_nav", false)
        // LAYOUT_STABLE hace que Android siga reservando el espacio de una barra aunque esté oculta
        // (ese era el hueco que dejaba ver el fondo). Con una barra oculta se usan los flags LAYOUT_*:
        // el contenido se estira hasta el borde de la pantalla y la tapa.
        var f = if (!hs && !hn) View.SYSTEM_UI_FLAG_LAYOUT_STABLE else 0
        if (hs) f = f or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        if (hn) {
            f = f or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
        window.decorView.systemUiVisibility = f
    }

    /** Con la barra de estado oculta el contenido llega hasta arriba: se deja su altura libre para el buscador y los títulos. */
    private fun applyInsets() {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (Prefs.bool(this, "hide_status", false) && id > 0) resources.getDimensionPixelSize(id) else 0
        drawer.setPadding(Ui.dp(this, 12), Ui.dp(this, 12) + sb, Ui.dp(this, 12), drawer.paddingBottom)
        resPanel.setTopInset(sb)
        weather.setTopInset(sb)
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun reloadApps() {
        Thread {
            AppRepo.load(applicationContext)
            runOnUiThread {
                if (!isDestroyed) {
                    adapter.setFilter(searchBox.text.toString())
                    refreshHome()
                }
            }
        }.start()
    }

    private fun launch(info: AppInfo, from: View?) {
        val i = Intent(Intent.ACTION_MAIN)
        i.addCategory(Intent.CATEGORY_LAUNCHER)
        i.setClassName(info.pkg, info.cls)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val animApps = Prefs.bool(this, "anim_apps", true) && !Prefs.bool(this, "perf_save", false)
            if (animApps && from != null) {
                val o = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
                startActivity(i, o.toBundle())
            } else if (!animApps) {
                startActivity(i, ActivityOptions.makeCustomAnimation(this, 0, 0).toBundle())
            } else {
                startActivity(i)
            }
        } catch (e: Exception) {
            toast("No se pudo abrir la app")
        }
    }

    // ---------------------------------------------------------------- cajón

    private fun showAppMenu(a: AppInfo) {
        // MAHORAGA GAMES: sin opción de desinstalar ni de eliminar desde el cajón de VERDANT
        if (com.personal.launcher.mahoraga.Mh.isEntry(a.key)) {
            Ui.menu(this, a.label, listOf("Añadir a la pantalla principal", "Información de MAHORAGA")) { i ->
                when (i) {
                    0 -> addToHome(a)
                    1 -> startSafe(Intent(this, com.personal.launcher.mahoraga.MahoragaActivity::class.java).putExtra("screen", "about"))
                    else -> {}
                }
            }
            return
        }
        val labels = listOf("Añadir a la pantalla principal", "Información de la app", "Desinstalar", "Ocultar aplicación")
        Ui.menu(this, a.label, labels) { i ->
            when (i) {
                0 -> addToHome(a)
                1 -> startSafe(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)))
                2 -> startSafe(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)))
                3 -> {
                    val hidden = Prefs.hiddenApps(this).toMutableSet()
                    hidden.add(a.key)
                    Prefs.setHiddenApps(this, hidden)
                    adapter.setFilter(searchBox.text.toString())
                    refreshHome()
                    toast("Aplicación ocultada")
                }
                else -> {}
            }
        }
    }

    private fun addToHome(a: AppInfo) {
        items = HomeStore.load(this)
        if (items.any { it.key == a.key }) {
            toast("Ya está en la pantalla principal")
            return
        }
        val p = HomeStore.nextFree(items)
        items.add(HomeItem(a.key, p.first, p.second))
        HomeStore.save(this, items)
        goTo(PageId.HOME, false)
        refreshHome()
        toast("Añadido a la pantalla principal")
    }

    private inner class DrawerAdapter : BaseAdapter() {
        var data: List<AppInfo> = emptyList()

        fun setFilter(q: String) {
            val s = q.trim()
            val hidden = Prefs.hiddenApps(this@MainActivity)
            val visible = AppRepo.list.filter { it.key !in hidden }
            data = if (s.isEmpty()) visible else visible.filter { it.label.contains(s, ignoreCase = true) }
            notifyDataSetChanged()
        }

        override fun getCount(): Int = data.size
        override fun getItem(position: Int): Any = data[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val cell: View = convertView ?: makeCell()
            val h = cell.tag as Cell
            val a = data[position]
            h.icon.setImageDrawable(a.icon)
            h.label.text = a.label
            return cell
        }
    }

    private fun makeCell(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4))
        val iv = ImageView(this)
        iv.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 52))
        val tv = TextView(this)
        tv.setTextColor(Ui.TEXT)
        tv.textSize = 11f
        tv.maxLines = 1
        tv.gravity = Gravity.CENTER
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.setPadding(Ui.dp(this, 2), Ui.dp(this, 4), Ui.dp(this, 2), 0)
        col.addView(iv)
        col.addView(tv)
        col.tag = Cell(iv, tv)
        return col
    }

    // ---------------------------------------------------------------- navegación
    //
    // Un único motor para los TRES estilos de barra. El estilo solo cambia cómo se dibuja
    // la barra (NavBar.navStyle); las pantallas, los gestos y los toques son idénticos.
    //
    //  · Gestos ACTIVADOS: Inicio, Aplicaciones y Recursos se recorren deslizando en
    //    horizontal. El acceso a «Aplicaciones» desaparece de la barra.
    //  · Gestos DESACTIVADOS: la barra muestra todas las pantallas y se navega tocando;
    //    «Aplicaciones» se abre como cajón superpuesto (con su animación de siempre).

    private fun pageView(p: PageId): View = when (p) {
        PageId.HOME -> homeLayer
        PageId.APPS -> drawer
        PageId.RES -> resPanel
        PageId.WEATHER -> weather
    }

    /** El cajón es superpuesto cuando no forma parte de la lista horizontal. */
    private fun isOverlay(): Boolean = cur == PageId.APPS && PageId.APPS !in hList

    private fun animOn(): Boolean = Prefs.animOn(this)
    private fun scaled(ms: Long): Long = (ms * Prefs.animScale(this)).toLong()

    private fun applyNavConfig() {
        navBar.navStyle = NavConfig.style(this)
        // Deslizar entre pantallas está siempre activo y la barra conserva los tres botones
        val swipe = true
        val pages = NavConfig.pages(this)
        val sig = swipe.toString() + pages.joinToString(",") { it.key }
        if (sig != navSig) {
            navSig = sig
            hAnim?.cancel()
            appsAnim?.cancel()
            swipeMode = swipe
            hList = pages
            barList = pages
            navBar.setPages(barList)
            val showBar = barList.size >= 2
            navBar.visibility = if (showBar) View.VISIBLE else View.GONE
            val inset = if (showBar) Ui.dp(this, NAV_H + NAV_MARGIN + 4) else Ui.dp(this, 12)
            drawer.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), inset)
            resPanel.setBottomInset(inset)
            weather.setBottomInset(inset)
            cur = PageId.HOME
            hpos = hList.indexOf(PageId.HOME).coerceAtLeast(0).toFloat()
            appsP = 0f
            syncNav(false)
        }
        layoutPages()
    }

    /** Coloca cada pantalla según [hpos] / [appsP]. Barato: solo traslaciones y alfa. */
    private fun layoutPages() {
        val w = host.width.toFloat()
        val h = host.height.toFloat()
        if (w <= 0f) return
        for (p in PageId.values()) {
            val v = pageView(p)
            val idx = hList.indexOf(p)
            if (idx >= 0) {
                val off = idx - hpos
                v.translationX = off * w
                v.translationY = 0f
                v.alpha = 1f - 0.45f * minOf(1f, abs(off))
                val vis = if (abs(off) >= 1f) View.INVISIBLE else View.VISIBLE
                if (v.visibility != vis) v.visibility = vis
            } else if (p == PageId.APPS) {
                v.translationX = 0f
                v.alpha = 1f
                v.translationY = (1f - appsP) * h
                val vis = if (appsP <= 0f) View.GONE else View.VISIBLE
                if (v.visibility != vis) v.visibility = vis
            } else {
                v.visibility = View.GONE
            }
        }
        val ri = hList.indexOf(PageId.RES)
        if (resumed && ri >= 0 && abs(ri - hpos) < 1f && !isOverlay()) resPanel.start() else resPanel.stop()
        // Clima: animaciones y red solo mientras es visible
        val wi = hList.indexOf(PageId.WEATHER)
        if (resumed && wi >= 0 && abs(wi - hpos) < 1f && !isOverlay()) weather.start() else weather.stop()
    }

    /** Indicador de la barra durante el arrastre (modo gestos): sigue a [hpos] de forma continua. */
    private fun navFromH() {
        if (hList.isEmpty() || barList.isEmpty()) return
        val i0 = floor(hpos).toInt().coerceIn(0, hList.size - 1)
        val i1 = minOf(i0 + 1, hList.size - 1)
        val f = (hpos - i0).coerceIn(0f, 1f)
        val a = barList.indexOf(hList[i0])
        val b = barList.indexOf(hList[i1])
        when {
            a >= 0 && b >= 0 -> navBar.setPosition(a + (b - a) * f, 1f)
            a >= 0 -> navBar.setPosition(a.toFloat(), 1f - f)
            b >= 0 -> navBar.setPosition(b.toFloat(), f)
            else -> navBar.setPosition(navBar.pos, 0f)
        }
    }

    private fun applyH() {
        layoutPages()
        if (swipeMode && !isOverlay()) navFromH()
    }

    /** Sincroniza la barra con la pantalla actual (modo toque o cajón superpuesto). */
    private fun syncNav(animate: Boolean) {
        if (swipeMode && !isOverlay()) {
            navFromH()
            return
        }
        val slot = barList.indexOf(cur)
        val d = if (animate && animOn()) scaled(560L) else 0L
        if (slot >= 0) navBar.animateTo(slot.toFloat(), 1f, d)
        else navBar.animateTo(navBar.pos, 0f, d)
    }

    private fun onCurChanged(old: PageId) {
        if (old == cur) return
        if (cur == PageId.APPS && searchBox.text.isNotEmpty()) searchBox.setText("")
        if (old == PageId.APPS) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
        }
    }

    /**
     * Mientras las pantallas se mueven se cachean como textura de GPU: así deslizar/fundir
     * (alfa) no vuelve a dibujar cada pantalla en cada fotograma. Al terminar se liberan.
     */
    private fun pageLayers(on: Boolean) {
        val t = if (on) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE
        for (p in PageId.values()) {
            val v = pageView(p)
            if (v.layerType != t) v.setLayerType(t, null)
        }
    }

    private val layersOff = object : AnimatorListenerAdapter() {
        override fun onAnimationEnd(animation: Animator) {
            if (hAnim?.isRunning != true && appsAnim?.isRunning != true) pageLayers(false)
        }
    }

    private fun animateH(target: Float, animate: Boolean) {
        hAnim?.cancel()
        if (abs(hpos - target) < 0.001f || !animate || !animOn()) {
            hpos = target
            applyH()
            if (appsAnim?.isRunning != true) pageLayers(false)
            return
        }
        val from = hpos
        pageLayers(true)
        hAnim = ValueAnimator.ofFloat(from, target).apply {
            duration = scaled((520 + 190 * minOf(2f, abs(target - from))).toLong())
            interpolator = Motion.settle
            addUpdateListener {
                hpos = it.animatedValue as Float
                applyH()
            }
            addListener(layersOff)
            start()
        }
    }

    private fun setOverlay(open: Boolean, animate: Boolean) {
        appsAnim?.cancel()
        val target = if (open) 1f else 0f
        if (!animate || !animOn()) {
            appsP = target
            layoutPages()
            if (hAnim?.isRunning != true) pageLayers(false)
            return
        }
        pageLayers(true)
        appsAnim = ValueAnimator.ofFloat(appsP, target).apply {
            duration = scaled(if (open) 500L else 420L)
            interpolator = if (open) Motion.settle else Motion.inOut
            addUpdateListener {
                appsP = it.animatedValue as Float
                layoutPages()
            }
            addListener(layersOff)
            start()
        }
    }

    /** Ir a una pantalla. Lo usan por igual toques en la barra, gestos y atajos. */
    private fun goTo(p: PageId, animate: Boolean = true) {
        val old = cur
        val wasOverlay = isOverlay()
        if (p == PageId.APPS && PageId.APPS !in hList) {
            cur = p
            onCurChanged(old)
            setOverlay(true, animate)
            syncNav(animate)
            return
        }
        val idx = hList.indexOf(p)
        if (idx < 0) return
        cur = p
        onCurChanged(old)
        if (wasOverlay) {
            hAnim?.cancel()
            hpos = idx.toFloat()
            setOverlay(false, animate)
            val slot = barList.indexOf(p)
            if (slot >= 0) navBar.animateTo(slot.toFloat(), 1f, if (animate && animOn()) scaled(560L) else 0L)
        } else {
            animateH(idx.toFloat(), animate)
            syncNav(animate)
        }
    }

    /** Cierra el cajón superpuesto volviendo a la pantalla que había debajo. */
    private fun closeOverlayApps() {
        val under = hList[hpos.roundToInt().coerceIn(0, hList.size - 1)]
        goTo(under)
    }

    /** Tras abrir una app o añadirla: salir del cajón. */
    private fun dismissApps() {
        if (isOverlay()) closeOverlayApps()
        else if (cur == PageId.APPS) goTo(PageId.HOME, false)
    }

    /** Fin de un arrastre: elegir pantalla destino según posición y velocidad. */
    private fun settleTo(vx: Float) {
        val n = hList.size
        var t = hpos.roundToInt()
        if (abs(vx) > 800f) {
            // dedo hacia la izquierda (vx < 0) = pantalla siguiente
            t = if (vx < 0) floor(hpos).toInt() + 1 else ceil(hpos).toInt() - 1
        }
        t = t.coerceIn(0, n - 1)
        val old = cur
        cur = hList[t]
        onCurChanged(old)
        animateH(t.toFloat(), true)
    }

    /**
     * Contenedor de pantallas. Intercepta los arrastres horizontales para cambiar de
     * pantalla y mueve [hpos]; la barra sigue el movimiento en vivo.
     */
    private inner class PagerHost(c: Context) : FrameLayout(c) {
        private val slop = ViewConfiguration.get(c).scaledTouchSlop
        private var downX = 0f
        private var downY = 0f
        private var startPos = 0f
        private var dragging = false
        private var closing = false     // arrastre hacia abajo en Aplicaciones (vuelve a Inicio)
        private var vt: VelocityTracker? = null

        private fun enabled() = swipeMode && hList.size >= 2 && !isOverlay()

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
            if (!enabled()) return false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    vt?.recycle()
                    vt = VelocityTracker.obtain()
                    vt?.addMovement(ev)
                    downX = ev.x
                    downY = ev.y
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    vt?.addMovement(ev)
                    if (dragActive) return false
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (abs(dx) > slop * 1.5f && abs(dx) > abs(dy) * 1.3f) {
                        // No bloquear el desplazamiento hacia Aplicaciones: con el orden
                        // predeterminado, un gesto hacia la izquierda desde Inicio abre el cajón.
                        // El acceso a Clima sigue dependiendo de su posición real en hList.
                        hAnim?.cancel()
                        dragging = true
                        pageLayers(true)
                        startPos = hpos
                        downX = ev.x
                        return true
                    }
                    // Deslizar hacia abajo en Aplicaciones (con la lista arriba del todo) vuelve a Inicio
                    if (cur == PageId.APPS && !grid.canScrollVertically(-1) &&
                        dy > slop * 2f && dy > abs(dx) * 1.5f) {
                        closing = true
                        return true
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    vt?.recycle()
                    vt = null
                }
                else -> {}
            }
            return false
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (closing) {
                vt?.addMovement(ev)
                if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                    var vy = 0f
                    vt?.let {
                        it.computeCurrentVelocity(1000)
                        vy = it.yVelocity
                    }
                    vt?.recycle()
                    vt = null
                    closing = false
                    if (ev.actionMasked == MotionEvent.ACTION_UP &&
                        (ev.y - downY > Ui.dp(context, 80) || vy > 900f)) goTo(PageId.HOME)
                }
                return true
            }
            if (!dragging) return false
            vt?.addMovement(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> {
                    val w = width.toFloat().coerceAtLeast(1f)
                    val maxP = (hList.size - 1).toFloat()
                    hpos = (startPos - (ev.x - downX) / w).coerceIn(0f, maxP)
                    applyH()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    var vx = 0f
                    vt?.let {
                        it.computeCurrentVelocity(1000)
                        vx = it.xVelocity
                    }
                    vt?.recycle()
                    vt = null
                    dragging = false
                    settleTo(if (ev.actionMasked == MotionEvent.ACTION_CANCEL) 0f else vx)
                }
                else -> {}
            }
            return true
        }
    }

    // ---------------------------------------------------------------- pantalla principal

    private fun showHomeMenu() {
        homeLayer.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val labels = mutableListOf("Configuración del launcher")
        if (items.none { it.key == HomeStore.GEAR }) labels.add("Colocar icono del engranaje")
        labels.add("Aplicaciones")
        labels.add("Ver aplicaciones ocultas")
        labels.add("Cambiar fondo de pantalla")
        Ui.menu(this, "VERDANT Launcher", labels) { i ->
            when (labels[i]) {
                "Configuración del launcher" -> openSettings()
                "Colocar icono del engranaje" -> {
                    HomeStore.addGear(this)
                    refreshHome()
                }
                "Aplicaciones" -> goTo(PageId.APPS)
                "Ver aplicaciones ocultas" -> requestHiddenAppsAccess()
                "Cambiar fondo de pantalla" ->
                    startSafe(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Fondo de pantalla"))
                else -> {}
            }
        }
    }

    private fun requestHiddenAppsAccess() {
        val hidden = Prefs.hiddenApps(this)
        if (hidden.isEmpty()) {
            toast("No hay aplicaciones ocultas")
            return
        }
        if (!Prefs.bool(this, "hidden_lock", false)) {
            showHiddenAppsList()
            return
        }
        val pinHash = Prefs.str(this, "hidden_pin_hash")
        if (pinHash.isNullOrBlank()) {
            toast("Configura primero la contraseña en Ajustes")
            openSettings()
            return
        }
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "Contraseña numérica"
            setSingleLine(true)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Aplicaciones ocultas")
            .setMessage("Introduce tu contraseña para continuar")
            .setView(input)
            .setPositiveButton("Aceptar") { _, _ ->
                if (sha256(input.text.toString()) == pinHash) showHiddenAppsList()
                else toast("Contraseña incorrecta")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun sha256(value: String): String = java.security.MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun showHiddenAppsList() {
        val hidden = Prefs.hiddenApps(this)
        val apps = AppRepo.list.filter { it.key in hidden }.sortedBy { it.label.lowercase() }
        if (apps.isEmpty()) { toast("No hay aplicaciones ocultas"); return }
        Ui.menu(this, "Aplicaciones ocultas", apps.map { it.label }) { index ->
            val app = apps.getOrNull(index) ?: return@menu
            Ui.menu(this, app.label, listOf("Abrir aplicación", "Mostrar en el cajón")) { action ->
                if (action == 0) launch(app, null)
                else if (action == 1) {
                    val updated = Prefs.hiddenApps(this).toMutableSet()
                    updated.remove(app.key)
                    Prefs.setHiddenApps(this, updated)
                    adapter.setFilter(searchBox.text.toString())
                    refreshHome()
                    toast("Aplicación visible nuevamente")
                }
            }
        }
    }

    private fun refreshHome() {
        if (homeLayer.width == 0) {
            pendingRefresh = true
            return
        }
        items = HomeStore.load(this)
        if (AppRepo.loaded) {
            val before = items.size
            items.removeAll { it.key != HomeStore.GEAR && AppRepo.find(it.key) == null }
            if (items.size != before) HomeStore.save(this, items)
        }
        homeLayer.removeAllViews()
        val w = homeLayer.width
        val h = homeLayer.height
        val hiddenKeys = Prefs.hiddenApps(this)
        for (item in items) {
            if (item.key in hiddenKeys) continue
            val v = makeHomeItemView(item) ?: continue
            homeLayer.addView(v)
            val maxX = (w - v.layoutParams.width).coerceAtLeast(0)
            val maxY = (h - Ui.dp(this, 100)).coerceAtLeast(0)
            v.x = (item.x * w).coerceIn(0f, maxX.toFloat())
            v.y = (item.y * h).coerceIn(0f, maxY.toFloat())
        }
    }

    private fun makeHomeItemView(item: HomeItem): View? {
        val isGear = item.key == HomeStore.GEAR
        val app: AppInfo? = if (isGear) null else AppRepo.find(item.key)
        if (!isGear && app == null) return null
        val sizeDp = intArrayOf(48, 56, 66)[Prefs.int(this, "icon_size", 1).coerceIn(0, 2)]

        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.gravity = Gravity.CENTER_HORIZONTAL

        val iv = ImageView(this)
        iv.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, sizeDp), Ui.dp(this, sizeDp))
        if (isGear) iv.setImageResource(R.drawable.ic_gear) else iv.setImageDrawable(app!!.newIcon())
        v.addView(iv)

        if (Prefs.bool(this, "labels", true)) {
            val tv = TextView(this)
            tv.text = if (isGear) "Configuración" else app!!.label
            tv.setTextColor(Color.WHITE)
            tv.setShadowLayer(4f, 0f, 1f, Color.BLACK)
            tv.textSize = 11f
            tv.maxLines = 1
            tv.gravity = Gravity.CENTER
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setPadding(0, Ui.dp(this, 4), 0, 0)
            v.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
        }

        val lp = FrameLayout.LayoutParams(Ui.dp(this, sizeDp + 28), WRAP)
        lp.gravity = Gravity.TOP or Gravity.LEFT
        v.layoutParams = lp
        attachItemTouch(v, item, app)
        return v
    }

    private fun isOverRemove(rawX: Float, rawY: Float): Boolean {
        val loc = IntArray(2)
        removeZone.getLocationOnScreen(loc)
        return rawX >= loc[0] && rawX <= loc[0] + removeZone.width &&
            rawY >= loc[1] && rawY <= loc[1] + removeZone.height
    }

    private fun attachItemTouch(v: View, item: HomeItem, app: AppInfo?) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0f
        var startY = 0f
        var dragging = false
        var moved = false

        val longPress = Runnable {
            dragging = true
            dragActive = true
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            v.bringToFront()
            v.animate().scaleX(1.12f).scaleY(1.12f).setDuration(100).start()
            removeZone.alpha = 0.75f
            removeZone.visibility = View.VISIBLE
        }

        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    itemTouched = true
                    downX = e.rawX
                    downY = e.rawY
                    startX = v.x
                    startY = v.y
                    dragging = false
                    moved = false
                    v.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging) {
                        if (abs(dx) > slop || abs(dy) > slop) {
                            moved = true
                            v.removeCallbacks(longPress)
                        }
                    } else {
                        val maxX = (homeLayer.width - v.width).coerceAtLeast(0).toFloat()
                        val maxY = (homeLayer.height - v.height).coerceAtLeast(0).toFloat()
                        v.x = (startX + dx).coerceIn(0f, maxX)
                        v.y = (startY + dy).coerceIn(0f, maxY)
                        removeZone.alpha = if (isOverRemove(e.rawX, e.rawY)) 1f else 0.75f
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.removeCallbacks(longPress)
                    if (dragging) {
                        val drop = e.actionMasked == MotionEvent.ACTION_UP && isOverRemove(e.rawX, e.rawY)
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                        removeZone.visibility = View.GONE
                        if (drop) {
                            items.remove(item)
                            homeLayer.removeView(v)
                        } else {
                            item.x = v.x / homeLayer.width
                            item.y = v.y / homeLayer.height
                        }
                        HomeStore.save(this, items)
                        dragging = false
                        dragActive = false
                    } else if (e.actionMasked == MotionEvent.ACTION_UP && !moved) {
                        if (item.key == HomeStore.GEAR) {
                            openSettings()
                        } else if (app != null) {
                            launch(app, v)
                        }
                    }
                }
                else -> {}
            }
            true
        }
    }

    /**
     * Capa de la pantalla principal: detecta mantener presionado en zona vacía
     * (menú del launcher) y deslizar hacia arriba (cajón) sin consumir los eventos
     * de los iconos.
     */
    private inner class HomeLayer(c: Context) : FrameLayout(c) {
        private var dX = 0f
        private var dY = 0f
        private var t0 = 0L
        private var lastTapAt = 0L
        private var lastTapX = 0f
        private var lastTapY = 0f
        private val slop = ViewConfiguration.get(c).scaledTouchSlop
        private val longPressRun = Runnable {
            if (!itemTouched && !dragActive && !drawerOpen) showHomeMenu()
        }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    itemTouched = false
                    dX = ev.rawX
                    dY = ev.rawY
                    t0 = ev.eventTime
                    removeCallbacks(longPressRun)
                    postDelayed(longPressRun, ViewConfiguration.getLongPressTimeout().toLong())
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(ev.rawX - dX) > slop || abs(ev.rawY - dY) > slop) {
                        removeCallbacks(longPressRun)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    removeCallbacks(longPressRun)
                    val dy = ev.rawY - dY
                    val dx = ev.rawX - dX
                    val dt = ev.eventTime - t0
                    if (!dragActive && !drawerOpen &&
                        -dy > Ui.dp(context, 90) && abs(dx) < -dy && dt < 700
                    ) {
                        goTo(PageId.APPS)
                    } else if (!dragActive && !drawerOpen && !itemTouched && abs(dx) < slop && abs(dy) < slop) {
                        val now = ev.eventTime
                        val closeToLast = abs(ev.rawX - lastTapX) < Ui.dp(context, 48) && abs(ev.rawY - lastTapY) < Ui.dp(context, 48)
                        if (lastTapAt > 0L && now - lastTapAt in 40L..350L && closeToLast) {
                            lastTapAt = 0L
                            val pkg = Prefs.str(context, "double_tap_app")
                            if (!pkg.isNullOrBlank()) {
                                try {
                                    val launch = context.packageManager.getLaunchIntentForPackage(pkg)
                                    if (launch != null) {
                                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        context.startActivity(launch)
                                    } else Prefs.say(context, "La aplicación seleccionada ya no está disponible.")
                                } catch (_: Exception) { Prefs.say(context, "No se pudo abrir la aplicación seleccionada.") }
                            }
                        } else {
                            lastTapAt = now
                            lastTapX = ev.rawX
                            lastTapY = ev.rawY
                        }
                    }
                }
                MotionEvent.ACTION_CANCEL -> removeCallbacks(longPressRun)
                else -> {}
            }
            return super.dispatchTouchEvent(ev)
        }
    }
}
