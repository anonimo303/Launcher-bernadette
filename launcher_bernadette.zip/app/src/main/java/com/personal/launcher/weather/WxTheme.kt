package com.personal.launcher.weather

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.Choreographer
import android.view.View

/** Paleta exclusiva de la sección Clima (azul eléctrico, violeta, morado profundo). */
object WxC {
    val TEXT: Int = 0xFFFFFFFF.toInt()
    val SUB: Int = 0xFFB9C2F7.toInt()
    val DIM: Int = 0xFF7F8AD0.toInt()
    val BLUE: Int = 0xFF4FB4FF.toInt()
    val CYAN: Int = 0xFF2FD4FF.toInt()
    val VIOLET: Int = 0xFFA77BFF.toInt()
    val PURPLE: Int = 0xFF7A4CFF.toInt()
    val HOT: Int = 0xFFFF3B30.toInt()
}

internal fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
internal fun Context.dpi(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/**
 * Lo que hay «detrás» del cristal: una versión de MUY baja resolución del fondo (1/8).
 * Los paneles dibujan su trozo ampliado con filtro bilineal → desenfoque real del fondo
 * sin gastar un solo desenfoque por fotograma.
 */
class WxBackdrop {
    var scene: Bitmap? = null
    var scale: Int = 8
    var anchor: View? = null
    val glass = ArrayList<View>()

    /** Vuelve a dibujar los paneles (p. ej. al desplazar la lista: el fondo se queda quieto y el panel se mueve). */
    fun refresh() {
        for (v in glass) v.invalidate()
    }
}

/**
 * Panel de cristal: desenfoque del fondo + velo azul/violeta + reflejo especular
 * + brillo interior + borde luminoso degradado.
 *
 * [level]: 0 = pastilla pequeña, 1 = panel grande.
 */
class GlassDrawable(
    private val host: View,
    private val bd: WxBackdrop,
    private val radius: Float,
    private val level: Int = 1
) : Drawable() {

    /** Resalta el borde (p. ej. el día de hoy). */
    var emphasis: Boolean = false
        set(v) { field = v; invalidateSelf() }

    private val rect = RectF()
    private val frost = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spec = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lip = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val m = Matrix()
    private val l1 = IntArray(2)
    private val l2 = IntArray(2)
    private var shBmp: Bitmap? = null
    private val d = host.resources.displayMetrics.density

    override fun onBoundsChange(b: Rect) {
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        if (level == 2) {
            // Píldora violeta (pista «Toca un día…», «Pronóstico extendido», sensación térmica)
            fill.shader = LinearGradient(
                0f, 0f, w, h * 0.6f,
                intArrayOf(alpha(0x5A32D8, 0.78f), alpha(0x2A1C98, 0.80f), alpha(0x0E1450, 0.85f)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        } else {
            // Cristal oscuro: azul marino casi negro con un leve velo violeta abajo
            fill.shader = LinearGradient(
                0f, 0f, 0f, h,
                intArrayOf(alpha(0x1C2C78, 0.48f), alpha(0x0B0F48, 0.62f), alpha(0x22127A, 0.55f)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        }
        spec.shader = LinearGradient(
            0f, 0f, w * 0.65f, h * 0.9f,
            intArrayOf(alpha(0xFFFFFF, 0.07f), alpha(0xFFFFFF, 0.02f), alpha(0xFFFFFF, 0f)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        lip.shader = LinearGradient(
            0f, 0f, w, 0f,
            intArrayOf(alpha(0x9C7CFF, 0f), alpha(0xC8B8FF, 0.70f), alpha(0x9C7CFF, 0f)),
            null, Shader.TileMode.CLAMP
        )
        // borde neón: violeta arriba-izquierda, cian arriba-derecha, violeta intenso abajo
        edge.shader = LinearGradient(
            0f, h, w, 0f,
            intArrayOf(0xFFB05CFF.toInt(), 0xFF6A4CFF.toInt(), 0xFF3C8CFF.toInt(), 0xFF36D6FF.toInt()),
            floatArrayOf(0f, 0.38f, 0.72f, 1f), Shader.TileMode.CLAMP
        )
        glow.shader = LinearGradient(
            0f, h, w, 0f,
            intArrayOf(0xFFB05CFF.toInt(), 0xFF6A4CFF.toInt(), 0xFF3C8CFF.toInt(), 0xFF36D6FF.toInt()),
            floatArrayOf(0f, 0.38f, 0.72f, 1f), Shader.TileMode.CLAMP
        )
    }

    private fun alpha(rgb: Int, a: Float): Int = ((a * 255f).toInt() shl 24) or (rgb and 0xFFFFFF)

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val sw = if (emphasis) 2.2f * d else 1.4f * d
        val inset = sw / 2f
        rect.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)
        val r = radius

        // 1) Fondo desenfocado (trozo del fondo ampliado desde la miniatura)
        val bmp = bd.scene
        val an = bd.anchor
        if (bmp != null && an != null && an.isAttachedToWindow && host.isAttachedToWindow) {
            if (shBmp !== bmp) {
                shBmp = bmp
                frost.shader = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            }
            host.getLocationInWindow(l1)
            an.getLocationInWindow(l2)
            m.setScale(bd.scale.toFloat(), bd.scale.toFloat())
            m.postTranslate((l2[0] - l1[0]).toFloat(), (l2[1] - l1[1]).toFloat())
            frost.shader.setLocalMatrix(m)
            frost.alpha = 70
            c.drawRoundRect(rect, r, r, frost)
        }
        // 2) Velo de color del cristal
        c.drawRoundRect(rect, r, r, fill)
        // 3) Reflejo suave
        c.drawRoundRect(rect, r, r, spec)
        // 4) Brillo interior (halo luminoso del borde)
        glow.strokeWidth = (if (emphasis) 8f else 5f) * d
        glow.alpha = if (emphasis) 150 else 46
        c.drawRoundRect(rect, r, r, glow)
        // 5) Borde de cristal iluminado
        edge.strokeWidth = sw
        edge.alpha = if (emphasis) 255 else 200
        c.drawRoundRect(rect, r, r, edge)
        // 6) Filo de luz en el borde superior
        lip.strokeWidth = d
        val ly = rect.top + sw + 0.5f * d
        c.drawLine(rect.left + r * 0.7f, ly, rect.right - r * 0.7f, ly, lip)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * Reloj único de las animaciones de Clima. Solo corre mientras la sección está visible
 * y limita los fotogramas (30 normal / 24 reducido) para no cargar teléfonos modestos.
 */
class WxClock(private val fps: () -> Int, private val onFrame: (Float) -> Unit) : Choreographer.FrameCallback {
    private val ch = Choreographer.getInstance()
    private var on = false
    private var last = 0L

    val running: Boolean get() = on

    fun start() {
        if (on) return
        on = true
        last = 0L
        ch.postFrameCallback(this)
    }

    fun stop() {
        on = false
        ch.removeFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!on) return
        ch.postFrameCallback(this)
        if (last == 0L) {
            last = frameTimeNanos
            return
        }
        val minNs = 1_000_000_000L / fps().coerceAtLeast(10)
        val el = frameTimeNanos - last
        if (el < minNs * 85L / 100L) return
        last = frameTimeNanos
        onFrame((el / 1_000_000_000f).coerceAtMost(0.1f))
    }
}
