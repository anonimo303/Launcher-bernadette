package com.personal.launcher

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AutomaticGainControl
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Modelo de voz en español que se descarga una sola vez (≈40 MB) y funciona sin internet. */
object VoskModel {
    const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip"

    @Volatile var downloading = false

    fun dir(c: Context): File? {
        val p = Prefs.str(c, "vosk_path") ?: return null
        val f = File(p)
        return if (File(f, "am").isDirectory) f else null
    }

    fun installed(c: Context): Boolean = dir(c) != null

    /** Descarga y descomprime. Llamar en un hilo aparte. Devuelve null si salió bien, o el motivo del fallo. */
    fun download(c: Context, onProgress: (Int) -> Unit): String? {
        val app = c.applicationContext
        val tmp = File(app.cacheDir, "vosk_model.zip")
        downloading = true
        try {
            val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.instanceFollowRedirects = true
            if (conn.responseCode !in 200..299) return "El servidor respondió " + conn.responseCode
            val total = conn.contentLengthLong
            conn.inputStream.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(32768)
                    var done = 0L
                    var n = 0
                    var last = -1
                    while (true) {
                        n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 90 / total).toInt()
                            if (p != last) { last = p; onProgress(p) }
                        }
                    }
                }
            }
            val dest = File(app.filesDir, "vosk")
            dest.deleteRecursively()
            dest.mkdirs()
            val destPath = dest.canonicalPath + File.separator
            ZipInputStream(tmp.inputStream().buffered()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val f = File(dest, e.name)
                    if (!f.canonicalPath.startsWith(destPath)) throw SecurityException("archivo no válido")
                    if (e.isDirectory) f.mkdirs()
                    else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { o -> zin.copyTo(o) }
                    }
                    zin.closeEntry()
                    e = zin.nextEntry
                }
            }
            val model = dest.listFiles()?.firstOrNull { File(it, "am").isDirectory }
                ?: (if (File(dest, "am").isDirectory) dest else null)
                ?: return "El modelo descargado no es válido"
            Prefs.setStr(app, "vosk_path", model.absolutePath)
            onProgress(100)
            return null
        } catch (e: Exception) {
            return "No se pudo descargar: " + (e.message ?: e.javaClass.simpleName)
        } finally {
            downloading = false
            try { tmp.delete() } catch (_: Exception) {}
        }
    }
}

/**
 * Escucha continua y silenciosa: un solo micrófono abierto y reconocimiento en el propio teléfono,
 * sin pitidos ni ciclos. Avisa cuando oye texto (parcial) y cuando termina una frase (final).
 */
class VoskWake(
    private val ctx: Context,
    private val onPartial: (String) -> Unit,
    private val onFinal: (String) -> Unit,
    private val onFail: (String) -> Unit,
    private val onLevel: (Float) -> Unit = {}
) {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        val dir = VoskModel.dir(ctx)
        if (dir == null) { onFail("falta el modelo de voz"); return }
        running = true
        thread = Thread({ loop(dir) }, "vosk-wake").also { it.start() }
    }

    /** Suelta el micrófono antes de volver (para que otro reconocedor pueda usarlo). */
    fun stop() {
        running = false
        try { thread?.join(600) } catch (_: Exception) {}
        thread = null
    }

    private fun fail(msg: String) {
        main.post { if (running) { running = false; onFail(msg) } }
    }

    private fun loop(dir: File) {
        var rec: AudioRecord? = null
        var r: Recognizer? = null
        var agc: AutomaticGainControl? = null
        try {
            val m = model(dir)
            r = Recognizer(m, 16000f)
            val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 16000)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) { fail("el micrófono está ocupado"); return }
            // Control automático de ganancia del propio teléfono (si lo tiene)
            try {
                if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(rec.audioSessionId)?.also { it.enabled = true }
            } catch (_: Throwable) {}
            rec.startRecording()
            val buf = ShortArray(1600)
            var lastPartial = ""
            var env = 0f      // volumen reciente (decae solo)
            var gain = 6f     // amplificación por software: permite hablar desde lejos
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) { fail("error de audio ($n)"); break }
                if (n == 0) continue
                var peak = 0
                for (i in 0 until n) { val a = Math.abs(buf[i].toInt()); if (a > peak) peak = a }
                env = Math.max(peak.toFloat(), env * 0.97f)
                val want = if (env < 120f) 8f else (9000f / env).coerceIn(1.5f, 16f)
                gain += (want - gain) * 0.25f
                for (i in 0 until n) buf[i] = (buf[i] * gain).toInt().coerceIn(-32768, 32767).toShort()
                val lvl = (peak * gain / 12000f).coerceIn(0f, 1f)
                main.post { if (running) onLevel(lvl) }
                if (r.acceptWaveForm(buf, n)) {
                    val t = JSONObject(r.result).optString("text")
                    lastPartial = ""
                    if (t.isNotBlank()) main.post { if (running) onFinal(t) }
                } else {
                    val p = JSONObject(r.partialResult).optString("partial")
                    if (p.isNotBlank() && p != lastPartial) {
                        lastPartial = p
                        main.post { if (running) onPartial(p) }
                    }
                }
            }
        } catch (e: Throwable) {
            fail("fallo del motor de voz: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            try { agc?.release() } catch (_: Exception) {}
            try { rec?.stop() } catch (_: Exception) {}
            try { rec?.release() } catch (_: Exception) {}
            try { r?.close() } catch (_: Exception) {}
        }
    }

    companion object {
        private var cached: Model? = null
        private var cachedPath = ""

        @Synchronized
        private fun model(dir: File): Model {
            val c = cached
            if (c != null && cachedPath == dir.absolutePath) return c
            try { cached?.close() } catch (_: Exception) {}
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            val m = Model(dir.absolutePath)
            cached = m
            cachedPath = dir.absolutePath
            return m
        }

        /** Libera la memoria del modelo (unos 300 MB) cuando el servicio se detiene. */
        @Synchronized
        fun release() {
            try { cached?.close() } catch (_: Exception) {}
            cached = null
            cachedPath = ""
        }
    }
}
