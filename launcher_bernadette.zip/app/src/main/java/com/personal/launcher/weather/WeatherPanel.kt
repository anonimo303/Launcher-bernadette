package com.personal.launcher.weather

import android.app.ActivityManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.animation.ValueAnimator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.personal.launcher.Motion
import com.personal.launcher.Prefs
import com.personal.launcher.R

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val STALE_MS = 30L * 60L * 1000L
private const val RETRY_MS = 60L * 1000L

/** ScrollView que avisa al cristal cuando se desplaza (el fondo se queda quieto y el panel se mueve). */
private class GlassScroll(ctx: Context, private val bd: WxBackdrop) : ScrollView(ctx) {
    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        bd.refresh()
    }
}

/**
 * Sección «Clima» de VERDANT. Es una pantalla más del launcher (misma mecánica que «Recursos»):
 * el lanzador llama a [start] / [stop] según sea visible y a [onBack] con el botón atrás.
 *
 *  · Pantalla principal: ciudad, temperatura, estado, sensación, máx/mín, viento, humedad, lluvia
 *    y tarjetas de los próximos días.
 *  · Detalle de un día: esfera meteorológica 3D, indicadores y pronóstico extendido.
 *  · Ubicación: búsqueda de ciudad/pueblo (la primera vez y desde el engranaje).
 *
 * Datos reales de Open-Meteo. Solo hay animaciones y red mientras la sección es visible.
 */
class WeatherPanel(ctx: Context) : FrameLayout(ctx) {

    init {
        // Aísla el módulo del fondo del launcher durante gestos y animaciones internas.
        clipChildren = true
        clipToPadding = true
        isFocusable = true
        isClickable = true
        overScrollMode = View.OVER_SCROLL_NEVER
    }

    private val bd = WxBackdrop()
    private val bg = WeatherBackground(ctx, bd)
    private val handler = Handler(Looper.getMainLooper())
    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    // ---- estado ----
    private var place: WxPlace? = WeatherStore.place(ctx)
    private var report: WxReport? = null
    private var running = false
    private var fetching = false
    private var lastTry = 0L
    private var lastError = false
    private var quality = 2
    private var slow = 0
    private var topInset = 0
    private var bottomInset = 0

    private var detailShown = false
    private var detailIdx = 0
    private var busy = false
    private var setupShown = false
    private var extOpen = false
    private var extDirty = true
    private var sKind = WxKind.CLOUDY
    private var sNight = false
    private var sLevel = 2

    private val clock = WxClock({ if (quality >= 2) 30 else 22 }) { dt -> onFrame(dt) }

    // ---- pantalla principal ----
    private val homeScroll = GlassScroll(ctx, bd)
    private val homeCol = LinearLayout(ctx)
    private val headerIcon = WxIconView(ctx)
    private val tvCity = TextView(ctx)
    private val btnRefresh = ImageView(ctx)
    private val nowIcon = WxIconView(ctx)
    private val tvTemp = TextView(ctx)
    private val tvState = TextView(ctx)
    private val tvFeels = TextView(ctx)
    private val tvMaxMin = TextView(ctx)
    private val tvWind = TextView(ctx)
    private val tvHum = TextView(ctx)
    private val tvRain = TextView(ctx)
    private val tvStatus = TextView(ctx)
    private val cards = ArrayList<DayCard>()

    // ---- detalle ----
    private val detailRoot = FrameLayout(ctx)
    private val detailScroll = GlassScroll(ctx, bd)
    private val detailCol = LinearLayout(ctx)
    private val sphere = WxSphere(ctx)
    private val sphereBox = FrameLayout(ctx)
    private val sphereText = LinearLayout(ctx)
    private val tvDayTitle = TextView(ctx)
    private val tvDayDate = TextView(ctx)
    private val tvNote = TextView(ctx)
    private val tvDTemp = TextView(ctx)
    private val tvCond = TextView(ctx)
    private val tvDFeels = TextView(ctx)
    private val tvDWind = TextView(ctx)
    private val tvDWindLbl = TextView(ctx)
    private val tvDHum = TextView(ctx)
    private val tvDRain = TextView(ctx)
    private val tvDMax = TextView(ctx)
    private val tvDMin = TextView(ctx)
    private val tvDesc = TextView(ctx)
    private val extList = LinearLayout(ctx)
    private val stagger = ArrayList<View>()
    private val hoursPanel = LinearLayout(ctx)
    private val hoursScroll = HorizontalScrollView(ctx)
    private val hoursRow = LinearLayout(ctx)

    // ---- ubicación ----
    private val setupRoot = FrameLayout(ctx)
    private val setupCol = LinearLayout(ctx)
    private val tvSetupTitle = TextView(ctx)
    private val tvSetupSub = TextView(ctx)
    private val btnSetupBack = ImageView(ctx)
    private val searchField = EditText(ctx)
    private val tvSearchStatus = TextView(ctx)
    private val resultsCol = LinearLayout(ctx)
    private var searchSeq = 0
    private val searchRun = Runnable { doSearch(searchField.text.toString()) }

    init {
        buildHome()
        buildDetail()
        buildSetup()
        // orden: fondo, pantalla principal, detalle, ubicación
        addView(bg, 0, LayoutParams(MATCH, MATCH))
        addView(homeScroll, LayoutParams(MATCH, MATCH))
        addView(detailRoot, LayoutParams(MATCH, MATCH))
        addView(setupRoot, LayoutParams(MATCH, MATCH))
        detailRoot.visibility = View.GONE
        setupRoot.visibility = View.GONE
        applyInsets()
        val p = place
        if (p == null) {
            showSetup(false)
        } else {
            report = WeatherStore.loadCache(ctx, p)
            bind()
        }
    }

    // ================================================================ utilidades de interfaz

    private fun dp(v: Float): Int = context.dpi(v)
    private fun dp(v: Int): Int = context.dpi(v.toFloat())

    private fun glass(v: View, radius: Float, level: Int = 1): GlassDrawable {
        val g = GlassDrawable(v, bd, context.dpf(radius), level)
        v.background = g
        bd.glass.add(v)
        return g
    }

    private fun style(t: TextView, text: CharSequence, sp: Float, color: Int = WxC.TEXT, bold: Boolean = false): TextView {
        t.text = text
        t.textSize = sp
        t.setTextColor(color)
        t.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        t.includeFontPadding = false
        return t
    }

    private fun tv(text: CharSequence, sp: Float, color: Int = WxC.TEXT, bold: Boolean = false): TextView =
        style(TextView(context), text, sp, color, bold)

    private fun icon(res: Int, sizeDp: Int, tint: Int): ImageView {
        val v = ImageView(context)
        v.setImageResource(res)
        v.imageTintList = ColorStateList.valueOf(tint)
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

    private fun press(v: View, onClick: () -> Unit) {
        v.isClickable = true
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(170).start()
                else -> {}
            }
            false
        }
        v.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onClick()
        }
    }

    private fun circleButton(res: Int, desc: String, onClick: () -> Unit): ImageView {
        val b = ImageView(context)
        b.setImageResource(res)
        b.imageTintList = ColorStateList.valueOf(WxC.TEXT)
        val pad = dp(11)
        b.setPadding(pad, pad, pad, pad)
        glass(b, 18f, 0)
        b.contentDescription = desc
        press(b, onClick)
        return b
    }

    private fun divider(vertical: Boolean): View {
        val v = View(context)
        val g = GradientDrawable(
            if (vertical) GradientDrawable.Orientation.TOP_BOTTOM else GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0x006AA8FF, 0x996AA8FF.toInt(), 0x006AA8FF)
        )
        v.background = g
        return v
    }

    private fun bigTemp(v: Double): CharSequence {
        val n = WxText.temp(v)
        val s = SpannableString("$n °C")
        s.setSpan(RelativeSizeSpan(0.42f), n.length, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        return s
    }

    private fun neon(t: TextView, color: Int, radiusDp: Float = 12f): TextView {
        t.setShadowLayer(context.dpf(radiusDp), 0f, 0f, color)
        return t
    }

    // ================================================================ construcción: pantalla principal

    private inner class DayCard(val index: Int) {
        val root = LinearLayout(context)
        val label = tv("—", 14f, WxC.TEXT, true)
        val icon = WxIconView(context)
        val hi = tv("—", 18f, WxC.TEXT, true)
        val lo = tv("—", 16f, WxC.SUB)
        val bgd: GlassDrawable

        init {
            root.orientation = LinearLayout.VERTICAL
            root.gravity = Gravity.CENTER_HORIZONTAL
            root.setPadding(dp(2), dp(12), dp(2), dp(12))
            bgd = glass(root, 26f, 0)
            label.gravity = Gravity.CENTER
            hi.gravity = Gravity.CENTER
            lo.gravity = Gravity.CENTER
            root.addView(label, lp(WRAP, WRAP))
            root.addView(icon, lp(dp(42), dp(42)).apply { topMargin = dp(8); bottomMargin = dp(10) })
            root.addView(hi, lp(WRAP, WRAP))
            root.addView(lo, lp(WRAP, WRAP).apply { topMargin = dp(2) })
            press(root) { openDay(index, root) }
        }
    }

    private inner class Stat(res: Int, tint: Int, label: String, val value: TextView) {
        val root = LinearLayout(context)

        init {
            root.orientation = LinearLayout.HORIZONTAL
            root.gravity = Gravity.CENTER
            root.addView(icon(res, 28, tint))
            val col = LinearLayout(context)
            col.orientation = LinearLayout.VERTICAL
            style(value, "—", 17f, WxC.TEXT, true)
            col.addView(value, lp(WRAP, WRAP))
            col.addView(tv(label, 13f, WxC.SUB), lp(WRAP, WRAP).apply { topMargin = dp(2) })
            root.addView(col, lp(WRAP, WRAP).apply { leftMargin = dp(8) })
        }
    }

    private fun buildHome() {
        homeScroll.isVerticalScrollBarEnabled = false
        homeScroll.overScrollMode = View.OVER_SCROLL_NEVER
        homeCol.orientation = LinearLayout.VERTICAL
        homeScroll.addView(homeCol, FrameLayout.LayoutParams(MATCH, WRAP))

        // --- cabecera ---
        val header = LinearLayout(context)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(16), dp(10), dp(14), dp(10))
        glass(header, 28f)
        headerIcon.set(WxKind.PARTLY, false)
        header.addView(headerIcon, lp(dp(54), dp(54)))
        val titles = LinearLayout(context)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(neon(tv("Clima", 30f, WxC.TEXT, true), 0x228C6CFF.toInt(), 6f), lp(WRAP, WRAP))
        titles.addView(tv("Pronóstico meteorológico", 14f, WxC.SUB), lp(WRAP, WRAP).apply { topMargin = dp(3) })
        header.addView(titles, lp(0, WRAP, 1f).apply { leftMargin = dp(12) })
        header.addView(circleButton(R.drawable.wx_ic_gear, "Cambiar ubicación") { openSetup() }, lp(dp(46), dp(46)))
        homeCol.addView(header, lp(MATCH, WRAP))

        // --- tarjeta del clima actual ---
        val card = LinearLayout(context)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(18), dp(16), dp(18), dp(14))
        glass(card, 30f)

        val r1 = LinearLayout(context)
        r1.orientation = LinearLayout.HORIZONTAL
        r1.gravity = Gravity.CENTER_VERTICAL
        r1.addView(icon(R.drawable.wx_ic_pin, 24, WxC.VIOLET))
        style(tvCity, "—", 22f, WxC.TEXT, true)
        tvCity.setSingleLine()
        tvCity.ellipsize = TextUtils.TruncateAt.END
        r1.addView(tvCity, lp(0, WRAP, 1f).apply { leftMargin = dp(8) })
        btnRefresh.setImageResource(R.drawable.wx_ic_refresh)
        btnRefresh.imageTintList = ColorStateList.valueOf(WxC.CYAN)
        btnRefresh.setPadding(dp(8), dp(8), dp(8), dp(8))
        btnRefresh.contentDescription = "Actualizar"
        press(btnRefresh) { refresh(true) }
        r1.addView(btnRefresh, lp(dp(40), dp(40)))
        card.addView(r1, lp(MATCH, WRAP))

        val r2 = LinearLayout(context)
        r2.orientation = LinearLayout.HORIZONTAL
        r2.gravity = Gravity.CENTER_VERTICAL
        r2.addView(nowIcon, lp(dp(124), dp(124)))
        val c2 = LinearLayout(context)
        c2.orientation = LinearLayout.VERTICAL
        c2.gravity = Gravity.CENTER_VERTICAL
        style(tvTemp, "—", 66f, WxC.TEXT, false)
        tvTemp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        neon(tvTemp, 0x336A8CFF.toInt(), 10f)
        c2.addView(tvTemp, lp(WRAP, WRAP))
        style(tvState, "—", 18f, WxC.TEXT, true)
        c2.addView(tvState, lp(WRAP, WRAP).apply { topMargin = dp(4) })
        val fr = LinearLayout(context)
        fr.orientation = LinearLayout.HORIZONTAL
        fr.gravity = Gravity.CENTER_VERTICAL
        fr.addView(icon(R.drawable.wx_ic_thermo, 18, WxC.VIOLET))
        style(tvFeels, "—", 14f, WxC.SUB)
        fr.addView(tvFeels, lp(WRAP, WRAP).apply { leftMargin = dp(6) })
        c2.addView(fr, lp(WRAP, WRAP).apply { topMargin = dp(6) })
        style(tvMaxMin, "—", 14f, WxC.SUB)
        tvMaxMin.visibility = View.GONE   // la referencia no muestra Máx/Mín en la pantalla principal
        c2.addView(tvMaxMin, lp(WRAP, WRAP).apply { topMargin = dp(4) })
        r2.addView(c2, lp(0, WRAP, 1f).apply { leftMargin = dp(4) })
        card.addView(r2, lp(MATCH, WRAP).apply { topMargin = dp(4) })

        card.addView(divider(false), lp(MATCH, dp(1)).apply { topMargin = dp(8); bottomMargin = dp(12) })

        val r4 = LinearLayout(context)
        r4.orientation = LinearLayout.HORIZONTAL
        r4.gravity = Gravity.CENTER_VERTICAL
        r4.addView(Stat(R.drawable.wx_ic_wind, WxC.BLUE, "Viento", tvWind).root, lp(0, WRAP, 1f))
        r4.addView(divider(true), lp(dp(1), dp(34)))
        r4.addView(Stat(R.drawable.wx_ic_drop, WxC.CYAN, "Humedad", tvHum).root, lp(0, WRAP, 1f))
        r4.addView(divider(true), lp(dp(1), dp(34)))
        r4.addView(Stat(R.drawable.wx_ic_umbrella, WxC.BLUE, "Lluvia", tvRain).root, lp(0, WRAP, 1f))
        card.addView(r4, lp(MATCH, WRAP))
        homeCol.addView(card, lp(MATCH, WRAP).apply { topMargin = dp(14) })

        // --- próximos días ---
        val fc = LinearLayout(context)
        fc.orientation = LinearLayout.VERTICAL
        fc.setPadding(dp(14), dp(14), dp(14), dp(14))
        glass(fc, 30f)
        val th = LinearLayout(context)
        th.orientation = LinearLayout.HORIZONTAL
        th.gravity = Gravity.CENTER_VERTICAL
        th.addView(icon(R.drawable.wx_ic_calendar, 24, WxC.VIOLET))
        th.addView(tv("Pronóstico de los próximos días", 16f, WxC.TEXT, true), lp(WRAP, WRAP).apply { leftMargin = dp(10) })
        fc.addView(th, lp(MATCH, WRAP).apply { leftMargin = dp(2); bottomMargin = dp(12) })

        val days = LinearLayout(context)
        days.orientation = LinearLayout.HORIZONTAL
        for (i in 0 until 5) {
            val dc = DayCard(i)
            cards.add(dc)
            days.addView(dc.root, lp(0, WRAP, 1f).apply { leftMargin = dp(3); rightMargin = dp(3) })
        }
        fc.addView(days, lp(MATCH, WRAP))

        val hint = LinearLayout(context)
        hint.orientation = LinearLayout.HORIZONTAL
        hint.gravity = Gravity.CENTER_VERTICAL
        hint.setPadding(dp(16), dp(12), dp(12), dp(12))
        glass(hint, 26f, 2)
        hint.addView(icon(R.drawable.wx_ic_tap, 24, WxC.VIOLET))
        val ht = tv("Toca un día para ver más detalles", 14f, WxC.SUB)
        ht.setSingleLine()
        ht.ellipsize = TextUtils.TruncateAt.END
        hint.addView(ht, lp(0, WRAP, 1f).apply { leftMargin = dp(10) })
        hint.addView(icon(R.drawable.wx_ic_chev, 22, WxC.SUB))
        press(hint) { openDay(0, hint) }
        fc.addView(hint, lp(MATCH, WRAP).apply { topMargin = dp(12) })
        homeCol.addView(fc, lp(MATCH, WRAP).apply { topMargin = dp(14) })

        style(tvStatus, "", 12f, WxC.DIM)
        tvStatus.gravity = Gravity.CENTER
        homeCol.addView(tvStatus, lp(MATCH, WRAP).apply { topMargin = dp(12) })
    }

    // ================================================================ construcción: detalle

    private fun buildDetail() {
        detailScroll.isVerticalScrollBarEnabled = false
        detailScroll.overScrollMode = View.OVER_SCROLL_NEVER
        detailCol.orientation = LinearLayout.VERTICAL
        detailScroll.addView(detailCol, FrameLayout.LayoutParams(MATCH, WRAP))
        detailRoot.addView(detailScroll, FrameLayout.LayoutParams(MATCH, MATCH))

        // barra superior
        val bar = LinearLayout(context)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(10), dp(10), dp(10), dp(10))
        glass(bar, 28f)
        bar.addView(circleButton(R.drawable.wx_ic_back, "Volver") { closeDay() }, lp(dp(46), dp(46)))
        val tt = LinearLayout(context)
        tt.orientation = LinearLayout.VERTICAL
        tt.gravity = Gravity.CENTER
        style(tvDayTitle, "—", 22f, WxC.TEXT, true)
        style(tvDayDate, "—", 14f, WxC.SUB)
        tt.addView(tvDayTitle, lp(WRAP, WRAP))
        tt.addView(tvDayDate, lp(WRAP, WRAP).apply { topMargin = dp(3) })
        bar.addView(tt, lp(0, WRAP, 1f))
        bar.addView(circleButton(R.drawable.wx_ic_calendar, "Pronóstico extendido") { toggleExt() }, lp(dp(46), dp(46)))
        detailCol.addView(bar, lp(MATCH, WRAP))
        stagger.add(bar)

        // esfera + temperatura
        sphereBox.addView(sphere, FrameLayout.LayoutParams(MATCH, MATCH))
        sphereText.orientation = LinearLayout.VERTICAL
        sphereText.gravity = Gravity.CENTER_HORIZONTAL
        style(tvNote, "", 12f, WxC.SUB)
        tvNote.visibility = View.GONE
        style(tvDTemp, "—", 62f, WxC.TEXT, false)
        tvDTemp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        neon(tvDTemp, 0x554F7CFF.toInt(), 10f)
        style(tvCond, "—", 17f, WxC.TEXT, true)
        neon(tvCond, 0xAA000020.toInt(), 6f)
        sphereText.addView(tvNote, lp(WRAP, WRAP))
        sphereText.addView(tvDTemp, lp(WRAP, WRAP))
        sphereText.addView(tvCond, lp(WRAP, WRAP).apply { topMargin = dp(2) })
        sphereBox.addView(sphereText, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        sphereBox.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            // el texto queda en la mitad inferior de la esfera (como en el diseño de referencia)
            sphereText.translationY = minOf(r - l, b - t) * 0.35f * 0.42f
        }
        detailCol.addView(sphereBox, lp(MATCH, dp(310)).apply { topMargin = dp(6) })

        // sensación térmica
        val feels = LinearLayout(context)
        feels.orientation = LinearLayout.HORIZONTAL
        feels.gravity = Gravity.CENTER_VERTICAL
        feels.setPadding(dp(22), dp(10), dp(26), dp(10))
        glass(feels, 30f, 2)
        feels.addView(icon(R.drawable.wx_ic_thermo, 32, WxC.VIOLET))
        val fcol = LinearLayout(context)
        fcol.orientation = LinearLayout.VERTICAL
        fcol.addView(tv("Sensación térmica", 14f, WxC.SUB), lp(WRAP, WRAP))
        style(tvDFeels, "—", 22f, WxC.TEXT, true)
        fcol.addView(tvDFeels, lp(WRAP, WRAP).apply { topMargin = dp(2) })
        feels.addView(fcol, lp(WRAP, WRAP).apply { leftMargin = dp(12) })
        detailCol.addView(feels, lp(WRAP, WRAP).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(2) })
        stagger.add(feels)

        // viento / humedad / lluvia
        val stats = LinearLayout(context)
        stats.orientation = LinearLayout.HORIZONTAL
        fun tile(res: Int, tint: Int, value: TextView, label: TextView): LinearLayout {
            val t = LinearLayout(context)
            t.orientation = LinearLayout.VERTICAL
            t.gravity = Gravity.CENTER_HORIZONTAL
            t.setPadding(dp(4), dp(14), dp(4), dp(12))
            glass(t, 26f, 0)
            t.addView(icon(res, 32, tint))
            style(value, "—", 20f, WxC.TEXT, true)
            value.gravity = Gravity.CENTER
            t.addView(value, lp(WRAP, WRAP).apply { topMargin = dp(8) })
            label.gravity = Gravity.CENTER
            t.addView(label, lp(WRAP, WRAP).apply { topMargin = dp(3) })
            return t
        }
        style(tvDWindLbl, "Viento", 13f, WxC.SUB)
        stats.addView(tile(R.drawable.wx_ic_wind, WxC.BLUE, tvDWind, tvDWindLbl), lp(0, WRAP, 1f).apply { rightMargin = dp(5) })
        stats.addView(tile(R.drawable.wx_ic_drop, WxC.CYAN, tvDHum, tv("Humedad", 13f, WxC.SUB)), lp(0, WRAP, 1f).apply { leftMargin = dp(5); rightMargin = dp(5) })
        stats.addView(tile(R.drawable.wx_ic_umbrella, WxC.BLUE, tvDRain, tv("Prob. de lluvia", 13f, WxC.SUB)), lp(0, WRAP, 1f).apply { leftMargin = dp(5) })
        detailCol.addView(stats, lp(MATCH, WRAP).apply { topMargin = dp(12) })
        stagger.add(stats)

        // máxima / mínima
        val mm = LinearLayout(context)
        mm.orientation = LinearLayout.HORIZONTAL
        mm.gravity = Gravity.CENTER_VERTICAL
        mm.setPadding(dp(10), dp(12), dp(10), dp(12))
        glass(mm, 26f, 0)
        fun half(res: Int, tint: Int, label: String, value: TextView): LinearLayout {
            val h = LinearLayout(context)
            h.orientation = LinearLayout.HORIZONTAL
            h.gravity = Gravity.CENTER
            h.addView(icon(res, 30, tint))
            val c = LinearLayout(context)
            c.orientation = LinearLayout.VERTICAL
            c.addView(tv(label, 14f, WxC.SUB), lp(WRAP, WRAP))
            style(value, "—", 22f, WxC.TEXT, true)
            c.addView(value, lp(WRAP, WRAP).apply { topMargin = dp(2) })
            h.addView(c, lp(WRAP, WRAP).apply { leftMargin = dp(8) })
            return h
        }
        mm.addView(half(R.drawable.wx_ic_up, WxC.HOT, "Máxima", tvDMax), lp(0, WRAP, 1f))
        mm.addView(divider(true), lp(dp(1), dp(40)))
        mm.addView(half(R.drawable.wx_ic_down, WxC.CYAN, "Mínima", tvDMin), lp(0, WRAP, 1f))
        detailCol.addView(mm, lp(MATCH, WRAP).apply { topMargin = dp(10) })
        stagger.add(mm)

        // descripción
        val desc = LinearLayout(context)
        desc.orientation = LinearLayout.HORIZONTAL
        desc.setPadding(dp(14), dp(14), dp(14), dp(14))
        glass(desc, 26f, 0)
        val badge = FrameLayout(context)
        val bgOval = GradientDrawable()
        bgOval.shape = GradientDrawable.OVAL
        bgOval.setColor(0xFF7A4CFF.toInt())
        badge.background = bgOval
        val bi = ImageView(context)
        bi.setImageResource(R.drawable.wx_ic_info)
        bi.imageTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
        badge.addView(bi, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        desc.addView(badge, lp(dp(34), dp(34)))
        val dcol = LinearLayout(context)
        dcol.orientation = LinearLayout.VERTICAL
        dcol.addView(tv("Detalles del clima", 16f, WxC.TEXT, true), lp(WRAP, WRAP))
        style(tvDesc, "", 14f, WxC.SUB)
        tvDesc.setLineSpacing(0f, 1.15f)
        dcol.addView(tvDesc, lp(MATCH, WRAP).apply { topMargin = dp(6) })
        desc.addView(dcol, lp(0, WRAP, 1f).apply { leftMargin = dp(12) })
        detailCol.addView(desc, lp(MATCH, WRAP).apply { topMargin = dp(10) })
        stagger.add(desc)

        // pronóstico por horas (desliza hacia la derecha: pasa de un día al siguiente)
        hoursPanel.orientation = LinearLayout.VERTICAL
        hoursPanel.setPadding(dp(14), dp(14), dp(10), dp(14))
        glass(hoursPanel, 28f, 1)
        val hhead = LinearLayout(context)
        hhead.orientation = LinearLayout.HORIZONTAL
        hhead.gravity = Gravity.CENTER_VERTICAL
        hhead.addView(icon(R.drawable.wx_ic_clock, 24, WxC.VIOLET))
        hhead.addView(tv("Pronóstico por horas", 16f, WxC.TEXT, true), lp(WRAP, WRAP).apply { leftMargin = dp(10) })
        hoursPanel.addView(hhead, lp(MATCH, WRAP))
        hoursScroll.isHorizontalScrollBarEnabled = false
        hoursScroll.overScrollMode = View.OVER_SCROLL_NEVER
        hoursRow.orientation = LinearLayout.HORIZONTAL
        hoursScroll.addView(hoursRow, FrameLayout.LayoutParams(WRAP, WRAP))
        hoursPanel.addView(hoursScroll, lp(MATCH, WRAP).apply { topMargin = dp(12) })
        detailCol.addView(hoursPanel, lp(MATCH, WRAP).apply { topMargin = dp(10) })
        stagger.add(hoursPanel)

        // pronóstico extendido
        val ext = LinearLayout(context)
        ext.orientation = LinearLayout.HORIZONTAL
        ext.gravity = Gravity.CENTER
        ext.setPadding(dp(16), dp(14), dp(16), dp(14))
        glass(ext, 30f, 2)
        ext.addView(icon(R.drawable.wx_ic_chart, 24, WxC.VIOLET))
        ext.addView(tv("Pronóstico extendido", 16f, WxC.TEXT, true), lp(WRAP, WRAP).apply { leftMargin = dp(10) })
        press(ext) { toggleExt() }
        detailCol.addView(ext, lp(MATCH, WRAP).apply { topMargin = dp(12) })
        stagger.add(ext)

        extList.orientation = LinearLayout.VERTICAL
        extList.visibility = View.GONE
        detailCol.addView(extList, lp(MATCH, WRAP).apply { topMargin = dp(8) })
    }

    // ================================================================ construcción: ubicación

    private fun buildSetup() {
        setupCol.orientation = LinearLayout.VERTICAL
        setupRoot.addView(setupCol, FrameLayout.LayoutParams(MATCH, MATCH))

        val bar = LinearLayout(context)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(10), dp(10), dp(14), dp(10))
        glass(bar, 28f)
        btnSetupBack.setImageResource(R.drawable.wx_ic_back)
        btnSetupBack.imageTintList = ColorStateList.valueOf(WxC.TEXT)
        btnSetupBack.setPadding(dp(11), dp(11), dp(11), dp(11))
        glass(btnSetupBack, 23f, 0)
        btnSetupBack.contentDescription = "Volver"
        press(btnSetupBack) { closeSetup() }
        bar.addView(btnSetupBack, lp(dp(46), dp(46)).apply { rightMargin = dp(10) })
        val tt = LinearLayout(context)
        tt.orientation = LinearLayout.VERTICAL
        style(tvSetupTitle, "Ubicación", 24f, WxC.TEXT, true)
        style(tvSetupSub, "Elige tu ciudad o pueblo", 14f, WxC.SUB)
        tt.addView(tvSetupTitle, lp(WRAP, WRAP))
        tt.addView(tvSetupSub, lp(WRAP, WRAP).apply { topMargin = dp(3) })
        bar.addView(tt, lp(0, WRAP, 1f).apply { leftMargin = dp(4) })
        setupCol.addView(bar, lp(MATCH, WRAP))

        val box = LinearLayout(context)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(16), dp(4), dp(8), dp(4))
        glass(box, 28f)
        box.addView(icon(R.drawable.wx_ic_search, 22, WxC.VIOLET))
        searchField.hint = "Busca tu ciudad o pueblo"
        searchField.setHintTextColor(WxC.DIM)
        searchField.setTextColor(WxC.TEXT)
        searchField.textSize = 17f
        searchField.setSingleLine()
        searchField.background = null
        searchField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        searchField.imeOptions = EditorInfo.IME_ACTION_SEARCH
        searchField.setPadding(dp(10), dp(12), dp(6), dp(12))
        box.addView(searchField, lp(0, WRAP, 1f))
        val clear = icon(R.drawable.wx_ic_close, 40, WxC.SUB)
        clear.setPadding(dp(10), dp(10), dp(10), dp(10))
        clear.contentDescription = "Borrar"
        clear.setOnClickListener { searchField.setText("") }
        box.addView(clear)
        setupCol.addView(box, lp(MATCH, WRAP).apply { topMargin = dp(14) })

        style(tvSearchStatus, "", 14f, WxC.SUB)
        tvSearchStatus.setLineSpacing(0f, 1.15f)
        setupCol.addView(tvSearchStatus, lp(MATCH, WRAP).apply { topMargin = dp(14); leftMargin = dp(6); rightMargin = dp(6) })

        val sc = GlassScroll(context, bd)
        sc.isVerticalScrollBarEnabled = false
        sc.overScrollMode = View.OVER_SCROLL_NEVER
        resultsCol.orientation = LinearLayout.VERTICAL
        sc.addView(resultsCol, FrameLayout.LayoutParams(MATCH, WRAP))
        setupCol.addView(sc, lp(MATCH, 0, 1f).apply { topMargin = dp(6) })

        searchField.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(searchRun)
                val q = s?.toString()?.trim() ?: ""
                searchSeq++
                if (q.length >= 2) {
                    handler.postDelayed(searchRun, 450L)
                } else {
                    resultsCol.removeAllViews()
                    tvSearchStatus.text = defaultSearchHint()
                }
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        searchField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                handler.removeCallbacks(searchRun)
                val q = searchField.text.toString().trim()
                if (q.length >= 2) doSearch(q)
                hideKeyboard()
            }
            true
        }
    }

    private fun defaultSearchHint(): String =
        if (place == null) "Escribe el nombre de tu ciudad o pueblo para ver su pronóstico real. Se guardará en tu teléfono y no tendrás que repetirlo."
        else "Ubicación actual: ${place?.name}. Escribe otra ciudad o pueblo para cambiarla."

    // ================================================================ márgenes (barra de estado / barra de navegación)

    fun setTopInset(px: Int) {
        topInset = px
        applyInsets()
    }

    fun setBottomInset(px: Int) {
        bottomInset = px
        applyInsets()
    }

    private fun applyInsets() {
        val l = dp(16)
        val t = dp(16) + topInset
        val b = bottomInset + dp(16)
        homeCol.setPadding(l, t, l, b)
        detailCol.setPadding(l, t, l, b)
        setupCol.setPadding(l, t, l, b)
    }

    // ================================================================ ciclo de vida (lo llama el launcher)

    private fun computeQuality(): Int = when {
        Prefs.bool(context, "perf_save", false) || !ValueAnimator.areAnimatorsEnabled() -> 0
        am.isLowRamDevice -> 1
        else -> 2
    }

    private fun applyQuality() {
        bg.quality = quality
        sphere.quality = quality
        if (detailShown) sphere.setWeather(sKind, sNight, sLevel)
    }

    /** La sección pasa a ser visible: arranca el reloj de animación y refresca los datos si caducaron. */
    fun start() {
        if (running) return
        running = true
        quality = computeQuality()
        slow = 0
        applyQuality()
        if (place != null) refresh(false)
        if (quality > 0) clock.start()
    }

    /** La sección ya no es visible: se detiene TODO (animaciones 3D incluidas). */
    fun stop() {
        if (!running) return
        running = false
        clock.stop()
    }

    /** Botón «atrás». Devuelve true si Clima se encargó (cerró el detalle o la búsqueda). */
    fun onBack(): Boolean {
        if (setupShown) {
            if (place != null) {
                closeSetup()
                return true
            }
            return false
        }
        if (detailShown) {
            if (!busy) closeDay()
            return true
        }
        return false
    }

    override fun onDetachedFromWindow() {
        stop()
        handler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    private fun onFrame(dt: Float) {
        bg.tick(dt)
        if (detailShown) sphere.tick(dt)
        // Si el teléfono no da el ancho, se baja a efectos más ligeros (nunca al revés).
        val target = 1f / (if (quality >= 2) 30f else 22f)
        if (dt > target * 1.45f) slow++ else if (slow > 0) slow--
        if (slow > 30 && quality >= 2) {
            quality = 1
            slow = 0
            applyQuality()
        }
    }

    // ================================================================ datos

    private fun stale(): Boolean {
        val r = report ?: return true
        return System.currentTimeMillis() - r.fetchedAt > STALE_MS
    }

    private fun refresh(force: Boolean) {
        val p = place ?: return
        if (fetching) return
        val now = System.currentTimeMillis()
        if (!force && (!stale() || now - lastTry < RETRY_MS)) return
        fetching = true
        lastTry = now
        setRefreshing()
        bindStatus()
        val app = context.applicationContext
        Thread {
            var rep: WxReport? = null
            try {
                val raw = WeatherApi.forecast(p)
                val at = System.currentTimeMillis()
                rep = WxParser.parse(p, raw, at)
                WeatherStore.saveCache(app, p, raw, at)
            } catch (e: Exception) {
                rep = null
            }
            val result = rep
            handler.post {
                fetching = false
                if (!p.same(place)) {          // el usuario cambió de ciudad mientras tanto
                    refresh(true)
                    return@post
                }
                if (result != null) {
                    report = result
                    lastError = false
                    extDirty = true
                    bind()
                } else {
                    lastError = true
                    bindStatus()
                }
            }
        }.start()
    }

    private val spinRun = object : Runnable {
        override fun run() {
            if (!fetching) {
                btnRefresh.rotation = 0f
                return
            }
            btnRefresh.animate().rotationBy(360f).setDuration(900L)
                .setInterpolator(LinearInterpolator()).withEndAction(this).start()
        }
    }

    private fun setRefreshing() {
        if (fetching) handler.post(spinRun)
    }

    private fun ago(at: Long): String {
        val m = ((System.currentTimeMillis() - at) / 60000L).toInt()
        return when {
            m < 1 -> "ahora mismo"
            m < 60 -> "hace $m min"
            m < 60 * 24 -> "hace ${m / 60} h"
            else -> "hace ${m / (60 * 24)} d"
        }
    }

    private fun bindStatus() {
        val r = report
        tvStatus.text = when {
            r == null && fetching -> "Cargando pronóstico…"
            r == null && lastError -> "No se pudo obtener el pronóstico. Revisa tu conexión y toca ↻ para reintentar."
            r == null -> ""
            fetching -> "Actualizando…"
            lastError -> "Sin conexión · mostrando datos de ${ago(r.fetchedAt)}"
            else -> ""
        }
    }

    /** Vuelca los datos reales en la pantalla principal (y en el detalle si está abierto). */
    private fun bind() {
        val p = place
        tvCity.text = p?.name ?: "—"
        val r = report
        if (p == null || r == null) {
            tvTemp.text = bigTemp(Double.NaN)
            tvState.text = "—"
            tvFeels.text = "Sensación térmica: —"
            tvMaxMin.text = ""
            tvWind.text = "—"
            tvHum.text = "—"
            tvRain.text = "—"
            nowIcon.set(WxKind.CLOUDY, false)
            for (c in cards) {
                c.label.text = "—"; c.hi.text = "—"; c.lo.text = "—"
            }
            bindStatus()
            return
        }
        val n = r.now
        val d0 = r.days[0]
        val kind = Wmo.kind(n.code)
        tvTemp.text = bigTemp(n.temp)
        tvState.text = Wmo.text(n.code)
        tvFeels.text = "Sensación térmica: ${WxText.tempC(n.feels)}"
        tvMaxMin.text = "Máx ${WxText.deg(d0.tMax)}  ·  Mín ${WxText.deg(d0.tMin)}"
        tvWind.text = WxText.kmh(n.wind)
        tvHum.text = WxText.pct(n.humidity)
        tvRain.text = WxText.pct(d0.rainProb)
        nowIcon.set(kind, !n.isDay)
        headerIcon.set(kind, !n.isDay, false)
        for (c in cards) {
            val d = r.days.getOrNull(c.index)
            if (d == null) {
                c.root.visibility = View.INVISIBLE
                continue
            }
            c.root.visibility = View.VISIBLE
            c.label.text = WxText.dayShort(d.date)
            c.icon.set(Wmo.kind(d.code), false, false)
            c.hi.text = WxText.deg(d.tMax)
            c.lo.text = WxText.deg(d.tMin)
            c.bgd.emphasis = c.index == 0
        }
        bindStatus()
        if (detailShown) bindDetail(detailIdx) else bg.setMood(kind)
    }

    // ================================================================ detalle de un día

    private fun bindDetail(i: Int) {
        val r = report ?: return
        val d = r.days.getOrNull(i) ?: return
        val today = i == 0
        val code = if (today) r.now.code else d.code
        val kind = Wmo.kind(code)
        val night = today && !r.now.isDay

        tvDayTitle.text = WxText.dayLong(d.date)
        tvDayDate.text = WxText.dateLong(d.date)
        tvNote.text = ""
        tvDTemp.text = bigTemp(if (today) r.now.temp else d.tMax)
        tvCond.text = Wmo.text(code)
        tvDFeels.text = WxText.tempC(if (today) r.now.feels else d.feelMax)

        val wind = if (today) r.now.wind else d.wind
        val dir = if (today) r.now.windDir else d.windDir
        tvDWind.text = WxText.kmh(wind)
        tvDWindLbl.text = "Viento"
        tvDHum.text = WxText.pct(if (today) r.now.humidity else d.humidity)
        tvDRain.text = WxText.pct(d.rainProb)
        tvDMax.text = WxText.tempC(d.tMax)
        tvDMin.text = WxText.tempC(d.tMin)
        tvDesc.text = WxText.describe(d, kind)

        sKind = kind
        sNight = night
        sLevel = Wmo.intensity(code)
        sphere.quality = quality
        sphere.setWeather(sKind, sNight, sLevel)
        bg.setMood(kind)
        extDirty = extDirty || extOpen
        if (extOpen) buildExt()
        bindHours(i)
    }

    /**
     * Fila de horas del día elegido y de los siguientes. Hoy empieza en la hora actual del lugar
     * (18:32 → 18:00); otro día empieza a las 00:00. Al pasar de las 23:00 aparece el día siguiente
     * con su etiqueta y vuelve a las 00:00.
     */
    private fun bindHours(i: Int) {
        for (k in 0 until hoursRow.childCount) bd.glass.remove(hoursRow.getChildAt(k))
        hoursRow.removeAllViews()
        val r = report
        val d = r?.days?.getOrNull(i)
        if (r == null || d == null || r.hours.isEmpty()) {
            hoursPanel.visibility = View.GONE
            return
        }
        val nd = r.nowDate
        val startKey = if (i == 0 && nd != null && r.nowHour >= 0) nd.toEpochDay() * 24 + r.nowHour
        else d.date.toEpochDay() * 24
        val endKey = (d.date.toEpochDay() + 7) * 24
        var prev: java.time.LocalDate? = null
        var count = 0
        for (h in r.hours) {
            val key = h.date.toEpochDay() * 24 + h.hour
            if (key < startKey || key >= endKey) continue
            if (prev != null && h.date != prev) hoursRow.addView(dayChip(h.date), lp(dp(50), MATCH).apply { rightMargin = dp(8) })
            hoursRow.addView(hourCard(h, count == 0), lp(dp(64), WRAP).apply { rightMargin = dp(8) })
            prev = h.date
            count++
        }
        hoursPanel.visibility = if (count == 0) View.GONE else View.VISIBLE
        hoursScroll.post { hoursScroll.scrollTo(0, 0) }
    }

    private fun hourBackground(first: Boolean): GradientDrawable {
        val g = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x661C2C78, 0x880B0F48.toInt(), 0x8822127A.toInt())
        )
        g.cornerRadius = dp(24).toFloat()
        if (first) g.setStroke(dp(2), 0xFFB05CFF.toInt()) else g.setStroke(dp(1), 0x886A7CFF.toInt())
        return g
    }

    private fun hourCard(h: WxHour, first: Boolean): View {
        val root = LinearLayout(context)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(2), dp(10), dp(2), dp(10))
        root.background = hourBackground(first)
        root.addView(tv(String.format(java.util.Locale.US, "%02d:00", h.hour), 14f, WxC.TEXT, true), lp(WRAP, WRAP))
        val ic = WxIconView(context)
        ic.animated = false
        ic.set(Wmo.kind(h.code), !h.isDay, false)
        root.addView(ic, lp(dp(40), dp(40)).apply { topMargin = dp(6); bottomMargin = dp(6) })
        root.addView(tv(WxText.deg(h.temp), 18f, WxC.TEXT, true), lp(WRAP, WRAP))
        val rain = LinearLayout(context)
        rain.orientation = LinearLayout.HORIZONTAL
        rain.gravity = Gravity.CENTER
        rain.addView(icon(R.drawable.wx_ic_drop, 11, WxC.CYAN))
        rain.addView(tv(WxText.pct(h.rainProb), 12f, WxC.SUB), lp(WRAP, WRAP).apply { leftMargin = dp(2) })
        root.addView(rain, lp(WRAP, WRAP).apply { topMargin = dp(4) })
        return root
    }

    /** Separador de día dentro de la fila de horas («Vie» / «27»). */
    private fun dayChip(date: java.time.LocalDate): View {
        val root = LinearLayout(context)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.cornerRadius = dp(22).toFloat()
        g.setColor(0x557A4CFF)
        g.setStroke(dp(1), 0xFFA77BFF.toInt())
        root.background = g
        root.addView(tv(WxText.dayShort(date), 15f, WxC.VIOLET, true), lp(WRAP, WRAP))
        root.addView(tv(date.dayOfMonth.toString(), 20f, WxC.TEXT, true), lp(WRAP, WRAP).apply { topMargin = dp(2) })
        return root
    }

    private fun animScale(): Float = Prefs.animScale(context)
    private fun animOn(): Boolean = Prefs.animOn(context)

    private fun layersOn(on: Boolean) {
        val t = if (on) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE
        if (homeScroll.layerType != t) homeScroll.setLayerType(t, null)
        if (detailRoot.layerType != t) detailRoot.setLayerType(t, null)
    }

    private fun pivotOf(from: View?, out: FloatArray) {
        if (from != null && from.isAttachedToWindow) {
            val a = IntArray(2)
            val b = IntArray(2)
            from.getLocationInWindow(a)
            getLocationInWindow(b)
            out[0] = a[0] - b[0] + from.width / 2f
            out[1] = a[1] - b[1] + from.height / 2f
        } else {
            out[0] = width / 2f
            out[1] = height * 0.4f
        }
    }

    private val pivot = FloatArray(2)

    /** Abre el detalle de un día: la tarjeta «se expande» hasta convertirse en la pantalla de detalles. */
    private fun openDay(i: Int, from: View?) {
        val r = report ?: return
        if (busy || detailShown || setupShown || i !in r.days.indices) return
        detailIdx = i
        extOpen = false
        extList.visibility = View.GONE
        bindDetail(i)
        detailScroll.scrollTo(0, 0)
        detailShown = true
        detailRoot.visibility = View.VISIBLE
        sphere.invalidate()

        if (!animOn()) {
            homeScroll.visibility = View.INVISIBLE
            detailRoot.alpha = 1f
            detailRoot.scaleX = 1f
            detailRoot.scaleY = 1f
            return
        }
        busy = true
        val k = animScale()
        val dur = (560 * k).toLong()
        pivotOf(from, pivot)
        layersOn(true)
        detailRoot.pivotX = pivot[0]
        detailRoot.pivotY = pivot[1]
        detailRoot.alpha = 0f
        detailRoot.scaleX = 0.3f
        detailRoot.scaleY = 0.3f
        homeScroll.pivotX = pivot[0]
        homeScroll.pivotY = pivot[1]

        detailRoot.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0L)
            .setDuration(dur).setInterpolator(Motion.settle).withEndAction {
                homeScroll.visibility = View.INVISIBLE
                homeScroll.alpha = 1f
                homeScroll.scaleX = 1f
                homeScroll.scaleY = 1f
                layersOn(false)
                busy = false
            }.start()
        homeScroll.animate().alpha(0f).scaleX(1.12f).scaleY(1.12f).setStartDelay(0L)
            .setDuration((dur * 0.7f).toLong()).setInterpolator(Motion.inOut).start()

        // la esfera «emerge» y gira; los indicadores aparecen uno tras otro
        sphereBox.alpha = 0f
        sphereBox.scaleX = 0.65f
        sphereBox.scaleY = 0.65f
        sphereBox.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay((120 * k).toLong())
            .setDuration((620 * k).toLong()).setInterpolator(OvershootInterpolator(1.05f)).start()
        sphere.kick(5f)
        for ((idx, v) in stagger.withIndex()) {
            v.alpha = 0f
            v.translationY = dp(30).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(((200 + idx * 75) * k).toLong())
                .setDuration((420 * k).toLong()).setInterpolator(Motion.settle).start()
        }
    }

    private fun closeDay() {
        if (!detailShown || busy) return
        val r = report
        if (r != null) bg.setMood(Wmo.kind(r.now.code))
        if (!animOn()) {
            finishClose()
            return
        }
        busy = true
        val k = animScale()
        val dur = (480 * k).toLong()
        layersOn(true)
        homeScroll.visibility = View.VISIBLE
        homeScroll.alpha = 0f
        homeScroll.scaleX = 1.12f
        homeScroll.scaleY = 1.12f
        homeScroll.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0L)
            .setDuration(dur).setInterpolator(Motion.settle).start()
        detailRoot.animate().alpha(0f).scaleX(0.4f).scaleY(0.4f).setStartDelay(0L)
            .setDuration((dur * 0.8f).toLong()).setInterpolator(Motion.inOut).withEndAction {
                finishClose()
                layersOn(false)
            }.start()
    }

    private fun finishClose() {
        detailRoot.visibility = View.GONE
        detailRoot.alpha = 1f
        detailRoot.scaleX = 1f
        detailRoot.scaleY = 1f
        homeScroll.visibility = View.VISIBLE
        homeScroll.alpha = 1f
        homeScroll.scaleX = 1f
        homeScroll.scaleY = 1f
        for (v in stagger) {
            v.alpha = 1f
            v.translationY = 0f
        }
        sphereBox.alpha = 1f
        sphereBox.scaleX = 1f
        sphereBox.scaleY = 1f
        detailShown = false
        busy = false
        bg.invalidate()
    }

    /** Cambia de día dentro del detalle (desde el pronóstico extendido). */
    private fun selectDay(i: Int) {
        if (i == detailIdx) {
            detailScroll.smoothScrollTo(0, 0)
            return
        }
        detailIdx = i
        if (animOn()) {
            detailCol.alpha = 0.25f
            bindDetail(i)
            detailCol.animate().alpha(1f).setDuration((320 * animScale()).toLong()).start()
            sphere.kick(4f)
        } else {
            bindDetail(i)
        }
        detailScroll.smoothScrollTo(0, 0)
    }

    private fun toggleExt() {
        extOpen = !extOpen
        if (extOpen) {
            if (extDirty || extList.childCount == 0) buildExt()
            extList.visibility = View.VISIBLE
            if (animOn()) {
                extList.alpha = 0f
                extList.animate().alpha(1f).setDuration((300 * animScale()).toLong()).start()
            }
            detailScroll.post { detailScroll.smoothScrollTo(0, extList.top - dp(80)) }
        } else {
            extList.visibility = View.GONE
        }
    }

    private fun clearGlass(col: LinearLayout) {
        for (i in 0 until col.childCount) bd.glass.remove(col.getChildAt(i))
        col.removeAllViews()
    }

    private fun buildExt() {
        extDirty = false
        clearGlass(extList)
        val r = report ?: return
        for ((i, d) in r.days.withIndex()) {
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(8), dp(14), dp(8))
            val g = glass(row, 20f, 0)
            g.emphasis = i == detailIdx
            row.addView(
                tv("${WxText.dayShort(d.date)} ${d.date.dayOfMonth}", 15f, WxC.TEXT, true),
                lp(dp(66), WRAP)
            )
            val ic = WxIconView(context)
            ic.set(Wmo.kind(d.code), false, false)
            row.addView(ic, lp(dp(36), dp(36)))
            val rain = LinearLayout(context)
            rain.orientation = LinearLayout.HORIZONTAL
            rain.gravity = Gravity.CENTER_VERTICAL
            rain.addView(icon(R.drawable.wx_ic_drop, 15, WxC.CYAN))
            rain.addView(tv(WxText.pct(d.rainProb), 14f, WxC.SUB), lp(WRAP, WRAP).apply { leftMargin = dp(4) })
            row.addView(rain, lp(0, WRAP, 1f).apply { leftMargin = dp(12) })
            row.addView(tv(WxText.deg(d.tMax), 16f, WxC.TEXT, true), lp(WRAP, WRAP))
            row.addView(tv(WxText.deg(d.tMin), 15f, WxC.SUB), lp(WRAP, WRAP).apply { leftMargin = dp(10) })
            press(row) { selectDay(i) }
            extList.addView(row, lp(MATCH, WRAP).apply { topMargin = dp(6) })
        }
    }

    // ================================================================ ubicación

    private fun openSetup() {
        if (busy || setupShown) return
        if (detailShown) return
        showSetup(true)
    }

    private fun showSetup(animate: Boolean) {
        setupShown = true
        btnSetupBack.visibility = if (place != null) View.VISIBLE else View.GONE
        tvSetupTitle.text = if (place == null) "Elige tu ciudad" else "Cambiar ubicación"
        tvSetupSub.text = if (place == null) "Pronóstico meteorológico real" else "Busca tu ciudad o pueblo"
        searchField.setText("")
        resultsCol.removeAllViews()
        tvSearchStatus.text = defaultSearchHint()
        homeScroll.visibility = View.INVISIBLE
        setupRoot.visibility = View.VISIBLE
        if (animate && animOn()) {
            setupRoot.alpha = 0f
            setupRoot.animate().alpha(1f).setDuration((260 * animScale()).toLong()).start()
        } else {
            setupRoot.alpha = 1f
        }
    }

    private fun closeSetup() {
        if (place == null) return
        hideKeyboard()
        handler.removeCallbacks(searchRun)
        searchSeq++
        setupShown = false
        setupRoot.visibility = View.GONE
        homeScroll.visibility = if (detailShown) View.INVISIBLE else View.VISIBLE
    }

    private fun hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchField.windowToken, 0)
        searchField.clearFocus()
    }

    private fun doSearch(q: String) {
        val query = q.trim()
        if (query.length < 2) return
        val my = ++searchSeq
        tvSearchStatus.text = "Buscando…"
        Thread {
            var res: List<WxPlace>? = null
            try {
                res = WeatherApi.search(query)
            } catch (e: Exception) {
                res = null
            }
            val result = res
            handler.post {
                if (my != searchSeq) return@post
                if (result == null) {
                    tvSearchStatus.text = "No se pudo buscar. Revisa tu conexión a internet."
                } else {
                    showResults(result)
                }
            }
        }.start()
    }

    private fun showResults(list: List<WxPlace>) {
        clearGlass(resultsCol)
        if (list.isEmpty()) {
            tvSearchStatus.text = "No se encontró ningún lugar con ese nombre. Prueba con otra escritura."
            return
        }
        tvSearchStatus.text = "Toca tu ciudad para elegirla"
        for (p in list) {
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), dp(12), dp(12), dp(12))
            glass(row, 22f, 0)
            row.addView(icon(R.drawable.wx_ic_pin, 22, WxC.VIOLET))
            val col = LinearLayout(context)
            col.orientation = LinearLayout.VERTICAL
            col.addView(tv(p.name, 17f, WxC.TEXT, true), lp(WRAP, WRAP))
            val sub = p.subtitle()
            if (sub.isNotEmpty()) col.addView(tv(sub, 13f, WxC.SUB), lp(WRAP, WRAP).apply { topMargin = dp(3) })
            row.addView(col, lp(0, WRAP, 1f).apply { leftMargin = dp(12) })
            row.addView(icon(R.drawable.wx_ic_chev, 22, WxC.SUB))
            press(row) { pick(p) }
            resultsCol.addView(row, lp(MATCH, WRAP).apply { topMargin = dp(8) })
        }
    }

    private fun pick(p: WxPlace) {
        hideKeyboard()
        WeatherStore.savePlace(context, p)
        place = p
        report = null
        lastError = false
        lastTry = 0L
        extDirty = true
        closeSetup()
        bind()
        refresh(true)
    }
}
