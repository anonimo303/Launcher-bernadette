package com.personal.launcher.weather

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Dibujo de los símbolos del clima (sol, luna, nubes, lluvia, rayo, nieve, niebla).
 * Todo se dibuja con formas vectoriales en coordenadas unitarias [-1, 1]: no hay imágenes
 * y el mismo código sirve para los iconos pequeños y grandes.
 */
internal object WxArt {

    // ---- pinturas unitarias (los degradados están en coordenadas unitarias) ----
    private val rect = RectF()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    const val TINT_LIGHT = 0
    const val TINT_GRAY = 1
    const val TINT_DARK = 2

    private fun cloudPaint(top: Int, mid: Int, bot: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(0f, -0.64f, 0f, 0.52f, intArrayOf(top, mid, bot), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }

    private val cloudPaints: Array<Paint> by lazy {
        arrayOf(
            cloudPaint(0xFFFFFFFF.toInt(), 0xFFE2DEFF.toInt(), 0xFF9FABFF.toInt()),
            cloudPaint(0xFFECEAFF.toInt(), 0xFFB5B9E8.toInt(), 0xFF7A80D0.toInt()),
            cloudPaint(0xFFB9B4EA.toInt(), 0xFF7B70C9.toInt(), 0xFF473C9E.toInt())
        )
    }

    private val sunDisc: Paint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(-0.25f, -0.28f, 1.25f, intArrayOf(0xFFFFFBC8.toInt(), 0xFFFFC928.toInt(), 0xFFFF8A00.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        }
    }
    private val sunGlow: Paint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(0f, 0f, 1f, intArrayOf(0x99FFC94A.toInt(), 0x44FF9A2C.toInt(), 0x00FF7A00), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        }
    }
    private val aura: Paint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(0f, 0f, 1f, intArrayOf(0x668C6CFF, 0x224F7CFF, 0x00406CFF), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        }
    }
    private val moonPaint: Paint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(-0.8f, -0.8f, 0.8f, 0.8f, 0xFFFFFFFF.toInt(), 0xFFB9C3FF.toInt(), Shader.TileMode.CLAMP)
        }
    }
    private val moonPath: Path by lazy {
        val a = Path()
        a.addCircle(0f, 0f, 1f, Path.Direction.CW)
        val b = Path()
        b.addCircle(0.52f, -0.3f, 0.86f, Path.Direction.CW)
        a.op(b, Path.Op.DIFFERENCE)
        a
    }
    private val boltPath: Path by lazy {
        Path().apply {
            moveTo(0.14f, -0.5f)
            lineTo(-0.3f, 0.12f)
            lineTo(-0.02f, 0.12f)
            lineTo(-0.16f, 0.62f)
            lineTo(0.34f, -0.08f)
            lineTo(0.06f, -0.08f)
            lineTo(0.22f, -0.5f)
            close()
        }
    }
    private val boltPaint: Paint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, -0.5f, 0f, 0.62f, 0xFFFFF7B0.toInt(), 0xFFFFB300.toInt(), Shader.TileMode.CLAMP)
        }
    }

    // ---- piezas ----

    fun sun(c: Canvas, x: Float, y: Float, r: Float, rays: Boolean, rot: Float = 0f) {
        c.save()
        c.translate(x, y)
        c.scale(r, r)
        c.drawCircle(0f, 0f, 2.3f, sunGlow)
        if (rays) {
            p.shader = null
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = 0.17f
            p.color = 0xFFFFC53D.toInt()
            c.save()
            c.rotate(rot)
            for (i in 0 until 8) {
                val a = i * (Math.PI.toFloat() / 4f)
                c.drawLine(cos(a) * 1.36f, sin(a) * 1.36f, cos(a) * 1.78f, sin(a) * 1.78f, p)
            }
            c.restore()
            p.style = Paint.Style.FILL
        }
        c.drawCircle(0f, 0f, 1f, sunDisc)
        c.restore()
    }

    fun moon(c: Canvas, x: Float, y: Float, r: Float) {
        c.save()
        c.translate(x, y)
        c.scale(r, r)
        c.rotate(-18f)
        c.drawPath(moonPath, moonPaint)
        c.restore()
    }

    /** Nube vectorial opaca (iconos). Ancho total = [w]. */
    fun cloud(c: Canvas, x: Float, y: Float, w: Float, tint: Int) {
        val f = w / 1.7f
        c.save()
        c.translate(x, y)
        c.scale(f, f)
        val pt = cloudPaints[tint]
        rect.set(-0.85f, 0.02f, 0.85f, 0.52f)
        c.drawRoundRect(rect, 0.26f, 0.26f, pt)
        c.drawCircle(-0.46f, 0.08f, 0.34f, pt)
        c.drawCircle(0.02f, -0.14f, 0.5f, pt)
        c.drawCircle(0.5f, 0.1f, 0.36f, pt)
        c.restore()
    }

    fun bolt(c: Canvas, x: Float, y: Float, s: Float) {
        c.save()
        c.translate(x, y)
        c.scale(s, s)
        c.drawPath(boltPath, boltPaint)
        c.restore()
    }

    private fun drops(c: Canvas, cy: Float) {
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 0.085f
        p.color = 0xFF5CC8FF.toInt()
        val xs = floatArrayOf(-0.42f, 0f, 0.42f)
        for (i in xs.indices) {
            val o = if (i == 1) 0.1f else 0f
            c.drawLine(xs[i] + 0.07f, cy + o, xs[i] - 0.05f, cy + o + 0.24f, p)
        }
        p.style = Paint.Style.FILL
    }

    private fun flakes(c: Canvas, cy: Float) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = 0xFFFFFFFF.toInt()
        c.drawCircle(-0.4f, cy, 0.075f, p)
        c.drawCircle(0f, cy + 0.14f, 0.075f, p)
        c.drawCircle(0.4f, cy, 0.075f, p)
        c.drawCircle(-0.2f, cy + 0.3f, 0.06f, p)
        c.drawCircle(0.2f, cy + 0.3f, 0.06f, p)
    }

    private fun fog(c: Canvas, cy: Float) {
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 0.08f
        p.color = 0xCCDDE2FF.toInt()
        c.drawLine(-0.62f, cy, 0.62f, cy, p)
        c.drawLine(-0.46f, cy + 0.2f, 0.7f, cy + 0.2f, p)
        c.drawLine(-0.62f, cy + 0.4f, 0.5f, cy + 0.4f, p)
        p.style = Paint.Style.FILL
    }

    /** Icono completo del clima dentro de un cuadrado de lado [s] centrado en ([cx], [cy]). */
    fun icon(c: Canvas, kind: WxKind, night: Boolean, cx: Float, cy: Float, s: Float, glow: Boolean = true) {
        val u = s / 2f
        c.save()
        c.translate(cx, cy)
        c.scale(u, u)
        if (glow) c.drawCircle(0f, 0f, 1.05f, aura)
        when (kind) {
            WxKind.CLEAR -> if (night) {
                moon(c, 0f, 0f, 0.62f)
                p.shader = null; p.color = 0xFFFFFFFF.toInt(); p.style = Paint.Style.FILL
                c.drawCircle(0.62f, -0.55f, 0.06f, p)
                c.drawCircle(0.42f, 0.58f, 0.045f, p)
            } else {
                sun(c, 0f, 0f, 0.46f, true)
            }
            WxKind.PARTLY -> {
                if (night) moon(c, -0.3f, -0.3f, 0.4f) else sun(c, -0.3f, -0.3f, 0.34f, true)
                cloud(c, 0.1f, 0.2f, 1.5f, TINT_LIGHT)
            }
            WxKind.CLOUDY -> {
                cloud(c, 0.3f, -0.28f, 1.0f, TINT_DARK)
                cloud(c, -0.05f, 0.12f, 1.5f, TINT_LIGHT)
            }
            WxKind.FOG -> {
                cloud(c, 0f, -0.3f, 1.4f, TINT_LIGHT)
                fog(c, 0.28f)
            }
            WxKind.RAIN -> {
                cloud(c, 0f, -0.28f, 1.5f, TINT_GRAY)
                drops(c, 0.38f)
            }
            WxKind.STORM -> {
                cloud(c, 0f, -0.3f, 1.5f, TINT_DARK)
                bolt(c, 0.04f, 0.4f, 0.55f)
            }
            WxKind.SNOW -> {
                cloud(c, 0f, -0.3f, 1.5f, TINT_GRAY)
                flakes(c, 0.4f)
            }
        }
        c.restore()
    }

    // ---- nubes en mapa de bits (para la esfera: se dibujan miles de veces, así cuestan casi nada) ----

    private const val BMP_W = 240
    private const val BMP_H = 168
    private const val BMP_S = 130f
    /** Origen de la nube dentro del mapa de bits, en unidades de nube. */
    const val BMP_OX = (BMP_W / 2f) / BMP_S
    const val BMP_OY = 91f / BMP_S
    const val BMP_UW = BMP_W / BMP_S
    const val BMP_UH = BMP_H / BMP_S

    private val bitmaps = arrayOfNulls<Bitmap>(3)

    fun cloudBitmap(tint: Int): Bitmap {
        bitmaps[tint]?.let { return it }
        val b = Bitmap.createBitmap(BMP_W, BMP_H, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.translate(BMP_W / 2f, 91f)
        c.scale(BMP_S, BMP_S)
        val pt = cloudPaints[tint]
        rect.set(-0.85f, 0.02f, 0.85f, 0.52f)
        c.drawRoundRect(rect, 0.26f, 0.26f, pt)
        c.drawCircle(-0.46f, 0.08f, 0.34f, pt)
        c.drawCircle(0.02f, -0.14f, 0.5f, pt)
        c.drawCircle(0.5f, 0.1f, 0.36f, pt)
        // volumen: luz arriba a la izquierda y sombra abajo (solo sobre los píxeles de la nube)
        val q = Paint(Paint.ANTI_ALIAS_FLAG)
        q.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
        q.shader = RadialGradient(-0.15f, -0.42f, 0.7f, intArrayOf(0x66FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        c.drawRect(-1f, -0.8f, 1f, 0.6f, q)
        q.shader = LinearGradient(0f, 0.05f, 0f, 0.52f, 0x00281E78, 0x55281E78, Shader.TileMode.CLAMP)
        c.drawRect(-1f, 0f, 1f, 0.6f, q)
        bitmaps[tint] = b
        return b
    }
}

/** Vista estática con el icono del clima (la usan la cabecera, la tarjeta principal y los días). */
class WxIconView(ctx: Context) : View(ctx) {
    private var kind = WxKind.CLEAR
    private var night = false
    private var glow = true

    fun set(k: WxKind, n: Boolean, glow: Boolean = true) {
        if (k == kind && n == night && glow == this.glow) return
        kind = k
        night = n
        this.glow = glow
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat()
        if (s <= 0f) return
        WxArt.icon(c, kind, night, width / 2f, height / 2f, s, glow)
    }
}
