package com.personal.launcher.mahoraga

import android.content.Context
import com.personal.launcher.Prefs

/**
 * Activa con Shizuku los mismos ajustes que las «Opciones del desarrollador» para ventanas pequeñas, sin tener que entrar ahí:
 *  · enable_freeform_support        → «Activar ventanas de formato libre»
 *  · force_resizable_activities     → «Forzar que se pueda cambiar el tamaño de las actividades»
 *  · enable_non_resizable_multi_window → «…imposibilidad de cambiar de tamaño en una ventana múltiple»
 * Guarda el valor anterior de cada uno y lo devuelve al desactivar. Bloqueante: llamar desde un hilo.
 * Nota: algunos sistemas solo aplican el cambio tras reiniciar; si se apagan las opciones del desarrollador desde Ajustes,
 * Android puede volver a ponerlas a cero (basta con volver a activarlas desde aquí).
 */
object Freeform {
    private val KEYS = listOf("enable_freeform_support", "force_resizable_activities", "enable_non_resizable_multi_window")
    private const val K_PREV = "mh_ff_prev"

    fun active(c: Context) = Mh.freeformSupported(c)

    fun enable(c: Context): Boolean {
        if (!Shz.granted()) return false
        val app = c.applicationContext
        if (Prefs.str(app, K_PREV) == null) {
            val r = Shz.exec(KEYS.joinToString("; ") { "echo \"$it=\$(settings get global $it)\"" }, 6000L) ?: return false
            Prefs.setStr(app, K_PREV, r.out.lines().filter { it.contains("=") }.joinToString(","))
        }
        Shz.exec(KEYS.joinToString("; ") { "settings put global $it 1" }, 6000L) ?: return false
        val chk = Shz.exec("settings get global enable_freeform_support", 4000L)
        return chk?.out?.trim() == "1"
    }

    fun disable(c: Context): Boolean {
        if (!Shz.granted()) return false
        val app = c.applicationContext
        val prev = (Prefs.str(app, K_PREV) ?: "").split(",").filter { it.contains("=") }
            .associate { it.substringBefore("=") to it.substringAfter("=").trim() }
        val cmd = KEYS.joinToString("; ") {
            val v = prev[it]
            if (v == null || v == "null" || v.isEmpty() || !v.matches(Regex("[0-9]+"))) "settings delete global $it" else "settings put global $it $v"
        }
        val r = Shz.exec(cmd, 6000L) ?: return false
        Prefs.setStr(app, K_PREV, null)
        return r.ok || r.out.isBlank()
    }
}
