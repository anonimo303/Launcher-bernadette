package com.personal.launcher

import android.Manifest
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.min

/**
 * Bernadette: asistente de voz del launcher.
 *
 *  · Servicio en primer plano (micrófono) que escucha la palabra «Bernadette».
 *  · Al oírla muestra la esfera (grande, o pequeña flotante si la app en uso está elegida),
 *    escucha la orden, la ejecuta, responde por voz y se cierra sola.
 */
class BernadetteService : Service() {

    companion object {
        const val ACTION_START = "bern.start"
        const val ACTION_STOP = "bern.stop"
        const val ACTION_TEST = "bern.test"
        private const val CH = "bernadette"
        private const val NID = 4201

        fun enabled(c: Context) = Prefs.bool(c, "bern_on", false)
        fun name(c: Context): String = Prefs.str(c, "bern_name")?.trim()?.takeIf { it.isNotEmpty() } ?: BernadetteParser.DEFAULT_NAME
        fun hasCalendar(c: Context) = c.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            c.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
        fun listenerOn(c: Context): Boolean =
            (Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: "").contains(c.packageName)
        fun hasMic(c: Context) = c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        fun hasUsage(c: Context): Boolean = try {
            val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) { false }

        fun loadAliases(c: Context) {
            BernadetteParser.aliases = (Prefs.str(c, "bern_alias") ?: "").split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }
        }

        fun floatApps(c: Context): Set<String> =
            (Prefs.str(c, "bern_float_apps") ?: "").split("\n").filter { it.isNotBlank() }.toSet()

        /** Arranca o detiene el servicio según los ajustes. Llamar con la app visible (Android 12). */
        fun sync(c: Context) {
            if (enabled(c) && hasMic(c)) start(c, ACTION_START) else stop(c)
        }

        fun start(c: Context, action: String) {
            try {
                c.startForegroundService(Intent(c, BernadetteService::class.java).setAction(action))
            } catch (e: Exception) { /* Android 12 impide arrancarlo desde segundo plano */ }
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, BernadetteService::class.java))
        }
    }

    private enum class Phase { WAKE, COMMAND, BUSY }
    private enum class Mode { NONE, FULL, FLOAT }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var recognizer: SpeechRecognizer? = null
    private var onDevice = false
    private var vosk: VoskWake? = null
    private var voskFails = 0
    private var voskBad = false     // el motor silencioso falló: se usa el reconocedor del sistema
    private var gen = 0            // generación del reconocedor: ignora avisos de uno ya destruido
    private var phase = Phase.WAKE
    private var woken = false
    private var backoff = 1000L
    private var screenOn = true
    private var lastStart = 0L      // cuándo empezó la última sesión de escucha
    private var quick = 0           // sesiones seguidas que murieron casi al instante
    private var muted = false       // volumen multimedia silenciado para que no suene el «tic»

    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private var ttsSig = ""
    private var pendingSpeech: String? = null

    private var ui = Mode.NONE
    private var fullView: FrameLayout? = null
    private var fullSphere: BernadetteSphere? = null
    private var transcript: TextView? = null
    private var floatView: BernadetteSphere? = null
    private var floatLp: WindowManager.LayoutParams? = null

    private var currentPkg = ""
    private var lastPoll = 0L
    private var torchOn = false

    // ------------------------------------------------------------------ ciclo de vida

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        loadAliases(this)
        onDevice = Build.VERSION.SDK_INT >= 31 && Prefs.bool(this, "bern_ondevice", false)
        Diag.log(this, "servicio iniciado (Android " + Build.VERSION.SDK_INT + ", " + Build.MANUFACTURER + ")")
        screenOn = (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isInteractive
        val f = IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON) }
        registerReceiver(screenReceiver, f)
        initTts()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setBool(this, "bern_on", false)
            stopSelf()
            return START_NOT_STICKY
        }
        loadAliases(this)
        if (!startFg()) { stopSelf(); return START_NOT_STICKY }
        if (!hasMic(this)) { stopSelf(); return START_NOT_STICKY }
        h.removeCallbacks(poll)
        h.post(poll)
        if (intent?.action == ACTION_TEST) {
            h.post { activate("") }
        } else if (phase == Phase.WAKE && recognizer == null && vosk == null && screenOn && always()) {
            listen(false)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        stopVosk()
        VoskWake.release()
        unmuteBeep()
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        destroyRecognizer()
        removeFull(false)
        removeFloat()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (floatView != null) { removeFloat(); ensureFloat() }
    }

    private fun startFg(): Boolean {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Bernadette", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, SettingsActivity::class.java).putExtra("page", "bernadette"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, BernadetteService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val talk = PendingIntent.getService(
            this, 2, Intent(this, BernadetteService::class.java).setAction(ACTION_TEST),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_sparkle)
            .setContentTitle("Bernadette")
            .setContentText(if (always()) "Esperando que digas «" + name(this) + "»" else "Toca «Hablar» para darme una orden")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_sparkle), "Hablar", talk).build())
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_sparkle), "Detener", stop).build())
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(NID, n)
            true
        } catch (e: Exception) { false }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) {
                screenOn = false
                h.removeCallbacksAndMessages(null)
                stopVosk()
                unmuteBeep()
                destroyRecognizer()
                tts?.stop()
                removeFull(false)
                removeFloat()
                phase = Phase.WAKE; woken = false; ui = Mode.NONE
            } else {
                screenOn = true
                h.post(poll)
                h.postDelayed({ if (phase == Phase.WAKE && always()) listen(false) }, 600)
            }
        }
    }

    // ------------------------------------------------------------------ reconocimiento

    private fun destroyRecognizer() {
        gen++
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }

    private fun newRecognizer(): SpeechRecognizer? {
        destroyRecognizer()
        val r = try {
            if (onDevice && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            else if (SpeechRecognizer.isRecognitionAvailable(this)) SpeechRecognizer.createSpeechRecognizer(this)
            else null
        } catch (e: Exception) { null }
        r?.setRecognitionListener(Listener(gen))
        recognizer = r
        Diag.log(this, "reconocedor nuevo (" + (if (onDevice) "sin internet" else "del sistema") + ", ok=" + (r != null) + ")")
        return r
    }

    private fun useVosk(): Boolean = !voskBad && VoskModel.installed(this)
    private fun always(): Boolean = Prefs.bool(this, "bern_always", true)

    private fun startVosk() {
        if (vosk != null) return
        destroyRecognizer()
        val w = VoskWake(this, { p -> onVoskPartial(p) }, { t -> onVoskFinal(t) }, { m -> onVoskFail(m) })
        vosk = w
        Diag.log(this, "escucha silenciosa iniciada")
        w.start()
    }

    private fun stopVosk() {
        val w = vosk ?: return
        vosk = null
        w.stop()
        Diag.log(this, "escucha silenciosa detenida")
    }

    private val resetWoken = Runnable {
        if (woken && phase == Phase.WAKE) { woken = false; hideUi() }
    }

    private fun onVoskPartial(p: String) {
        if (phase != Phase.WAKE || woken) return
        if (BernadetteParser.afterWake(p, name(this), 3) != null) {
            Diag.log(this, "oyó su nombre: " + p)
            woken = true
            showUi()
            setState(BernadetteSphere.State.LISTENING)
            h.removeCallbacks(resetWoken)
            h.postDelayed(resetWoken, 7000)
        }
    }

    private fun onVoskFinal(t: String) {
        if (phase != Phase.WAKE) return
        Diag.log(this, "oyó: «" + t + "»")
        val rem = BernadetteParser.afterWake(t, name(this), 3)
        if (rem == null) {
            if (woken) { woken = false; hideUi() }
            return
        }
        h.removeCallbacks(resetWoken)
        stopVosk()
        activate(rem)
    }

    private fun onVoskFail(msg: String) {
        vosk = null
        voskFails++
        if (voskFails < 4) {
            Diag.log(this, "escucha silenciosa falló (" + msg + "), reintento " + voskFails + "/3")
            if (phase == Phase.WAKE) h.postDelayed({ if (phase == Phase.WAKE) listen(false) }, 2500)
        } else {
            Diag.log(this, "escucha silenciosa falló: " + msg + " → uso el reconocedor del sistema")
            voskBad = true
            if (phase == Phase.WAKE) h.postDelayed({ if (phase == Phase.WAKE) listen(false) }, 500)
        }
    }

    private fun listen(command: Boolean) {
        if (!screenOn || !hasMic(this)) return
        if (!command && !always()) return   // modo manual: el micrófono solo se abre al tocar «Hablar»
        if (!command && useVosk()) { startVosk(); return }
        val r = recognizer ?: newRecognizer()
        if (r == null) {
            // sin servicio de reconocimiento (falta la app de Google): reintento lento
            h.postDelayed({ if (phase == Phase.WAKE) listen(false) }, 15000)
            return
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE,
                Locale.getDefault().takeIf { it.language == "es" }?.toLanguageTag() ?: "es-AR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, if (command) 1500L else 1000L)
        }
        lastStart = SystemClock.uptimeMillis()
        Diag.log(this, "empieza a escuchar (" + (if (command) "orden" else "palabra") + ")")
        try { r.startListening(i) } catch (e: Exception) { destroyRecognizer(); retryWake() }
    }

    private fun retryWake() {
        val lived = SystemClock.uptimeMillis() - lastStart
        backoff = if (lived > 4000L) 1500L else min(backoff * 2, 12000L).coerceAtLeast(1500L)
        Diag.log(this, "reintenta en " + backoff + " ms")
        h.postDelayed({ if (phase == Phase.WAKE && !woken) listen(false) }, backoff)
    }

    /**
     * Vuelve a escuchar la palabra de activación sin entrar en bucle: si las sesiones mueren
     * casi al instante (lo que hace que el micrófono verde parpadee y suene «tic, tic, tic»)
     * cada reintento espera un poco más; en cuanto una sesión dura normal, vuelve a lo normal.
     */
    private fun scheduleWake(baseMs: Long) {
        val lived = SystemClock.uptimeMillis() - lastStart
        quick = if (lived < 1500L) quick + 1 else 0
        val extra = if (quick >= 3) min(3000L, 300L shl min(quick - 3, 4)) else 0L
        h.postDelayed({ if (phase == Phase.WAKE) listen(false) }, baseMs + extra)
    }

    // ---- silenciar el «tic» del reconocedor mientras espera la palabra
    private val guard = object : Runnable {
        override fun run() {
            val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            if (!muted) return
            if (!screenOn || phase != Phase.WAKE || am.isMusicActive) unmuteBeep()
            else h.postDelayed(this, 250)
        }
    }

    /** Silencia el volumen multimedia solo si no está sonando nada; se devuelve solo en cuanto suena algo. */
    private fun muteBeep() {
        if (!Prefs.bool(this, "bern_mute", true) || muted) return
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            if (am.isMusicActive || am.isStreamMute(android.media.AudioManager.STREAM_MUSIC) ||
                am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) == 0) return
            am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_MUTE, 0)
            muted = true
            h.removeCallbacks(guard)
            h.postDelayed(guard, 250)
        } catch (_: Exception) {}
    }

    private fun unmuteBeep() {
        h.removeCallbacks(guard)
        if (!muted) return
        muted = false
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_UNMUTE, 0)
        } catch (_: Exception) {}
    }

    private inner class Listener(private val g: Int) : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) { if (g == gen) Diag.log(this@BernadetteService, "micrófono listo") }
        override fun onBeginningOfSpeech() { if (g == gen) backoff = 1000L }
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, b: Bundle?) {}

        override fun onRmsChanged(rms: Float) {
            if (g != gen) return
            if (phase == Phase.COMMAND || woken) {
                val v = ((rms + 2f) / 12f).coerceIn(0f, 1f)
                fullSphere?.setLevel(v)
                floatView?.setLevel(v)
            }
        }

        override fun onPartialResults(b: Bundle?) {
            if (g != gen) return
            val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
            if (l.isEmpty()) return
            if (phase == Phase.WAKE && !woken) {
                if (l.any { BernadetteParser.afterWake(it, name(this@BernadetteService)) != null }) {
                    woken = true
                    showUi()          // aparece al instante, mientras termina de hablar
                    setState(BernadetteSphere.State.LISTENING)
                }
            } else if (woken || phase == Phase.COMMAND) {
                setText(l[0])
            }
        }

        override fun onResults(b: Bundle?) {
            if (g != gen) return
            val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
            if (phase == Phase.WAKE) {
                val rem = l.mapNotNull { BernadetteParser.afterWake(it, name(this@BernadetteService)) }
                if (rem.isEmpty()) {
                    if (woken) { woken = false; hideUi() }
                    scheduleWake(350)
                } else {
                    unmuteBeep()
                    val best = rem.firstOrNull { it.isNotEmpty() } ?: ""
                    activate(best)
                }
            } else if (phase == Phase.COMMAND) {
                val t = l.firstOrNull()?.trim().orEmpty()
                if (t.isEmpty()) finish() else execute(t)
            }
        }

        override fun onError(e: Int) {
            if (g != gen) {
                Diag.log(this@BernadetteService, "aviso viejo ignorado: " + Diag.err(e))
                return
            }
            Diag.log(this@BernadetteService, "error " + Diag.err(e) + " tras " + (SystemClock.uptimeMillis() - lastStart) + " ms")
            when (phase) {
                Phase.WAKE -> {
                    when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                            if (woken) { woken = false; hideUi() }
                            scheduleWake(350)
                        }
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> stopSelf()
                        12, 13 -> { // idioma no disponible sin conexión → servicio normal
                            if (onDevice) {
                                onDevice = false
                                destroyRecognizer()
                                scheduleWake(400)
                            } else {
                                destroyRecognizer()
                                retryWake()
                            }
                        }
                        else -> {
                            if (woken) { woken = false; hideUi() }
                            destroyRecognizer()
                            retryWake()
                        }
                    }
                }
                Phase.COMMAND -> {
                    if (e == 12 || e == 13) { onDevice = false; destroyRecognizer() }
                    if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) speak("No te escuché.")
                    else speak("No pude reconocer tu voz.")
                }
                Phase.BUSY -> {}
            }
        }
    }

    // ------------------------------------------------------------------ flujo de la orden

    /** Bernadette fue llamada. [text] es lo que ya se dijo después de la palabra. */
    private fun activate(text: String) {
        woken = true
        h.removeCallbacks(resetWoken)
        stopVosk()
        unmuteBeep()
        showUi()
        if (text.isNotBlank()) {
            execute(text)
        } else {
            phase = Phase.COMMAND
            setState(BernadetteSphere.State.LISTENING)
            setText("Te escucho…")
            destroyRecognizer()
            h.postDelayed({ if (phase == Phase.COMMAND) listen(true) }, 250)
        }
    }

    private fun execute(text: String) {
        phase = Phase.BUSY
        destroyRecognizer()
        setState(BernadetteSphere.State.PROCESSING)
        setText(text)
        h.postDelayed({ speak(perform(text)) }, 400)
    }

    private val safety = Runnable { if (phase == Phase.BUSY) finish() }

    private fun armSafety(ms: Long) {
        h.removeCallbacks(safety)
        h.postDelayed(safety, ms)
    }

    private fun speak(reply: String) {
        phase = Phase.BUSY
        unmuteBeep()
        destroyRecognizer()
        setState(BernadetteSphere.State.SPEAKING)
        setText(reply)
        // Si cambiaste de voz o de motor en los ajustes, se vuelve a preparar antes de hablar.
        if (ttsSig != voiceSig()) {
            ttsOk = false
            try { tts?.shutdown() } catch (_: Exception) {}
            tts = null
            initTts()
        }
        val t = tts
        if (t != null && ttsOk) {
            t.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "bern")
            armSafety(90000) // seguro por si falla el audio
        } else if (t != null) {
            pendingSpeech = reply
            armSafety(6000)
        } else finish()
    }

    /** Cierra la interfaz y vuelve a esperar la palabra de activación. */
    private fun finish() {
        h.removeCallbacks(poll)
        h.removeCallbacks(safety)
        phase = Phase.WAKE
        woken = false
        pendingSpeech = null
        tts?.stop()
        hideUi()
        h.post(poll)
        h.postDelayed({ if (phase == Phase.WAKE) listen(false) }, 500)
    }

    private fun cancelByTouch() {
        tts?.stop()
        destroyRecognizer()
        finish()
    }

    // ------------------------------------------------------------------ voz

    private fun voiceSig(): String =
        (Prefs.str(this, "bern_tts_engine") ?: "") + "|" + (Prefs.str(this, "bern_voice") ?: "")

    private fun initTts() {
        ttsSig = voiceSig()
        val engine = Prefs.str(this, "bern_tts_engine")
        val onInit = TextToSpeech.OnInitListener { st ->
            val t = tts
            if (st == TextToSpeech.SUCCESS && t != null) {
                var r = t.setLanguage(Locale("es", "AR"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) r = t.setLanguage(Locale("es", "ES"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) r = t.setLanguage(Locale("es"))
                ttsOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                // Voz elegida en los ajustes (si ya no existe, se queda la del sistema).
                val wanted = Prefs.str(this, "bern_voice")
                if (wanted != null) {
                    try {
                        val v = t.voices?.firstOrNull { it.name == wanted }
                        if (v != null && t.setVoice(v) == TextToSpeech.SUCCESS) ttsOk = true
                    } catch (_: Exception) {}
                }
                t.setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { h.post { if (phase == Phase.BUSY) finish() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { h.post { if (phase == Phase.BUSY) finish() } }
                })
                pendingSpeech?.let { p -> if (ttsOk) { pendingSpeech = null; speak(p) } }
            } else if (engine != null) {
                // el motor elegido ya no funciona (se desinstaló): se vuelve al del sistema
                Prefs.setStr(this, "bern_tts_engine", null)
                Prefs.setStr(this, "bern_voice", null)
                try { tts?.shutdown() } catch (_: Exception) {}
                tts = null
                initTts()
            }
        }
        tts = if (engine != null) TextToSpeech(this, onInit, engine) else TextToSpeech(this, onInit)
    }

    // ------------------------------------------------------------------ acciones

    private fun perform(text: String): String {
        val cal = Calendar.getInstance()
        val cmd = BernadetteParser.parse(text, java.time.LocalDateTime.now())
        return when (cmd) {
            is Cmd.Alarm -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, cmd.hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, cmd.minute)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Bernadette")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (launch(i)) {
                    "Listo, alarma configurada para " + BernadetteParser.spokenTime(cmd.hour, cmd.minute) +
                        (if (cmd.guessedPeriod) BernadetteParser.period(cmd.hour) else "")
                } else "No encontré una aplicación de reloj para configurar la alarma."
            }
            is Cmd.Timer -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, cmd.seconds)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Bernadette")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (launch(i)) "Listo, temporizador de " + durationText(cmd.seconds)
                else "No encontré una aplicación de reloj para el temporizador."
            }
            is Cmd.OpenApp -> openApp(cmd.query, cmd.search)
            is Cmd.WebSearch -> webSearch(cmd.q)
            is Cmd.Event -> addEvent(cmd)
            is Cmd.ReadNotifs -> readNotifs(cmd)
            is Cmd.Torch -> torch(cmd.on)
            Cmd.TellTime -> {
                val t = BernadetteParser.spokenTime(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
                val hh = cal.get(Calendar.HOUR_OF_DAY)
                (if (t.startsWith("la ")) "Es " else "Son ") + t + BernadetteParser.period(if (cal.get(Calendar.MINUTE) == 45) (hh + 1) % 24 else hh)
            }
            Cmd.TellDate -> "Hoy es " + SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "AR")).format(Date())
            Cmd.Cancel -> "De acuerdo."
            Cmd.Unknown -> "No entendí. Puedo poner alarmas y temporizadores, abrir aplicaciones, decir la hora o la fecha, y encender la linterna."
        }
    }

    private fun launch(i: Intent): Boolean {
        return try {
            if (i.resolveActivity(packageManager) == null) return false
            startActivity(i)
            true
        } catch (e: Exception) { false }
    }

    private fun durationText(sec: Int): String {
        val hh = sec / 3600
        val mm = (sec % 3600) / 60
        val ss = sec % 60
        val p = ArrayList<String>()
        if (hh > 0) p.add(if (hh == 1) "1 hora" else "$hh horas")
        if (mm > 0) p.add(if (mm == 1) "1 minuto" else "$mm minutos")
        if (ss > 0) p.add(if (ss == 1) "1 segundo" else "$ss segundos")
        return p.joinToString(" y ")
    }

    /** Apps conocidas: lo que el reconocedor de voz suele oír → paquetes posibles + web de respaldo. */
    private class Known(val names: List<String>, val pkgs: List<String>, val web: String?)
    private val KNOWN = listOf(
        Known(listOf("tiktok", "tik tok", "tic toc", "tic tac", "tik tak", "tiktoc"),
            listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go"), "https://www.tiktok.com/"),
        Known(listOf("youtube", "you tube", "yutub", "yutube", "iutub", "iutube"),
            listOf("com.google.android.youtube", "com.google.android.apps.youtube.mango"), "https://www.youtube.com/"),
        Known(listOf("whatsapp", "wasap", "guasap", "wazap", "whats app", "guats app"),
            listOf("com.whatsapp", "com.whatsapp.w4b"), "https://wa.me/"),
        Known(listOf("instagram", "insta", "instagran"), listOf("com.instagram.android"), "https://www.instagram.com/"),
        Known(listOf("facebook", "feisbuk", "face"), listOf("com.facebook.katana", "com.facebook.lite"), "https://www.facebook.com/"),
        Known(listOf("telegram", "telegran"), listOf("org.telegram.messenger", "org.telegram.messenger.web"), "https://web.telegram.org/"),
        Known(listOf("spotify", "espotifai"), listOf("com.spotify.music"), "https://open.spotify.com/"),
        Known(listOf("netflix"), listOf("com.netflix.mediaclient"), "https://www.netflix.com/"),
        Known(listOf("twitter", "x"), listOf("com.twitter.android"), "https://x.com/"),
        Known(listOf("play store", "playstore", "google play"), listOf("com.android.vending"), null),
        Known(listOf("chrome", "crome"), listOf("com.android.chrome"), "https://www.google.com/"),
        Known(listOf("maps", "mapas", "google maps"), listOf("com.google.android.apps.maps"), "https://maps.google.com/")
    )

    private fun installedApps(): List<Pair<String, String>> {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return try {
            pm.queryIntentActivities(main, 0).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .filter { it.first != packageName }.distinctBy { it.first }
        } catch (e: Exception) { emptyList() }
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val t = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = t
            }
        }
        return d[b.length]
    }

    /** Busca en las apps instaladas ignorando espacios, acentos y cómo «suena» (tik tok = TikTok). */
    private fun findApp(q: String): Pair<String, String>? {
        val apps = installedApps()
        val nq = BernadetteParser.norm(q)
        val pq = BernadetteParser.phon(q)
        if (nq.isEmpty()) return null
        fun pick(f: (String) -> Boolean) = apps.firstOrNull { f(BernadetteParser.norm(it.second)) }
        fun pickP(f: (String) -> Boolean) = apps.firstOrNull { f(BernadetteParser.phon(it.second)) }
        pick { it == nq }?.let { return it }
        pickP { it == pq }?.let { return it }
        pick { it.startsWith(nq) }?.let { return it }
        pickP { pq.length >= 3 && it.startsWith(pq) }?.let { return it }
        pick { it.contains(nq) }?.let { return it }
        pickP { pq.length >= 4 && it.contains(pq) }?.let { return it }
        pick { it.length >= 3 && nq.contains(it) }?.let { return it }
        // alias conocidos («tic toc», «yutub», «wasap»…) → paquete instalado
        for (k in KNOWN) {
            if (k.names.any { BernadetteParser.phon(it) == pq || (pq.length >= 4 && lev(BernadetteParser.phon(it), pq) <= 1) }) {
                apps.firstOrNull { it.first in k.pkgs }?.let { return it }
                k.pkgs.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }?.let { return it to k.names[0] }
            }
        }
        // tolerancia a errores del reconocedor (una letra de diferencia)
        if (pq.length >= 4) {
            val lim = if (pq.length >= 7) 2 else 1
            return apps.map { it to lev(BernadetteParser.phon(it.second), pq) }
                .filter { it.second <= lim }.minByOrNull { it.second }?.first
        }
        return null
    }

    /** Última salida: si la app es conocida pero no la encuentro, abro su enlace web. */
    private fun webFallback(q: String): String? {
        val pq = BernadetteParser.phon(q)
        val k = KNOWN.firstOrNull { k -> k.web != null && k.names.any { BernadetteParser.phon(it) == pq || (pq.length >= 4 && lev(BernadetteParser.phon(it), pq) <= 1) } } ?: return null
        val v = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(k.web)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (launch(v)) "No vi la aplicación ${k.names[0]}, así que abrí su página web." else null
    }

    private fun launchApp(pkg: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { startActivity(i); true } catch (e: Exception) { false }
    }

    private fun openApp(q: String, search: String?): String {
        val m = findApp(q) ?: return webFallback(q) ?: "No encontré la aplicación $q."
        if (search.isNullOrBlank()) {
            return if (launchApp(m.first)) "Abriendo ${m.second}." else "No pude abrir ${m.second}."
        }
        val enc = android.net.Uri.encode(search)
        val nl = BernadetteParser.norm(m.second)
        val tries = ArrayList<Intent>()
        var sure = false
        when {
            "youtube" in nl && "music" !in nl -> {
                sure = true
                tries.add(Intent(Intent.ACTION_SEARCH).putExtra("query", search))
                tries.add(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com/results?search_query=$enc")))
            }
            "tiktok" in nl -> tries.add(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.tiktok.com/search?q=$enc")))
            "spotify" in nl -> tries.add(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("spotify:search:$enc")))
            "maps" in nl || "mapas" in nl -> { sure = true; tries.add(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q=$enc"))) }
            "play store" in nl || "google play" in nl -> { sure = true; tries.add(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("market://search?q=$enc"))) }
            "chrome" in nl || "navegador" in nl -> { sure = true; tries.add(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=$enc"))) }
            else -> tries.add(Intent(Intent.ACTION_SEARCH).putExtra(android.app.SearchManager.QUERY, search))
        }
        for (i in tries) {
            i.setPackage(m.first)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                if (i.resolveActivity(packageManager) != null) {
                    startActivity(i)
                    return if (sure) "Buscando $search en ${m.second}." else "Abrí ${m.second} e intenté buscar $search."
                }
            } catch (_: Exception) {}
        }
        return if (launchApp(m.first)) "Abrí ${m.second}, pero no pude buscar dentro de esa aplicación." else "No pude abrir ${m.second}."
    }

    private fun webSearch(q: String): String {
        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(android.app.SearchManager.QUERY, q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (launch(i)) return "Buscando $q en internet."
        val v = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(q)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (launch(v)) "Buscando $q en internet." else "No pude abrir el navegador."
    }

    // ---- calendario
    private fun writableCalendar(): Long? {
        val cr = contentResolver
        cr.query(
            android.provider.CalendarContract.Calendars.CONTENT_URI,
            arrayOf(android.provider.CalendarContract.Calendars._ID),
            android.provider.CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + " >= ? AND " +
                android.provider.CalendarContract.Calendars.VISIBLE + " = 1",
            arrayOf("500"),
            android.provider.CalendarContract.Calendars.IS_PRIMARY + " DESC"
        )?.use { if (it.moveToFirst()) return it.getLong(0) }
        return null
    }

    private fun dayText(daysAhead: Int): String = when (daysAhead) {
        0 -> "hoy"
        1 -> "mañana"
        2 -> "pasado mañana"
        else -> "el " + java.time.LocalDate.now().plusDays(daysAhead.toLong())
            .format(java.time.format.DateTimeFormatter.ofPattern("EEEE d 'de' MMMM", Locale("es", "AR")))
    }

    private fun addEvent(c: Cmd.Event): String {
        val day = java.time.LocalDate.now().plusDays(c.daysAhead.toLong())
        val zone = java.time.ZoneId.systemDefault()
        val begin: Long
        val end: Long
        if (c.hasTime) {
            begin = day.atTime(c.hour, c.minute).atZone(zone).toInstant().toEpochMilli()
            end = begin + 3_600_000L
        } else {
            begin = day.atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli()
            end = begin + 86_400_000L
        }
        var saved = false
        if (hasCalendar(this)) {
            try {
                val id = writableCalendar()
                if (id != null) {
                    val v = android.content.ContentValues()
                    v.put(android.provider.CalendarContract.Events.CALENDAR_ID, id)
                    v.put(android.provider.CalendarContract.Events.TITLE, c.title)
                    v.put(android.provider.CalendarContract.Events.DTSTART, begin)
                    v.put(android.provider.CalendarContract.Events.DTEND, end)
                    v.put(android.provider.CalendarContract.Events.ALL_DAY, if (c.hasTime) 0 else 1)
                    v.put(android.provider.CalendarContract.Events.EVENT_TIMEZONE, if (c.hasTime) zone.id else "UTC")
                    saved = contentResolver.insert(android.provider.CalendarContract.Events.CONTENT_URI, v) != null
                }
            } catch (_: Exception) {}
        }
        if (!saved) {
            val i = Intent(Intent.ACTION_INSERT).setData(android.provider.CalendarContract.Events.CONTENT_URI)
                .putExtra(android.provider.CalendarContract.Events.TITLE, c.title)
                .putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
                .putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME, end)
                .putExtra(android.provider.CalendarContract.EXTRA_EVENT_ALL_DAY, !c.hasTime)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return if (launch(i)) "Abrí el calendario con ${c.title} listo; toca guardar para confirmarlo."
            else "No encontré una aplicación de calendario."
        }
        val whenText = dayText(c.daysAhead) + (if (c.hasTime)
            " a " + BernadetteParser.spokenTime(c.hour, c.minute) + (if (c.guessed) BernadetteParser.period(c.hour) else "") else "")
        return "Listo, agregué ${c.title} al calendario para $whenText."
    }

    // ---- leer notificaciones
    private fun readNotifs(c: Cmd.ReadNotifs): String {
        if (!listenerOn(this)) return "Necesito acceso a las notificaciones. Actívalo en los ajustes de Bernadette."
        c.alsoOpen?.let { q -> findApp(q)?.let { launchApp(it.first) } }
        val items = NotifStore.query(c.who, c.app, if (c.single) 1 else 5)
        if (items.isEmpty()) {
            val w = c.who ?: c.app
            return if (w != null) "No tengo mensajes recientes de $w." else "No tengo notificaciones recientes."
        }
        val sb = StringBuilder()
        if (items.size > 1) sb.append("Tienes ${items.size} ").append(if (c.who == null && c.app == null) "notificaciones. " else "mensajes. ")
        val general = c.who == null && c.app == null
        for (it in items) {
            if (general) sb.append("De ${it.app}, ")
            val line = if (it.title.isNotEmpty() && it.title != it.who) "${it.who} en ${it.title}" else it.who
            sb.append(line).append(" dice: ").append(it.text.take(240)).append(". ")
        }
        return sb.toString().trim()
    }

    private fun torch(on: Boolean): String {
        return try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return "Este teléfono no tiene linterna disponible."
            cm.setTorchMode(id, on)
            torchOn = on
            if (on) "Linterna encendida." else "Linterna apagada."
        } catch (e: Exception) { "No pude controlar la linterna." }
    }

    // ------------------------------------------------------------------ interfaz

    private fun floatingNow(): Boolean =
        Prefs.bool(this, "bern_float", true) && currentPkg.isNotEmpty() && currentPkg in floatApps(this) &&
            hasUsage(this) && Settings.canDrawOverlays(this)

    private fun showUi() {
        if (!Settings.canDrawOverlays(this)) { ui = Mode.NONE; return }
        if (floatingNow()) {
            ui = Mode.FLOAT
            ensureFloat()
        } else {
            ui = Mode.FULL
            showFull()
        }
    }

    private fun hideUi() {
        if (ui == Mode.FULL) removeFull(true)
        ui = Mode.NONE
        setState(BernadetteSphere.State.IDLE)
        fullSphere?.setLevel(0f)
        floatView?.setLevel(0f)
    }

    private fun setState(s: BernadetteSphere.State) {
        fullSphere?.state = s
        floatView?.state = s
    }

    private fun setText(t: String) {
        transcript?.let { it.text = t; it.visibility = if (t.isBlank()) View.GONE else View.VISIBLE }
    }

    private fun showFull() {
        if (fullView != null) return
        val dm = resources.displayMetrics
        val root = FrameLayout(this)          // sin fondo negro: no tapa lo que estás haciendo
        val sp = BernadetteSphere(this)
        sp.state = BernadetteSphere.State.LISTENING
        val frac = floatArrayOf(0.40f, 0.55f, 0.75f)[Prefs.int(this, "bern_size", 1).coerceIn(0, 2)]
        val size = (min(dm.widthPixels, dm.heightPixels) * frac).toInt()
        val slp = FrameLayout.LayoutParams(size, size, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        slp.bottomMargin = Ui.dp(this, 64)
        root.addView(sp, slp)
        val tv = TextView(this)
        tv.setTextColor(Color.parseColor("#C8FFE6"))
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        tv.gravity = Gravity.CENTER
        tv.maxLines = 3
        tv.setPadding(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), Ui.dp(this, 8))
        tv.background = Ui.glass(this, 18, true)
        tv.visibility = View.GONE
        val tlp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        tlp.bottomMargin = Ui.dp(this, 12)
        tlp.leftMargin = Ui.dp(this, 24)
        tlp.rightMargin = Ui.dp(this, 24)
        root.addView(tv, tlp)
        root.setOnClickListener { cancelByTouch() } // tocar la esfera cancela
        root.alpha = 0f
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM
        try {
            wm.addView(root, lp)
            root.animate().alpha(1f).setDuration(320).start()
            fullView = root; fullSphere = sp; transcript = tv
        } catch (e: Exception) { ui = Mode.NONE }
    }

    private fun removeFull(animate: Boolean) {
        val v = fullView ?: return
        fullView = null; fullSphere = null; transcript = null
        val kill = { try { wm.removeViewImmediate(v) } catch (_: Exception) {} }
        if (animate) v.animate().alpha(0f).setDuration(300).withEndAction(kill).start() else kill()
    }

    private fun ensureFloat() {
        if (floatView != null) return
        if (!Settings.canDrawOverlays(this)) return
        val dm = resources.displayMetrics
        val size = Ui.dp(this, 60)
        val sp = BernadetteSphere(this)
        sp.small = true
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val fx = Prefs.int(this, "bern_fx", 1000) / 1000f   // esquina superior derecha por defecto
        val fy = Prefs.int(this, "bern_fy", 120) / 1000f
        lp.x = ((dm.widthPixels - size) * fx).toInt().coerceIn(0, maxOf(0, dm.widthPixels - size))
        lp.y = ((dm.heightPixels - size) * fy).toInt().coerceIn(0, maxOf(0, dm.heightPixels - size))

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var drag = false
        val longPress = Runnable {
            drag = true
            sp.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            sp.scaleX = 1.2f; sp.scaleY = 1.2f
        }
        sp.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; drag = false
                    h.postDelayed(longPress, 400)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!drag) {
                        if (hypot(e.rawX - dx, e.rawY - dy) > slop) h.removeCallbacks(longPress)
                    } else {
                        val m = resources.displayMetrics
                        lp.x = (sx + e.rawX - dx).toInt().coerceIn(0, maxOf(0, m.widthPixels - size))
                        lp.y = (sy + e.rawY - dy).toInt().coerceIn(0, maxOf(0, m.heightPixels - size))
                        try { wm.updateViewLayout(sp, lp) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    h.removeCallbacks(longPress)
                    sp.scaleX = 1f; sp.scaleY = 1f
                    if (drag) {
                        val m = resources.displayMetrics
                        val rw = maxOf(1, m.widthPixels - size)
                        val rh = maxOf(1, m.heightPixels - size)
                        Prefs.setInt(this, "bern_fx", (lp.x * 1000f / rw).toInt().coerceIn(0, 1000))
                        Prefs.setInt(this, "bern_fy", (lp.y * 1000f / rh).toInt().coerceIn(0, 1000))
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        manualActivate()
                    }
                    drag = false
                }
            }
            true
        }
        try {
            wm.addView(sp, lp)
            floatView = sp; floatLp = lp
        } catch (e: Exception) {}
    }

    private fun removeFloat() {
        val v = floatView ?: return
        floatView = null; floatLp = null
        try { wm.removeViewImmediate(v) } catch (_: Exception) {}
    }

    /** Toque corto sobre la esfera flotante: escucha sin decir la palabra (útil si el juego usa el micrófono). */
    private fun manualActivate() {
        if (phase != Phase.WAKE) return
        destroyRecognizer()
        ui = Mode.FLOAT
        activate("")
    }

    // ------------------------------------------------------------------ app en primer plano (modo flotante)

    private val poll = object : Runnable {
        override fun run() {
            if (!screenOn) return
            try {
                val wantFloat = Prefs.bool(this@BernadetteService, "bern_float", true) &&
                    floatApps(this@BernadetteService).isNotEmpty() && hasUsage(this@BernadetteService) &&
                    Settings.canDrawOverlays(this@BernadetteService)
                if (wantFloat) {
                    readForeground()
                    if (phase == Phase.WAKE && ui != Mode.FULL) {
                        if (currentPkg in floatApps(this@BernadetteService)) ensureFloat() else removeFloat()
                    }
                } else if (phase == Phase.WAKE && ui == Mode.NONE) removeFloat()
            } catch (_: Exception) {}
            h.postDelayed(this, 1500)
        }
    }

    private fun readForeground() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastPoll == 0L) now - 3_600_000L else lastPoll - 1500L
        val ev = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED && e.packageName != "com.android.systemui") {
                currentPkg = e.packageName
            }
        }
        lastPoll = now
    }
}
