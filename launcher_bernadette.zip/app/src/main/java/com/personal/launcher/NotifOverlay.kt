package com.personal.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Aviso animado del launcher, dibujado SOBRE cualquier app (TikTok, juegos, etc.).
 *
 *  1) aparece una burbuja negra chica con el logo de la app;
 *  2) el logo gira como ruedita (izquierda ↔ derecha);
 *  3) detrás del logo se despliega el texto («Gaby», «respondió tu mensaje»);
 *  4) pasado el tiempo se pliega y desaparece.
 *
 * Vertical: burbuja arriba al centro. Horizontal: igual, pero más angosta
 * (como el aviso emergente del sistema en horizontal). No captura toques.
 */
object NotifOverlay {

    private val main = Handler(Looper.getMainLooper())
    private class Item(val icon: Drawable?, val title: String, val text: String?)
    private val queue = ArrayDeque<Item>()
    private var busy = false
    private var current: View? = null

    fun canDraw(c: Context): Boolean = Settings.canDrawOverlays(c)

    /** Muestra el aviso. Devuelve false si falta el permiso «Mostrar sobre otras apps». */
    fun show(c: Context, icon: Drawable?, title: String, text: String?): Boolean {
        if (!canDraw(c)) return false
        val app = c.applicationContext
        main.post {
            if (queue.size >= 5) queue.removeFirst()
            queue.addLast(Item(icon, title, text))
            if (!busy) next(app)
        }
        return true
    }

    private fun next(c: Context) {
        val it = queue.removeFirstOrNull()
        if (it == null) { busy = false; return }
        busy = true
        try {
            play(c, it)
        } catch (e: Exception) {
            current = null
            main.postDelayed({ next(c) }, 200)
        }
    }

    private fun dp(c: Context, v: Int) = Ui.dp(c, v)

    private fun play(c: Context, item: Item) {
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = c.resources.displayMetrics
        val land = c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val scale = Prefs.animScale(c)
        val animated = !Prefs.perfSave(c)
        val long = Prefs.int(c, "msg_dur", 0) == 1

        // --- piezas
        val h = dp(c, 52)
        val pill = LinearLayout(c)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(dp(c, 8), 0, dp(c, 8), 0)
        pill.background = GradientDrawable().apply {
            setColor(Color.BLACK)
            cornerRadius = h / 2f
        }
        pill.elevation = dp(c, 8).toFloat()

        val ico = ImageView(c)
        ico.setImageDrawable(item.icon)
        ico.scaleType = ImageView.ScaleType.CENTER_CROP
        ico.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        ico.clipToOutline = true
        pill.addView(ico, LinearLayout.LayoutParams(dp(c, 36), dp(c, 36)))

        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_VERTICAL
        val t1 = TextView(c)
        t1.text = item.title
        t1.setTextColor(Color.WHITE)
        t1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        t1.typeface = Typeface.DEFAULT_BOLD
        t1.maxLines = 1
        t1.ellipsize = TextUtils.TruncateAt.END
        col.addView(t1)
        if (!item.text.isNullOrBlank()) {
            val t2 = TextView(c)
            t2.text = item.text
            t2.setTextColor(Color.parseColor("#CCFFFFFF"))
            t2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            t2.maxLines = 1
            t2.ellipsize = TextUtils.TruncateAt.END
            col.addView(t2)
        }
        val textLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT)
        textLp.leftMargin = dp(c, 10)
        textLp.rightMargin = dp(c, 8)
        pill.addView(col, textLp)

        // ancho final del texto (vertical: hasta ~78 % de pantalla; horizontal: ~40 %)
        val maxPill = (dm.widthPixels * (if (land) 0.40f else 0.78f)).toInt()
        val maxText = maxPill - dp(c, 8 + 36 + 8 + 10 + 8)
        col.measure(
            View.MeasureSpec.makeMeasureSpec(maxText, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val textW = col.measuredWidth.coerceIn(dp(c, 60), maxText)
        textLp.width = 0
        col.alpha = 0f

        val root = FrameLayout(c)
        root.addView(pill, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        root.alpha = 0f

        val sbId = c.resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (sbId > 0) c.resources.getDimensionPixelSize(sbId) else dp(c, 24)

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP
        lp.y = (if (land) dp(c, 6) else sb) + dp(c, 6)
        wm.addView(root, lp)
        current = root

        // --- animación
        pill.pivotX = 0f
        ico.pivotX = dp(c, 18).toFloat()
        ico.pivotY = dp(c, 18).toFloat()

        fun finish() {
            try { wm.removeViewImmediate(root) } catch (_: Exception) {}
            current = null
            main.postDelayed({ next(c) }, 120)
        }

        val enter = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(root, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(root, View.SCALE_X, 0.3f, 1f),
                ObjectAnimator.ofFloat(root, View.SCALE_Y, 0.3f, 1f)
            )
            interpolator = OvershootInterpolator(1.6f)
            duration = if (animated) (260 * scale).toLong() else 1
        }
        root.pivotY = 0f
        root.post { root.pivotX = root.width / 2f }

        val spin = ObjectAnimator.ofFloat(ico, View.ROTATION, 0f, -35f, 35f, -25f, 18f, -8f, 0f).apply {
            duration = if (animated) (900 * scale).toLong() else 1
            interpolator = DecelerateInterpolator(1.2f)
        }
        val expand = ValueAnimator.ofInt(0, textW).apply {
            duration = if (animated) (380 * scale).toLong() else 1
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                textLp.width = it.animatedValue as Int
                col.layoutParams = textLp
                col.alpha = it.animatedFraction
            }
        }
        val hold = ValueAnimator.ofInt(0, 1).apply { duration = if (long) 4500L else 2600L }
        val collapse = ValueAnimator.ofInt(textW, 0).apply {
            duration = if (animated) (300 * scale).toLong() else 1
            addUpdateListener {
                textLp.width = it.animatedValue as Int
                col.layoutParams = textLp
                col.alpha = 1f - it.animatedFraction
            }
        }
        val leave = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(root, View.ALPHA, 1f, 0f),
                ObjectAnimator.ofFloat(root, View.SCALE_X, 1f, 0.5f),
                ObjectAnimator.ofFloat(root, View.SCALE_Y, 1f, 0.5f)
            )
            duration = if (animated) (200 * scale).toLong() else 1
        }
        AnimatorSet().apply {
            playSequentially(enter, spin, expand, hold, collapse, leave)
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { finish() }
                override fun onAnimationCancel(a: Animator) { finish() }
            })
            start()
        }
    }
}
