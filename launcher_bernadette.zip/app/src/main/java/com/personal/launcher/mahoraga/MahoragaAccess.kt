package com.personal.launcher.mahoraga

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Servicio de accesibilidad mínimo: SOLO se usa para pedir a Android que haga una captura de pantalla
 * (acción global del sistema). No lee eventos ni el contenido de la pantalla.
 */
class MahoragaAccess : AccessibilityService() {
    companion object {
        @Volatile var inst: MahoragaAccess? = null

        fun screenshot(): Boolean = try {
            inst?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) ?: false
        } catch (e: Exception) { false }
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
