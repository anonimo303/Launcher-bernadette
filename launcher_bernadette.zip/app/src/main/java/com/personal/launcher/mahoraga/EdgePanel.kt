package com.personal.launcher.mahoraga

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.personal.launcher.Prefs
import com.personal.launcher.R
import kotlin.math.abs
import kotlin.math.min

/**
 * Pestaña lateral + panel gamer flotante, dibujados como ventanas superpuestas
 * (permiso «Mostrar sobre otras apps»). No toman foco: el juego sigue recibiendo el control.
 */
object EdgeUi {
    private val main = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var tab: View? = null
    private var panel: GamerPanel? = null
    var game: Game? = null
        private set
    val panelOpen: Boolean get() = panel != null
    val tabVisible: Boolean get() = tab != null
    var panelLeftPx = 0
        private set

    private fun wm(c: Context) = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    /** Llamado por el servicio: muestra la pestaña si hay un juego de la biblioteca en primer plano. */
    fun sync(c: Context, g: Game?) {
        val a = c.applicationContext
        main.post {
            app = a
            if (g == null || !Mh.panelEnabled(a) || !Mh.overlayGranted(a) || Mh.bubbleOff(a, g.pkg)) {
                game = null
                hideNow()
                return@post
            }
            if (game?.pkg != g.pkg) { hideNow(); game = g }
            if (panel == null && tab == null) showTab(a)
        }
    }

    fun hideAll() { main.post { game = null; hideNow() } }

    private fun hideNow() {
        val c = app ?: return
        tab?.let { try { wm(c).removeViewImmediate(it) } catch (e: Exception) { } }
        tab = null
        panel?.let { it.stop(); try { wm(c).removeViewImmediate(it.root) } catch (e: Exception) { } }
        panel = null
    }

    private fun showTab(c: Context) {
        val dm = c.resources.displayMetrics
        val w = Mh.dp(c, 16)
        val h = Mh.dp(c, 76)
        val r = Mh.dp(c, 10).toFloat()
        val v = FrameLayout(c)
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#CC241659"))
        bg.cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
        bg.setStroke(Mh.dp(c, 1), Mh.LINE)
        v.background = bg
        val ic = ImageView(c)
        ic.setImageResource(R.drawable.mh_ic_chev_l)
        ic.setColorFilter(Mh.VIOLET_L)
        v.addView(ic, FrameLayout.LayoutParams(Mh.dp(c, 14), Mh.dp(c, 14), Gravity.CENTER))

        val p = lp(w, h)
        p.gravity = Gravity.TOP or Gravity.END
        p.y = (dm.heightPixels * Prefs.int(c, "mh_tab_y", 35) / 100f).toInt()
        val slop = ViewConfiguration.get(c).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startY = 0; var mode = 0
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startY = p.y; mode = 0 }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (mode == 0) {
                        if (-dx > Mh.dp(c, 14) && abs(dx) > abs(dy)) { mode = 2; main.post { openPanel(c) } }
                        else if (abs(dy) > slop && abs(dy) > abs(dx)) mode = 1
                    }
                    if (mode == 1) {
                        p.y = (startY + dy).toInt().coerceIn(0, dm.heightPixels - h)
                        try { wm(c).updateViewLayout(v, p) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (mode == 0) main.post { openPanel(c) }
                    else if (mode == 1) Prefs.setInt(c, "mh_tab_y", (p.y * 100f / dm.heightPixels).toInt())
                }
            }
            true
        }
        try { wm(c).addView(v, p); tab = v } catch (e: Exception) { tab = null }
    }

    fun openPanel(c: Context) {
        val g = game ?: return
        if (panel != null) return
        tab?.let { try { wm(c).removeViewImmediate(it) } catch (e: Exception) { } }
        tab = null
        val dm = c.resources.displayMetrics
        val land = c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val handleW = Mh.dp(c, 26)
        val cardW = if (land) min(Mh.dp(c, 380), (dm.widthPixels * 0.46f).toInt())
        else min(dm.widthPixels - handleW - Mh.dp(c, 8), Mh.dp(c, 400))
        val gp = GamerPanel(c, g, cardW, handleW)
        val p = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        p.x = Mh.dp(c, 4)
        try {
            wm(c).addView(gp.root, p)
            panel = gp
            gp.start()
            gp.root.post {
                val loc = IntArray(2)
                gp.root.getLocationOnScreen(loc)
                panelLeftPx = loc[0]
            }
        } catch (e: Exception) { panel = null; showTab(c) }
    }

    fun closePanel(c: Context) {
        val gp = panel ?: return
        gp.stop()
        try { wm(c).removeViewImmediate(gp.root) } catch (e: Exception) { }
        panel = null
        panelLeftPx = 0
        if (game != null) showTab(c.applicationContext)
    }
}

/** Panel horizontal compacto, con el aspecto del diseño de referencia (Mahoraga + monitor + accesos + modos). */
class GamerPanel(private val ctx: Context, private val game: Game, cardW: Int, handleW: Int) {

    val root = LinearLayout(ctx)
    private val handler = Handler(Looper.getMainLooper())
    private val dm = ctx.resources.displayMetrics
    private var running = false
    private var armedKey: String? = null
    private var armedAt = 0L
    private var updating = false

    private lateinit var bCpu: Badge
    private lateinit var bRam: Badge
    private lateinit var bTemp: Badge
    private lateinit var bBat: Badge
    private lateinit var info: TextView
    private lateinit var msg: TextView
    private lateinit var tDnd: Tile
    private lateinit var swGamer: Switch
    private lateinit var subGamer: TextView
    private lateinit var swTherm: Switch
    private lateinit var subTherm: TextView

    private fun dp(v: Int) = Mh.dp(ctx, v)

    private inner class Badge(iconRes: Int, label: String, size: Int) : LinearLayout(ctx) {
        val value = Mh.text(ctx, "—", 13f, Mh.TEXT, true)
        init {
            orientation = VERTICAL
            gravity = Gravity.CENTER
            // margen interior para que el contenido quede dentro del círculo, no en las esquinas
            val pad = (size * 0.12f).toInt()
            setPadding(pad, pad, pad, pad)
            val ring = GradientDrawable()
            ring.shape = GradientDrawable.OVAL
            ring.setColor(Color.parseColor("#1A1040"))
            ring.setStroke(dp(2), Mh.VIOLET)
            background = ring
            val ic = ImageView(ctx)
            ic.setImageResource(iconRes)
            ic.setColorFilter(Mh.VIOLET_L)
            addView(ic, LayoutParams(dp(18), dp(18)))
            // los textos se centran (antes ocupaban todo el ancho y quedaban pegados a la izquierda)
            value.gravity = Gravity.CENTER
            value.maxLines = 1
            value.includeFontPadding = false
            addView(value, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val l = Mh.text(ctx, label, 9.5f, Mh.SUB)
            l.gravity = Gravity.CENTER
            l.maxLines = 1
            l.includeFontPadding = false
            addView(l, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fun set(t: String, color: Int) { value.text = t; value.setTextColor(color) }
    }

    private inner class Tile(icon: android.graphics.drawable.Drawable?, tint: Int?, label: String) : LinearLayout(ctx) {
        val iv = ImageView(ctx)
        val tv = Mh.text(ctx, label, 12f, Mh.TEXT)
        init {
            orientation = VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(8), dp(4), dp(8))
            background = Mh.round(Mh.CARD2, dp(14).toFloat(), Mh.LINE, dp(1))
            iv.setImageDrawable(icon)
            if (tint != null) iv.setColorFilter(tint)
            addView(iv, LayoutParams(dp(30), dp(30)))
            tv.gravity = Gravity.CENTER
            tv.maxLines = 1
            tv.ellipsize = android.text.TextUtils.TruncateAt.END
            addView(tv)
        }
        fun active(on: Boolean) {
            background = Mh.round(if (on) Color.parseColor("#4A2BB8") else Mh.CARD2, dp(14).toFloat(), if (on) Mh.VIOLET_L else Mh.LINE, dp(1))
        }
    }

    init {
        root.orientation = LinearLayout.HORIZONTAL
        root.gravity = Gravity.CENTER_VERTICAL

        // pestaña « para cerrar
        val handle = FrameLayout(ctx)
        val hr = dp(12).toFloat()
        val hb = GradientDrawable()
        hb.setColor(Color.parseColor("#F01B1146"))
        hb.cornerRadii = floatArrayOf(hr, hr, 0f, 0f, 0f, 0f, hr, hr)
        hb.setStroke(dp(1), Mh.LINE)
        handle.background = hb
        val hi = ImageView(ctx)
        hi.setImageResource(R.drawable.mh_ic_chev_l)
        hi.rotation = 180f
        hi.setColorFilter(Mh.VIOLET_L)
        handle.addView(hi, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        handle.setOnClickListener { EdgeUi.closePanel(ctx) }
        root.addView(handle, LinearLayout.LayoutParams(handleW, dp(80)))

        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(10))
        val cg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#F21E1250"), Color.parseColor("#F20E0724")))
        cg.cornerRadius = dp(22).toFloat()
        cg.setStroke(dp(2), Mh.VIOLET)
        card.background = cg

        // --- cabecera
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val face = ImageView(ctx)
        face.setImageResource(R.drawable.mh_icon)
        face.scaleType = ImageView.ScaleType.FIT_CENTER
        head.addView(face, LinearLayout.LayoutParams(dp(62), dp(62)))
        val titles = LinearLayout(ctx)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(8), 0, 0, 0)
        val t1 = Mh.text(ctx, "MAHORAGA", 19f, Mh.TEXT, true)
        t1.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD_ITALIC)
        val t2 = Mh.text(ctx, "GAMES", 22f, Mh.VIOLET_L, true)
        t2.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD_ITALIC)
        val t3 = Mh.text(ctx, "Rendimiento en tiempo real", 10.5f, Mh.SUB)
        titles.addView(t1); titles.addView(t2); titles.addView(t3)
        head.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gear = ImageView(ctx)
        gear.setImageResource(R.drawable.mh_ic_gear)
        gear.setColorFilter(Mh.VIOLET_L)
        gear.setPadding(dp(6), dp(6), dp(6), dp(6))
        gear.setOnClickListener {
            EdgeUi.closePanel(ctx)
            ctx.startActivity(Intent(ctx, MahoragaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("screen", "settings"))
        }
        head.addView(gear, LinearLayout.LayoutParams(dp(34), dp(34)))
        card.addView(head)

        // --- monitor
        val stats = LinearLayout(ctx)
        stats.orientation = LinearLayout.HORIZONTAL
        stats.gravity = Gravity.CENTER
        // círculos perfectos: mismo ancho y alto
        val bd = min((cardW - dp(24) - dp(24)) / 4, dp(78))
        bCpu = Badge(R.drawable.mh_ic_cpu, "CPU", bd)
        bRam = Badge(R.drawable.mh_ic_ram, "RAM", bd)
        bTemp = Badge(R.drawable.mh_ic_temp, "Temp.", bd)
        bBat = Badge(R.drawable.mh_ic_bat, "Bat.", bd)
        for (b in listOf(bCpu, bRam, bTemp, bBat)) {
            val lp = LinearLayout.LayoutParams(bd, bd)
            lp.setMargins(dp(3), 0, dp(3), 0)
            stats.addView(b, lp)
        }
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dp(8)
        card.addView(stats, slp)
        info = Mh.text(ctx, "", 10.5f, Mh.SUB)
        info.gravity = Gravity.CENTER
        info.setPadding(0, dp(4), 0, dp(6))
        card.addView(info)

        // --- único acceso rápido: No molestar. Las apps predeterminadas y captura/grabación
        // ya no aparecen en el panel; cada juego decide en su configuración si muestra DND.
        tDnd = Tile(ctx.getDrawable(R.drawable.mh_ic_moon), Mh.VIOLET_L, "No molestar")
        tDnd.setOnClickListener { onDnd() }
        val dndRow = LinearLayout(ctx)
        dndRow.orientation = LinearLayout.HORIZONTAL
        val dndLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dndLp.topMargin = dp(3)
        dndRow.addView(tDnd, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        card.addView(dndRow, dndLp)
        tDnd.visibility = if (Prefs.bool(ctx, "mh_dnd_show_${game.pkg}", true)) View.VISIBLE else View.GONE

        // --- modos
        val g1 = toggleRow(R.drawable.mh_ic_trend, "Modo Gamer")
        swGamer = g1.second; subGamer = g1.third
        card.addView(g1.first)
        val g2 = toggleRow(R.drawable.mh_ic_temp, "Control térmico")
        swTherm = g2.second; subTherm = g2.third
        card.addView(g2.first)
        swGamer.setOnCheckedChangeListener { _, on -> if (!updating) onGamer(on) }
        swTherm.setOnCheckedChangeListener { _, on -> if (!updating) onTherm(on) }

        msg = Mh.text(ctx, "", 11f, Mh.GOLD)
        msg.setPadding(dp(4), dp(6), dp(4), 0)
        msg.visibility = View.GONE
        card.addView(msg)

        val hide = LinearLayout(ctx)
        hide.orientation = LinearLayout.HORIZONTAL
        hide.gravity = Gravity.CENTER
        hide.background = Mh.round(Color.parseColor("#2E1D80"), dp(14).toFloat(), Mh.LINE, dp(1))
        val hic = ImageView(ctx)
        hic.setImageResource(R.drawable.mh_ic_chev_d)
        hic.setColorFilter(Mh.VIOLET_L)
        hide.addView(hic, LinearLayout.LayoutParams(dp(18), dp(18)))
        hide.addView(Mh.text(ctx, "  Ocultar panel", 13f, Mh.TEXT, true))
        hide.setPadding(0, dp(10), 0, dp(10))
        hide.setOnClickListener { EdgeUi.closePanel(ctx) }
        val hlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        hlp.topMargin = dp(8)
        card.addView(hide, hlp)

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(card)
        root.addView(sv, LinearLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT))
        refresh()
    }

    private fun appIcon(pkgs: List<String>) = pkgs.firstNotNullOfOrNull { Games.icon(ctx, it) }

    private fun row(vararg tiles: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        for (t in tiles) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(t, lp)
        }
        // relleno invisible para que una fila incompleta mantenga el mismo ancho de botón
        for (i in tiles.size until 3) {
            val lp = LinearLayout.LayoutParams(0, 1, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(View(ctx), lp)
        }
        return r
    }

    private fun toggleRow(iconRes: Int, title: String): Triple<LinearLayout, Switch, TextView> {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(10), dp(7), dp(10), dp(7))
        r.background = Mh.round(Mh.CARD2, dp(14).toFloat(), Mh.LINE, dp(1))
        val ic = ImageView(ctx)
        ic.setImageResource(iconRes)
        ic.setColorFilter(Mh.VIOLET_L)
        r.addView(ic, LinearLayout.LayoutParams(dp(26), dp(26)))
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(10), 0, dp(6), 0)
        col.addView(Mh.text(ctx, title, 13f, Mh.TEXT, true))
        val sub = Mh.text(ctx, "", 11f, Mh.SUB)
        col.addView(sub)
        r.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(ctx)
        sw.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sw.trackTintList = ColorStateList.valueOf(Mh.VIOLET)
        r.addView(sw)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        r.layoutParams = lp
        return Triple(r, sw, sub)
    }

    // ------------------------------------------------------------------ ciclo

    fun start() {
        if (running) return
        running = true
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (!running) return
                refresh()
                val light = Brain.activeIds(ctx, game.pkg).contains("light")
                handler.postDelayed(this, if (light) 3000L else 2000L)
            }
        }, 1500L)
    }

    fun stop() { running = false; handler.removeCallbacksAndMessages(null) }

    private fun refresh() {
        val s = Sys.sample(ctx)
        bCpu.set(if (s.cpuPct >= 0) "${s.cpuPct}%" else "N/D", if (s.cpuPct >= 90) Mh.BAD else Mh.TEXT)
        bRam.set(if (s.ramUsedPct >= 0) "${s.ramUsedPct}%" else "N/D", if (s.ramUsedPct >= 92) Mh.BAD else if (s.ramUsedPct >= 85) Mh.WARN else Mh.TEXT)
        val tc = if (s.battTemp.isNaN()) Mh.TEXT else if (s.battTemp >= 44f) Mh.BAD else if (s.battTemp >= 41f) Mh.WARN else Mh.TEXT
        bTemp.set(if (s.battTemp.isNaN()) "N/D" else "%.0f°C".format(s.battTemp), tc)
        bBat.set(if (s.battPct >= 0) "${s.battPct}%" else "N/D", if (s.battPct in 0..15 && !s.charging) Mh.WARN else Mh.TEXT)
        val sb = StringBuilder()
        if (s.battMv > 0) sb.append("Voltaje %.2f V · ".format(s.battMv / 1000.0)) else sb.append("Voltaje N/D · ")
        sb.append(if (s.fps >= 0) "FPS ${s.fps} · " else "FPS N/D · ").append("Térmico: ").append(Mh.thermalName(s.thermal))
        if (!s.skinTemp.isNaN()) sb.append(" · Piel %.0f°C".format(s.skinTemp))
        if (!s.zoneTemp.isNaN()) sb.append(" · Zona %.0f°C".format(s.zoneTemp))
        info.text = sb.toString()

        val has = Brain.hasAdaptation(ctx, game.pkg)
        val on = has && Prefs.bool(ctx, "mh_on_${game.pkg}", false)
        val thOn = Brain.thermalOn(ctx, game.pkg)
        updating = true
        swGamer.isChecked = on
        swTherm.isChecked = thOn
        updating = false
        subGamer.text = if (!has) "Sin adaptación (usa ADAPTACIÓN)" else if (on) "Perfil de ${game.name} aplicado" else "Desactivado"
        subTherm.text = if (!thOn) "Desactivado" else if (s.battTemp.isNaN()) "Vigilando" else if (s.battTemp >= 41f) "Temperatura alta" else if (s.battTemp >= 38f) "Temperatura templada" else "Temperatura estable"
        tDnd.active(Dnd.active(ctx))
        tDnd.visibility = if (Prefs.bool(ctx, "mh_dnd_show_${game.pkg}", true)) View.VISIBLE else View.GONE
    }

    private fun say(t: String) { msg.text = t; msg.visibility = View.VISIBLE }

    /** Pide una segunda pulsación (en 5 s) antes de salir del juego o abrir ajustes. */
    private fun arm(key: String, t: String): Boolean {
        val now = System.currentTimeMillis()
        if (armedKey == key && now - armedAt < 5000) { armedKey = null; return true }
        armedKey = key; armedAt = now
        say(t)
        return false
    }

    private fun openSettings(action: String) {
        try {
            ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { say("No se pudo abrir los ajustes.") }
    }

    private fun openMini(pkgs: List<String>, url: String?, name: String) {
        var found: Intent? = null
        for (p in pkgs) { found = Games.launchIntent(ctx, p); if (found != null) break }
        if (found == null && url != null) found = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        val intent: Intent = found ?: run { say("No se pudo abrir $name."); return }
        val free = Mh.freeformSupported(ctx)
        if (!free && Shz.granted()) {
            // Con Shizuku se activan solas las ventanas flotantes (sin entrar a Opciones del desarrollador).
            say("Activando las ventanas flotantes con Shizuku…")
            val ui = Handler(Looper.getMainLooper())
            Thread {
                val ok = try { Freeform.enable(ctx) } catch (e: Throwable) { false }
                ui.post {
                    say(if (ok) "Ventanas flotantes activadas. Toca $name otra vez; si se abre a pantalla completa, reinicia el teléfono una vez y vuelve a intentarlo."
                        else "No se pudieron activar las ventanas flotantes con Shizuku.")
                }
            }.start()
            return
        }
        if (!free && !arm("mini$name", "$name: este teléfono no admite ventanas flotantes de otras apps. Toca otra vez para abrirla a pantalla completa; el juego queda abierto en segundo plano.")) return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (free) {
                val o = ActivityOptions.makeBasic()
                val w = dm.widthPixels; val h = dm.heightPixels
                o.setLaunchBounds(Rect(dp(8), (h * 0.45f).toInt(), (w * 0.45f).toInt(), h - dp(8)))
                ctx.startActivity(intent, o.toBundle())
                say("$name abierto en ventana pequeña.")
            } else {
                EdgeUi.closePanel(ctx)
                ctx.startActivity(intent)
            }
        } catch (e: Exception) { say("No se pudo abrir $name.") }
    }

    private fun onShot() {
        if (!Mh.accessEnabled()) {
            if (arm("shot", "Para capturar, activa «MAHORAGA captura» en Accesibilidad. Toca otra vez para abrir los ajustes.")) openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            return
        }
        EdgeUi.closePanel(ctx)
        Handler(Looper.getMainLooper()).postDelayed({ MahoragaAccess.screenshot() }, 450L)
    }

    private fun onRec() {
        if (RecorderService.recording) { RecorderService.stop(ctx); say("Deteniendo grabación…"); return }
        say("Android pedirá confirmar la grabación de pantalla (se graba sin audio).")
        try {
            ctx.startActivity(Intent(ctx, RecordPermActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { say("No se pudo iniciar la grabación.") }
    }

    private fun onDnd() {
        if (!Mh.dndGranted(ctx)) {
            if (arm("dnd", "Falta el permiso de No molestar. Toca otra vez para abrir los ajustes.")) openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return
        }
        if (Dnd.active(ctx)) { Prefs.setBool(ctx, "mh_dnd_manual", false); Dnd.exit(ctx); say("No molestar desactivado.") }
        else { Dnd.enter(ctx); Prefs.setBool(ctx, "mh_dnd_manual", true); say("No molestar activado.") }
        tDnd.active(Dnd.active(ctx))
    }

    private fun onGamer(on: Boolean) {
        if (!Brain.hasAdaptation(ctx, game.pkg)) {
            say("Aún no hay adaptación para ${game.name}. Abre MAHORAGA y toca ADAPTACIÓN.")
            updating = true; swGamer.isChecked = false; updating = false
            return
        }
        Brain.setProfileOn(ctx, game.pkg, on)
        if (on && Prefs.bool(ctx, "mh_dnd_show_${game.pkg}", true) && Brain.activeIds(ctx, game.pkg).contains("dnd")) Dnd.enter(ctx)
        say(if (on) "Perfil aplicado." else "Perfil desactivado y No molestar restaurado.")
    }

    private fun onTherm(on: Boolean) {
        if (on && !Mh.notifGranted(ctx)) {
            say("Falta el permiso de notificaciones para los avisos.")
            updating = true; swTherm.isChecked = false; updating = false
            return
        }
        Prefs.setBool(ctx, "mh_th_${game.pkg}", on)
        say(if (on) "Avisos de temperatura activados." else "Avisos de temperatura desactivados.")
    }
}
