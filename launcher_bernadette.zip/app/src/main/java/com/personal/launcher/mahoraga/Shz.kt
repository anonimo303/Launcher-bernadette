package com.personal.launcher.mahoraga

import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit

class ShzResult(val code: Int, val out: String) {
    val ok: Boolean get() = code == 0
}

/**
 * Integración OPCIONAL con Shizuku. Solo ejecuta comandos fijos escritos aquí (nivel adb), nunca texto del usuario.
 * Todo corre en un hilo aparte para no bloquear la interfaz ni el juego.
 */
object Shz {
    const val REQ = 4711
    const val PKG = "moe.shizuku.privileged.api"

    // Últimas lecturas hechas con Shizuku (se descartan si tienen más de 9 s)
    @Volatile private var cpu = -1
    @Volatile private var fps = -1
    @Volatile private var skin = Float.NaN
    @Volatile private var stamp = 0L

    private var grantedAt = 0L
    private var grantedVal = false
    private var h: Handler? = null
    @Volatile private var polling = false
    @Volatile private var pollPkg: String? = null
    private var layer: String? = null
    private var layerAt = 0L
    private var lastTotal = 0L
    private var lastIdle = 0L
    private var hasPrev = false

    fun installed(c: Context): Boolean = Games.installed(c, PKG)
    fun running(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    fun invalidate() { grantedAt = 0L }
    fun uid(): Int = try { Shizuku.getUid() } catch (e: Throwable) { -1 }
    fun denied(): Boolean = try { Shizuku.shouldShowRequestPermissionRationale() } catch (e: Throwable) { false }

    fun granted(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - grantedAt < 4000L) return grantedVal
        grantedVal = try {
            Shizuku.pingBinder() && !Shizuku.isPreV11() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) { false }
        grantedAt = now
        return grantedVal
    }

    fun request(): Boolean = try { Shizuku.requestPermission(REQ); true } catch (e: Throwable) { false }

    fun mode(): String = when (uid()) {
        0 -> "root (Shizuku iniciado con root)"
        2000 -> "shell (nivel adb)"
        else -> "uid ${uid()}"
    }

    private fun safe(p: String) = p.matches(Regex("[A-Za-z0-9._]+"))

    /** newProcess es privado en las versiones recientes de la API de Shizuku: se llama por reflexión. */
    private val newProc by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).also { it.isAccessible = true }
    }

    /** Ejecuta un comando de shell con Shizuku. NO llamar desde el hilo principal. */
    fun exec(cmd: String, timeoutMs: Long = 4000L): ShzResult? {
        if (!granted()) return null
        return try {
            val p = newProc.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val done = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            if (!done) { p.destroy(); return ShzResult(-1, out.trim()) }
            ShzResult(p.exitValue(), out.trim())
        } catch (e: Throwable) { null }
    }

    private fun handler(): Handler {
        var x = h
        if (x == null) {
            val t = HandlerThread("mh-shz"); t.start()
            x = Handler(t.looper); h = x
        }
        return x
    }

    fun async(block: () -> Unit) { handler().post { try { block() } catch (e: Throwable) { } } }

    // ------------------------------------------------------------------ lecturas en vivo

    fun cpuFresh(): Int = if (SystemClock.elapsedRealtime() - stamp < 9000L) cpu else -1
    fun fpsFresh(): Int = if (SystemClock.elapsedRealtime() - stamp < 9000L) fps else -1
    fun skinFresh(): Float = if (SystemClock.elapsedRealtime() - stamp < 9000L) skin else Float.NaN

    fun startPoll(pkg: String) {
        if (!safe(pkg)) return
        if (pollPkg != pkg) { layer = null; layerAt = 0L; fps = -1 }
        pollPkg = pkg
        if (polling) return
        polling = true
        handler().post(task)
    }

    fun stopPoll() {
        if (!polling) return
        polling = false
        pollPkg = null
        h?.removeCallbacksAndMessages(null)
        cpu = -1; fps = -1; skin = Float.NaN
        layer = null; hasPrev = false
    }

    private val task = object : Runnable {
        override fun run() {
            if (!polling) return
            try { pollOnce() } catch (e: Throwable) { }
            if (polling) handler().postDelayed(this, 3000L)
        }
    }

    private fun pollOnce() {
        val pkg = pollPkg ?: return
        val r = exec("head -n 1 /proc/stat; echo @@T; dumpsys thermalservice | grep mValue", 3500L) ?: return
        val parts = r.out.split("@@T")
        parseCpu(parts[0])
        if (parts.size > 1) parseSkin(parts[1])
        stamp = SystemClock.elapsedRealtime()
        pollFps(pkg)
    }

    private fun parseCpu(s: String) {
        val line = s.lines().firstOrNull { it.startsWith("cpu ") } ?: return
        val p = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (p.size < 5) return
        val idle = p[3] + p[4]
        val total = p.sum()
        val dT = total - lastTotal
        val dI = idle - lastIdle
        val had = hasPrev
        lastTotal = total; lastIdle = idle; hasPrev = true
        if (had && dT > 0) cpu = ((dT - dI) * 100 / dT).toInt().coerceIn(0, 100)
    }

    private fun parseSkin(s: String) {
        val re = Regex("mValue=([-0-9.]+).*mName=([A-Za-z0-9_\\-]+)")
        for (ln in s.lines()) {
            val m = re.find(ln) ?: continue
            if (m.groupValues[2].contains("skin", ignoreCase = true)) {
                val v = m.groupValues[1].toFloatOrNull() ?: continue
                if (v in 0f..120f) { skin = v; return }
            }
        }
        skin = Float.NaN
    }

    /** FPS reales del juego a partir de las marcas de presentación de SurfaceFlinger (mejor esfuerzo). */
    private fun pollFps(pkg: String) {
        val now = SystemClock.elapsedRealtime()
        if (layer == null && now - layerAt > 15000L) {
            layerAt = now
            val l = exec("dumpsys SurfaceFlinger --list", 3500L)
            if (l != null) {
                val names = l.out.lines().map { it.trim() }.filter {
                    it.contains(pkg) && !it.startsWith("Background for") && !it.startsWith("Bounds for") && !it.startsWith("Dim Layer")
                }
                layer = names.firstOrNull { it.startsWith("SurfaceView") } ?: names.firstOrNull { it.contains("#") } ?: names.firstOrNull()
            }
        }
        val ly = layer
        if (ly == null) { fps = -1; return }
        val q = "'" + ly.replace("'", "'\\''") + "'"
        val r = exec("dumpsys SurfaceFlinger --latency $q", 3500L) ?: return
        val ts = ArrayList<Long>()
        val lines = r.out.lines()
        for (i in 1 until lines.size) {
            val c = lines[i].trim().split(Regex("\\s+"))
            if (c.size < 2) continue
            val t = c[1].toLongOrNull() ?: continue
            if (t > 0L && t != Long.MAX_VALUE) ts.add(t)
        }
        if (ts.size < 3) { fps = -1; layer = null; return }   // capa no válida: se vuelve a buscar
        val last = ts.max()
        val win = ts.filter { it >= last - 1_000_000_000L }.sorted()
        fps = if (win.size >= 2 && win.last() > win.first())
            ((win.size - 1) * 1_000_000_000L / (win.last() - win.first())).toInt().coerceIn(0, 240) else -1
    }

    // ------------------------------------------------------------------ acciones

    /** Cierra procesos en caché (am kill-all: solo lo que Android considera seguro) y guarda la RAM libre medida antes/después. */
    fun cleanMemory(c: Context, pkg: String) {
        val app = c.applicationContext
        async {
            val before = Sys.ramAvailMb(app)
            val r = exec("am kill-all", 6000L)
            SystemClock.sleep(2000L)
            val after = Sys.ramAvailMb(app)
            val rep = Reports.latest(app, pkg) ?: return@async
            val a = rep.actions.firstOrNull { it.id == "shz_clean" } ?: return@async
            a.detail = if (r != null && r.ok) "Última vez: RAM libre $before → $after MB (medido). No es reversible: las apps se reabren cuando las uses."
            else "Última vez: el comando no se ejecutó correctamente."
            Reports.save(app, rep)
        }
    }

    fun gameModeSet(pkg: String, mode: String): ShzResult? {
        if (!safe(pkg) || mode !in listOf("performance", "standard", "battery")) return null
        return exec("cmd game mode $mode $pkg", 4000L)
    }
}
