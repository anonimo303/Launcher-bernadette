package com.personal.launcher.mahoraga

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import com.personal.launcher.Prefs

/**
 * Red para jugar. Solo lo que REALMENTE actúa (sin mediciones ni avisos):
 *  · pide a Android el modo Wi-Fi de baja latencia mientras juegas (API oficial para juegos);
 *  · con Shizuku, FUERZA ese modo aunque el juego no lo pida (se revierte al salir);
 *  · si algo no funciona en este equipo, se anota y no se insiste.
 * Con datos móviles Android no deja a una app cambiar nada: ahí no se hace nada.
 * Android no permite a una app aumentar la señal real ni la velocidad contratada.
 */
object Net {
    private const val K_FORCED = "mh_net_forced"
    private var lock: WifiManager.WifiLock? = null

    fun forced(c: Context) = Prefs.bool(c, K_FORCED, false)

    /** ¿El teléfono sale a internet por Wi-Fi ahora? (decide si hay algo que optimizar; no mide nada) */
    @Suppress("DEPRECATION")
    private fun onWifi(c: Context): Boolean = try {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.allNetworks.any {
            val cp = cm.getNetworkCapabilities(it)
            cp != null && cp.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                !cp.hasTransport(NetworkCapabilities.TRANSPORT_VPN) &&
                cp.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }
    } catch (e: Exception) { false }

    /** NO llamar desde el hilo principal. Devuelve solo lo que de verdad se aplicó. */
    fun begin(c: Context, g: Game): List<String> {
        val app = c.applicationContext
        val applied = ArrayList<String>()
        if (!onWifi(app)) return applied
        if (acquireLock(app)) applied.add("Wi-Fi: modo de baja latencia solicitado a Android.")
        if (Shz.granted() && Ia.blocked(app, g.pkg, "net_force") == null) {
            if (force(true)) {
                Prefs.setBool(app, K_FORCED, true)
                applied.add("Wi-Fi forzado a baja latencia con Shizuku (se revierte al salir).")
            } else Ia.fail(app, g.pkg, "net_force", "este Android no tiene el modo forzado de Wi-Fi")
        }
        return applied
    }

    @Suppress("DEPRECATION")
    private fun acquireLock(c: Context): Boolean = try {
        release()
        val wm = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val l = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "mahoraga:net")
        l.setReferenceCounted(false)
        l.acquire()
        lock = l
        true
    } catch (e: Throwable) { false }

    private fun release() {
        try { lock?.let { if (it.isHeld) it.release() } } catch (e: Throwable) { }
        lock = null
    }

    /** Intenta el modo de baja latencia (Android 12+) y, si no existe, el de alto rendimiento (Android 10/11). */
    private fun force(on: Boolean): Boolean {
        val v = if (on) "enabled" else "disabled"
        val bad = Regex("(?i)error|exception|unknown|usage|invalid|unsupported|not found|denied|unrecognized")
        for (cmd in arrayOf("force-low-latency-mode", "force-hi-perf-mode")) {
            val r = Shz.exec("cmd wifi $cmd $v", 5000L) ?: return false
            if (r.ok && !bad.containsMatchIn(r.out)) return true
        }
        return false
    }

    /** Libera todo lo que se pidió para jugar. Seguro desde el hilo principal. */
    fun endAsync(c: Context) {
        release()
        val app = c.applicationContext
        if (!forced(app)) return
        Prefs.setBool(app, K_FORCED, false)
        Shz.async { force(false) }
    }
}
