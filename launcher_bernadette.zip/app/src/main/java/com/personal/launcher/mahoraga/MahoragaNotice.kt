package com.personal.launcher.mahoraga

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.personal.launcher.Prefs
import com.personal.launcher.R

/**
 * Notificación ESPECIAL de adaptación terminada. Es independiente de NotifOverlay (la de VERDANT no se toca).
 *  · Con el panel flotante abierto: tarjeta que se coloca en el lado libre, para no tapar sus controles.
 *  · Sin ventana emergente: píldora compacta con el icono de MAHORAGA y el mensaje.
 * En ambos casos la rueda dorada (imagen original) desciende, gira a pasos con pausas y se detiene.
 * Solo muestra acciones que realmente se aplicaron.
 */
object MahoragaNotice {
    private val main = Handler(Looper.getMainLooper())
    private var busy = false

    fun canShow(c: Context) = Mh.overlayGranted(c)

    fun show(c: Context, game: String, lines: List<String>, titleText: String = "¡MAHORAGA SE HA ADAPTADO!", sub: String? = null): Boolean {
        if (!canShow(c) || lines.isEmpty()) return false
        val app = c.applicationContext
        main.post {
            if (busy) return@post
            busy = true
            try { play(app, game, lines, titleText, sub) } catch (e: Exception) { busy = false }
        }
        return true
    }

    private fun play(c: Context, game: String, lines: List<String>, titleText: String, sub: String?) {
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = c.resources.displayMetrics
        val land = c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val scale = Prefs.animScale(c)
        val animated = !Prefs.bool(c, "perf_save", false)
        val full = EdgeUi.panelOpen
        fun dp(v: Int) = Mh.dp(c, v)

        // --- piezas
        val wheelSize = if (full) dp(54) else dp(30)
        val wheel = ImageView(c)
        wheel.setImageResource(R.drawable.mh_wheel)
        wheel.scaleType = ImageView.ScaleType.FIT_CENTER

        val title = Mh.text(c, titleText, if (full) 13f else 12f, Mh.GOLD, true)
        title.maxLines = 2
        val gameT = Mh.text(c, if (full) game else (sub ?: "$game · ${lines.size} ajuste${if (lines.size == 1) "" else "s"}"), if (full) 15f else 11f, Mh.TEXT, full)
        gameT.maxLines = 1
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_VERTICAL
        col.addView(title)
        col.addView(gameT)
        if (full) for (l in lines.take(4)) {
            val t = Mh.text(c, "• $l", 11.5f, Mh.SUB)
            t.maxLines = 1
            col.addView(t)
        }
        col.alpha = 0f

        val card = LinearLayout(c)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(10), dp(8), dp(12), dp(8))
        card.background = Mh.round(Color.parseColor("#F20E0724"), dp(if (full) 20 else 28).toFloat(), Mh.VIOLET, dp(1))
        card.elevation = dp(8).toFloat()

        if (full) {
            card.addView(wheel, LinearLayout.LayoutParams(wheelSize, wheelSize))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.leftMargin = dp(10)
            card.addView(col, lp)
        } else {
            val face = ImageView(c)
            face.setImageResource(R.drawable.mh_icon)
            card.addView(face, LinearLayout.LayoutParams(dp(36), dp(36)))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.leftMargin = dp(8); lp.rightMargin = dp(8)
            card.addView(col, lp)
            card.addView(wheel, LinearLayout.LayoutParams(wheelSize, wheelSize))
        }

        val maxW = if (full) {
            val free = if (EdgeUi.panelLeftPx > 0) EdgeUi.panelLeftPx - dp(16) else (dm.widthPixels * 0.9f).toInt()
            free.coerceIn(dp(200), dp(360))
        } else (dm.widthPixels * (if (land) 0.42f else 0.86f)).toInt()

        val root = FrameLayout(c)
        root.clipChildren = false
        card.clipChildren = false
        root.setPadding(0, dp(56), 0, 0)
        root.addView(card, FrameLayout.LayoutParams(if (full) maxW else ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            if (full) Gravity.TOP or Gravity.START else Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        root.alpha = 0f

        val sbId = c.resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (sbId > 0) c.resources.getDimensionPixelSize(sbId) else dp(24)
        val p = WindowManager.LayoutParams(
            if (full) ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = if (full) Gravity.TOP or Gravity.START else Gravity.TOP
        p.x = if (full) dp(8) else 0
        p.y = ((if (land) dp(6) else sb) + dp(6) - dp(56)).coerceAtLeast(0)
        wm.addView(root, p)

        fun finish() {
            try { wm.removeViewImmediate(root) } catch (e: Exception) { }
            busy = false
        }

        // --- animación
        fun d(ms: Long) = if (animated) (ms * scale).toLong() else 1L
        wheel.pivotX = wheelSize / 2f
        wheel.pivotY = wheelSize / 2f
        wheel.translationY = -dp(80).toFloat()
        wheel.alpha = 0f

        val enter = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(root, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(root, View.TRANSLATION_Y, -dp(70).toFloat(), 0f)
            )
            interpolator = OvershootInterpolator(1.2f)
            duration = d(380)
        }
        // la rueda desciende
        val drop = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(wheel, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(wheel, View.TRANSLATION_Y, -dp(80).toFloat(), 0f)
            )
            interpolator = DecelerateInterpolator(1.4f)
            duration = d(420)
        }
        // pequeños giros de 45° (un radio) con detenciones
        val steps = ArrayList<Animator>()
        var ang = 0f
        for (i in 0 until 3) {
            val to = ang + 45f
            steps.add(ObjectAnimator.ofFloat(wheel, View.ROTATION, ang, to).apply {
                duration = d(280); interpolator = OvershootInterpolator(2.4f)
            })
            steps.add(ValueAnimator.ofInt(0, 1).apply { duration = d(170) })   // pausa
            ang = to
        }
        val spin = AnimatorSet().apply { playSequentially(steps) }
        val textIn = ObjectAnimator.ofFloat(col, View.ALPHA, 0f, 1f).apply { duration = d(320) }
        val hold = ValueAnimator.ofInt(0, 1).apply { duration = if (full) 4200L else 3200L }
        val leave = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(root, View.ALPHA, 1f, 0f),
                ObjectAnimator.ofFloat(root, View.TRANSLATION_Y, 0f, -dp(30).toFloat())
            )
            duration = d(320)
        }
        val head = AnimatorSet().apply { playSequentially(enter, drop) }
        val mid = AnimatorSet().apply { playTogether(spin, textIn) }
        AnimatorSet().apply {
            playSequentially(head, mid, hold, leave)
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { finish() }
                override fun onAnimationCancel(a: Animator) { finish() }
            })
            start()
        }
    }
}
