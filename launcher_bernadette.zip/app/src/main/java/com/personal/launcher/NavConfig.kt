package com.personal.launcher

import android.content.Context

/** Pantallas navegables del launcher. */
enum class PageId(val key: String, val label: String, val icon: Int) {
    HOME("home", "Inicio", R.drawable.ic_home),
    APPS("apps", "Aplicaciones", R.drawable.ic_apps),
    RES("res", "Recursos", R.drawable.ic_resources)
}

/** Configuración de navegación compartida por los TRES estilos de barra. */
object NavConfig {
    const val STYLE_ARC = 0
    const val STYLE_BEAM = 1
    const val STYLE_BUBBLE = 2

    fun style(c: Context): Int = Prefs.int(c, "nav_style", STYLE_ARC).coerceIn(0, 2)

    fun swipe(c: Context): Boolean = Prefs.bool(c, "nav_swipe", false)

    /** Orden guardado de las tres pantallas (incluye las ocultas). */
    fun order(c: Context): List<PageId> {
        val saved = Prefs.str(c, "nav_order")
            ?.split(",")
            ?.mapNotNull { k -> PageId.values().firstOrNull { it.key == k } }
            ?.distinct()
            ?: emptyList()
        return saved + PageId.values().filter { it !in saved }
    }

    /** Inicio siempre está activo: el launcher no puede quedarse sin pantalla principal. */
    fun enabled(c: Context, p: PageId): Boolean =
        p == PageId.HOME || Prefs.bool(c, "nav_on_" + p.key, true)

    /** Pantallas visibles, en el orden elegido. */
    fun pages(c: Context): List<PageId> = order(c).filter { enabled(c, it) }

    /**
     * Pestañas de la barra. Con gestos activados, «Aplicaciones» se abre deslizando
     * y su acceso se oculta de la barra.
     */
    fun barPages(c: Context): List<PageId> =
        if (swipe(c)) pages(c).filter { it != PageId.APPS } else pages(c)

    fun move(c: Context, p: PageId, delta: Int) {
        val l = order(c).toMutableList()
        val i = l.indexOf(p)
        val j = i + delta
        if (i < 0 || j < 0 || j >= l.size) return
        val t = l[i]
        l[i] = l[j]
        l[j] = t
        Prefs.setStr(c, "nav_order", l.joinToString(",") { it.key })
    }
}
