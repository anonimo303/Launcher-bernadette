package com.personal.launcher

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    /** Multiplicador de duración según «Velocidad» (rápida / normal / lenta). */
    fun animScale(c: Context): Float = floatArrayOf(0.6f, 1f, 1.5f)[int(c, "anim_speed", 1).coerceIn(0, 2)]

    /** Las animaciones de navegación/cajón se anulan en «Modo ahorro». */
    fun animOn(c: Context): Boolean = bool(c, "anim_drawer", true) && !bool(c, "perf_save", false)

    /** Mensajes cortos del launcher, según «Notificaciones». */
    fun say(c: Context, s: String) {
        if (!bool(c, "msg_on", true)) return
        // Aviso animado del launcher (con el logo girando); si falta el permiso, Toast normal.
        val icon = try { c.packageManager.getApplicationIcon(c.packageName) } catch (e: Exception) { null }
        if (NotifOverlay.show(c, icon, "VERDANT", s)) return
        android.widget.Toast.makeText(
            c, s, if (int(c, "msg_dur", 0) == 1) android.widget.Toast.LENGTH_LONG else android.widget.Toast.LENGTH_SHORT
        ).show()
    }

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("verdant", Context.MODE_PRIVATE)

    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
    fun str(c: Context, k: String): String? = sp(c).getString(k, null)
    fun setStr(c: Context, k: String, v: String?) { sp(c).edit().putString(k, v).apply() }

    /** Claves de actividad ocultas del cajón (no desinstala ni deshabilita las apps). */
    fun hiddenApps(c: Context): Set<String> = str(c, "hidden_apps")
        ?.split("\n")?.filter { it.isNotBlank() }?.toSet() ?: emptySet()

    fun setHiddenApps(c: Context, keys: Set<String>) {
        setStr(c, "hidden_apps", keys.sorted().joinToString("\n").ifEmpty { null })
    }
}
