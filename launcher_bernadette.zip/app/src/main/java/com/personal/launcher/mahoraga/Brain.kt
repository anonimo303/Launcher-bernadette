package com.personal.launcher.mahoraga

import android.content.Context
import com.personal.launcher.Prefs

/**
 * Análisis y adaptación. Solo hace cosas REALES y que MAHORAGA puede hacer sin root:
 * vigilar, avisar, restaurar «No molestar» y reducir su propio consumo. Lo demás se marca
 * como recomendación o como no disponible; nunca se simula.
 */
object Brain {

    fun findings(s: Stats, verified: Boolean): List<Finding> {
        val out = ArrayList<Finding>()
        if (!verified) out.add(Finding(
            "No se pudo comprobar que el juego estuviera en primer plano (falta el Acceso de uso). Los datos corresponden a ${s.seconds / 60} min medidos, no necesariamente jugando.", false))
        if (s.ramTotalMb > 0) {
            val pct = s.ramAvailMin * 100 / s.ramTotalMb
            if (pct < 12 || s.lowMem) out.add(Finding(
                "Memoria disponible reducida: mínimo ${s.ramAvailMin} MB libres de ${s.ramTotalMb} MB ($pct %)" +
                    (if (s.lowMem) "; Android avisó de poca memoria." else "."), true))
            else out.add(Finding("Memoria correcta: mínimo ${s.ramAvailMin} MB libres de ${s.ramTotalMb} MB.", false))
        }
        if (s.swapTotalMb > 0 && s.swapUsedMax >= 0 && s.swapUsedMax * 100 / s.swapTotalMb >= 50)
            out.add(Finding("Memoria virtual muy usada: hasta ${s.swapUsedMax} MB de ${s.swapTotalMb} MB.", true))
        if (!s.tempMax.isNaN()) {
            val rise = if (s.tempStart.isNaN()) 0f else s.tempMax - s.tempStart
            if (s.tempMax >= 40f) out.add(Finding("Temperatura de batería alta: máximo %.1f °C.".format(s.tempMax), true))
            else out.add(Finding("Temperatura de batería controlada: máximo %.1f °C.".format(s.tempMax), false))
            if (rise >= 3f) out.add(Finding("La temperatura subió %.1f °C durante la medición.".format(rise), true))
        }
        if (s.thermalMax >= 2) out.add(Finding("Android reportó estado térmico «${Mh.thermalName(s.thermalMax)}».", true))
        if (s.cpuAvg >= 0) {
            if (s.cpuAvg >= 85) out.add(Finding("Carga de CPU alta: media ${s.cpuAvg} % (máx ${s.cpuMax} %).", true))
            else out.add(Finding("Carga de CPU: media ${s.cpuAvg} % (máx ${s.cpuMax} %).", false))
        } else out.add(Finding("La carga de CPU no se pudo medir (Android la bloquea a las apps; con Shizuku sí se puede). No se estima.", false))
        if (s.fpsAvg >= 0) {
            if (s.fpsAvg < 25) out.add(Finding("Fluidez baja: FPS medios ${s.fpsAvg} (mínimo ${s.fpsMin}), medidos con Shizuku.", true))
            else out.add(Finding("FPS medidos con Shizuku: media ${s.fpsAvg}, mínimo ${s.fpsMin}.", false))
        }
        if (s.freqMax >= 0) out.add(Finding("Frecuencia de CPU leída: media ${s.freqAvg} MHz, máx ${s.freqMax} MHz.", false))
        if (!s.charging && s.battStart >= 0 && s.battEnd >= 0 && s.seconds >= 120) {
            val drop = s.battStart - s.battEnd
            val perHour = drop * 3600 / s.seconds
            if (perHour >= 25) out.add(Finding("Consumo de batería elevado: bajó $drop % en ${s.seconds / 60} min (≈ $perHour % por hora, calculado a partir de la batería leída).", true))
        }
        if (out.none { it.problem }) out.add(Finding("No se detectaron problemas claros en esta medición.", false))
        return out
    }

    fun plan(c: Context, g: Game, s: Stats, fs: List<Finding>): MutableList<Action> {
        val acts = ArrayList<Action>()
        val mem = fs.any { it.problem && (it.text.startsWith("Memoria") || it.text.startsWith("Memoria virtual")) }
        val therm = fs.any { it.problem && (it.text.startsWith("Temperatura") || it.text.startsWith("La temperatura") || it.text.startsWith("Android reportó")) }
        val cpu = fs.any { it.problem && it.text.startsWith("Carga de CPU") }
        val fluid = fs.any { it.problem && it.text.startsWith("Fluidez") }

        val usage = Mh.usageGranted(c)
        acts.add(Action("monitor", "Monitorización durante la partida",
            if (usage) "recommended" else "unavailable",
            if (usage) "Vigilará memoria, temperatura, batería y estado térmico solo mientras el juego esté en primer plano."
            else "Falta el Acceso de uso: sin él MAHORAGA no sabe cuándo estás jugando.",
            "Acceso de uso"))
        val notif = Mh.notifGranted(c)
        val warn = if (!s.tempMax.isNaN() && s.tempMax >= 41f) 40 else 41
        acts.add(Action("thermal", "Control térmico (avisos)",
            if (notif) "recommended" else "unavailable",
            if (notif) "Te avisa si la batería llega a $warn °C. No toca frecuencias ni protecciones térmicas de Android."
            else "Falta el permiso de notificaciones.",
            "Notificaciones"))
        acts.add(Action("light", "Reducir actividad propia de MAHORAGA", "recommended",
            "Lectura cada 5 s y panel con refresco lento: MAHORAGA usa menos CPU y RAM mientras juegas.", "Ninguno"))
        val dnd = Mh.dndGranted(c)
        acts.add(Action("dnd", "No molestar automático en partida",
            if (dnd) "recommended" else "unavailable",
            if (dnd) "Se activa al entrar al juego y se restaura al salir, para que las notificaciones no interrumpan."
            else "Falta el permiso de acceso a No molestar.",
            "Acceso a No molestar"))

        when (g.profile) {
            "blood" -> acts.add(Action("rec_game", "Ajustes dentro de Blood Strike", "recommended",
                if (therm || cpu || mem || fluid) "Baja la calidad gráfica y las sombras y limita los FPS en los ajustes del juego para ganar estabilidad."
                else "Con estos datos no hace falta tocar nada; si notas tirones, baja gráficos o FPS desde el juego.", "Manual"))
            "ppsspp" -> acts.add(Action("rec_game", "Ajustes dentro de PPSSPP", "recommended",
                "En el emulador: resolución de renderizado 1x, salto de fotogramas automático y sin escalado de texturas. MAHORAGA no modifica su configuración.", "Manual"))
            else -> acts.add(Action("rec_game", "Ajustes dentro de ${g.name}", "recommended",
                if (therm || cpu || mem || fluid) "Baja calidad gráfica y FPS desde las opciones del juego." else "Sin problemas claros: no hace falta cambiar nada.", "Manual"))
        }
        // ---- Shizuku (opcional): solo comandos autorizados, medidos y, cuando se puede, reversibles
        val shz = Shz.granted()
        val noShz = "Shizuku no está activo o no autorizó a MAHORAGA (Configuración con Shizuku)."
        if (Prefs.bool(c, "mh_shz_meter", true)) acts.add(Action("shz_meter", "Medición real de CPU y FPS (Shizuku)",
            if (shz) "recommended" else "unavailable",
            if (shz) "Mide la carga de CPU y los FPS del juego con comandos de sistema mientras juegas. Los FPS son de mejor esfuerzo: si el juego no expone su capa gráfica, se muestran como N/D."
            else noShz, "Shizuku"))
        if (Prefs.bool(c, "mh_shz_game", true)) acts.add(Action("shz_gamemode", "Modo de juego de Android: rendimiento (Shizuku)",
            if (shz) "recommended" else "unavailable",
            if (shz) "Pide al sistema el modo Rendimiento para ${g.name}. Se verifica la respuesta del sistema; el efecto depende de que el juego lo soporte y no se presenta como FPS ganados. Reversible."
            else noShz, "Shizuku"))
        if (Boost.enabled(c)) acts.add(Action("shz_clean", "Preparar el sistema antes de jugar",
            "recommended",
            if (shz) "Mira qué apps gastan CPU/RAM en segundo plano y cierra las que no usas, limpia su caché y frena su actividad mientras juegas (se restaura al salir)" +
                (if (mem || cpu) ". Como el diagnóstico encontró " + (if (mem) "poca memoria" else "CPU alta") + ", actuará a nivel Normal o superior" else "") +
                ". Nunca toca apps protegidas, teclado, VPN, launcher ni apps con un servicio activo. Mide la RAM antes y después."
            else "Sin Shizuku solo puede pedir a Android que cierre procesos en caché (Android decide cuáles). Con Shizuku analiza el sistema y cierra de verdad lo que consume.",
            "Shizuku (opcional)"))
        if (!shz) acts.add(Action("fps", "Medir FPS", "unavailable",
            "Sin Shizuku, Android no deja a una app leer los FPS de otro juego. No se muestran ni se estiman.", "—"))
        acts.add(Action("freq", "Forzar frecuencias de CPU/GPU", "unavailable",
            "Requiere root o privilegios que MAHORAGA no pide ni simula.", "—"))
        return acts
    }

    fun activeIds(c: Context, pkg: String): Set<String> {
        if (!Prefs.bool(c, "mh_on_$pkg", false)) return emptySet()
        return (Prefs.str(c, "mh_ad_$pkg") ?: "").split(",").filter { it.isNotBlank() }.toSet()
    }

    fun hasAdaptation(c: Context, pkg: String): Boolean = !(Prefs.str(c, "mh_ad_$pkg") ?: "").isBlank()

    fun setProfileOn(c: Context, pkg: String, on: Boolean) {
        Prefs.setBool(c, "mh_on_$pkg", on)
        if (!on) Dnd.exit(c)
    }

    fun thermalOn(c: Context, pkg: String): Boolean =
        Prefs.bool(c, "mh_th_$pkg", activeIds(c, pkg).contains("thermal"))

    /** Aplica solo lo autorizado y posible. Devuelve las acciones realmente aplicadas. */
    fun apply(c: Context, r: Report): List<Action> {
        if (Shz.granted()) {
            val top = Shz.topRam(c)
            if (top != null) r.findings = r.findings.filter { !it.text.startsWith("Mayores consumidores") } + Finding(top, false)
        }
        val ids = ArrayList<String>()
        val done = ArrayList<Action>()
        for (a in r.actions) {
            if (a.status != "recommended") continue
            when (a.id) {
                "monitor" -> if (Mh.usageGranted(c)) { a.status = "applied"; a.detail = "Vigila el juego solo mientras está en primer plano."; ids.add(a.id); done.add(a) }
                    else { a.status = "unavailable"; a.detail = "Falta el Acceso de uso." }
                "thermal" -> if (Mh.notifGranted(c)) { a.status = "applied"; Prefs.setBool(c, "mh_th_${r.pkg}", true); ids.add(a.id); done.add(a) }
                    else { a.status = "unavailable"; a.detail = "Falta el permiso de notificaciones." }
                "light" -> { a.status = "applied"; ids.add(a.id); done.add(a) }
                "shz_meter" -> if (Shz.granted()) { a.status = "applied"; a.detail = "Mide CPU y FPS reales con Shizuku mientras el juego está en primer plano."; ids.add(a.id); done.add(a) }
                    else { a.status = "unavailable"; a.detail = "Shizuku no está activo o no autorizó a MAHORAGA." }
                "shz_gamemode" -> {
                    val res = Shz.gameModeSet(r.pkg, "performance")
                    if (res != null && res.ok && !Regex("(?i)error|exception|unknown|usage|not ").containsMatchIn(res.out)) {
                        a.status = "applied"; a.detail = "El sistema aceptó el modo Rendimiento. El efecto depende del juego; no se mide como FPS."
                        ids.add(a.id); done.add(a)
                    } else {
                        a.status = "unavailable"
                        a.detail = "El sistema no lo aceptó" + (if (res == null) " (Shizuku no disponible)." else ": " + res.out.take(80))
                    }
                }
                "shz_clean" -> {
                    if (r.findings.any { it.problem && (it.text.startsWith("Memoria") || it.text.startsWith("Carga de CPU")) }) Boost.escalate(c, r.pkg, 1)
                    a.status = "applied"
                    a.detail = if (Shz.granted()) "Se ejecuta antes de abrir el juego (JUGAR) y ahora mismo; el informe guarda la RAM libre medida antes y después."
                        else "Sin Shizuku: pide a Android cerrar procesos en caché antes de jugar. Con Shizuku analiza y cierra lo que consume."
                    ids.add(a.id); done.add(a)
                    Boost.runAsync(c, r.pkg)
                }
                "dnd" -> if (Mh.dndGranted(c)) { a.status = "applied"; a.detail = "Se activará al entrar al juego y se restaurará al salir."; ids.add(a.id); done.add(a) }
                    else { a.status = "unavailable"; a.detail = "Falta el permiso de acceso a No molestar." }
            }
        }
        Prefs.setStr(c, "mh_ad_${r.pkg}", ids.joinToString(","))
        Prefs.setBool(c, "mh_on_${r.pkg}", ids.isNotEmpty())
        r.applied = ids.isNotEmpty()
        r.appliedTs = System.currentTimeMillis()
        r.after = null
        Reports.save(c, r)
        MonitorService.ensure(c)
        return done
    }

    /** Texto corto de cada ajuste realmente aplicado. */
    fun lines(done: List<Action>): List<String> = done.map {
        when (it.id) {
            "monitor" -> "Monitorización durante la partida activada."
            "thermal" -> "Control térmico activado."
            "light" -> "Actividad propia de MAHORAGA reducida."
            "dnd" -> "No molestar automático configurado."
            "shz_meter" -> "Medición real de CPU y FPS activada."
            "shz_gamemode" -> "Modo Rendimiento de Android solicitado y aceptado."
            "shz_clean" -> "Sistema preparado: apps en segundo plano cerradas y caché liberada."
            else -> it.title
        }
    }

    fun revert(c: Context, r: Report) {
        val hadGameMode = r.actions.any { it.id == "shz_gamemode" && it.status == "applied" }
        for (a in r.actions) if (a.status == "applied") { a.status = "reverted"; a.detail = if (a.id == "shz_clean") "Desactivada: se restauran las apps frenadas o congeladas (las cerradas se reabren al usarlas)." else "Revertida por el usuario." }
        if (hadGameMode) Shz.async { Shz.gameModeSet(r.pkg, "standard") }
        Prefs.setStr(c, "mh_ad_${r.pkg}", null)
        Prefs.setBool(c, "mh_on_${r.pkg}", false)
        Prefs.setBool(c, "mh_th_${r.pkg}", false)
        Dnd.exit(c)
        Boost.restore(c)
        Boost.resetLearning(c, r.pkg)
        r.applied = false
        Reports.save(c, r)
    }
}
