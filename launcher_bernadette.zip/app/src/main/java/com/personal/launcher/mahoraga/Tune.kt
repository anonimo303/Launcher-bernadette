package com.personal.launcher.mahoraga

import android.content.Context
import com.personal.launcher.Prefs

/**
 * Ajustes automáticos con Shizuku (nivel adb, sin root). Todo es reversible y se comprueba la respuesta
 * del sistema: si Android no lo acepta, se marca como no disponible, nunca se simula.
 *  · Resolución del juego (Modo de juego de Android): menos carga de GPU y calor. Android reinicia el juego al
 *    cambiarla, por eso, si se está jugando, antes se pregunta Sí/No; si no se está jugando, se aplica en silencio.
 *  · Compilación del código del juego (speed-profile): menos tirones y menos CPU. No interrumpe nada.
 */
object Tune {
    private val bad = Regex("(?i)error|exception|unknown|usage|invalid|unsupported|failure|not found|denied")

    private fun safe(p: String) = p.matches(Regex("[A-Za-z0-9._]+"))

    fun tuneOn(c: Context): Boolean = Prefs.bool(c, "mh_shz_tune", true)
    fun compileOn(c: Context): Boolean = Prefs.bool(c, "mh_shz_compile", true)

    /** 0.9 si hay problemas leves; 0.8 si hay FPS bajos o estado térmico alto. */
    fun factorFor(s: Stats?): String {
        if (s == null) return "0.9"
        val hard = (s.fpsAvg in 0..24) || s.thermalMax >= 3 || (!s.tempMax.isNaN() && s.tempMax >= 43f)
        return if (hard) "0.8" else "0.9"
    }

    fun gameRunning(c: Context, pkg: String): Boolean = try {
        Mh.usageGranted(c) && Fg.top(c) == pkg
    } catch (e: Exception) { false }

    /** NO llamar desde el hilo principal. */
    fun applyResolution(pkg: String, factor: String): Boolean {
        if (!safe(pkg) || !factor.matches(Regex("0\\.[0-9]"))) return false
        val r = Shz.exec("cmd game set --mode performance --downscale $factor $pkg", 6000L) ?: return false
        return r.ok && !bad.containsMatchIn(r.out)
    }

    fun resetResolution(pkg: String) {
        if (!safe(pkg)) return
        Shz.exec("cmd game reset $pkg", 5000L)
    }

    /** NO llamar desde el hilo principal. Puede tardar unos minutos. */
    fun compile(pkg: String): Boolean {
        if (!safe(pkg)) return false
        val r = Shz.exec("cmd package compile -m speed-profile -f $pkg", 240_000L) ?: return false
        return r.ok && !r.out.contains("Failure", ignoreCase = true)
    }

    fun resetCompile(pkg: String) {
        if (!safe(pkg)) return
        Shz.exec("cmd package compile --reset $pkg", 120_000L)
    }

    /** Cierra y vuelve a abrir el juego (hace falta para que Android aplique la resolución nueva). */
    fun restartGame(pkg: String) {
        if (!safe(pkg)) return
        Shz.exec("am force-stop $pkg", 5000L)
        try { Thread.sleep(900L) } catch (e: Exception) { }
        Shz.exec("monkey -p $pkg -c android.intent.category.LAUNCHER 1", 8000L)
    }

    /** Cuando el juego ya no está en primer plano: aplica en silencio lo que estaba pendiente. */
    fun afterGame(c: Context, pkg: String) {
        if (!Shz.granted() || !safe(pkg)) return
        val app = c.applicationContext
        val wait = Prefs.bool(app, "mh_tune_wait_$pkg", false)
        val compileDue = Prefs.bool(app, "mh_compile_due_$pkg", false)
        if (!wait && !compileDue) return
        Shz.async {
            if (wait) {
                val f = Prefs.str(app, "mh_tune_f_$pkg") ?: "0.9"
                if (applyResolution(pkg, f)) Prefs.setBool(app, "mh_tune_wait_$pkg", false)
            }
            if (compileDue) {
                if (compile(pkg)) Prefs.setBool(app, "mh_compile_due_$pkg", false)
            }
        }
    }
}
