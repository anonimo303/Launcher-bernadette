package com.personal.launcher

import java.text.Normalizer
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

/** Órdenes que Bernadette entiende. */
sealed class Cmd {
    data class Alarm(val hour: Int, val minute: Int, val guessedPeriod: Boolean) : Cmd()
    data class Timer(val seconds: Int) : Cmd()
    data class OpenApp(val query: String, val search: String?) : Cmd()
    data class WebSearch(val q: String) : Cmd()
    data class Torch(val on: Boolean) : Cmd()
    /** Evento de calendario. [daysAhead] = días desde hoy. Sin hora → todo el día. */
    data class Event(val title: String, val daysAhead: Int, val hour: Int, val minute: Int,
                     val hasTime: Boolean, val guessed: Boolean) : Cmd()
    /** Leer notificaciones/mensajes guardados. [who] puede ser una app o un contacto. */
    data class ReadNotifs(val who: String?, val app: String?, val single: Boolean, val alsoOpen: String?) : Cmd()
    object TellTime : Cmd()
    object TellDate : Cmd()
    object Cancel : Cmd()
    object Unknown : Cmd()
}

/** Interpreta frases en español. Sin dependencias de Android (se prueba en cualquier JVM). */
object BernadetteParser {

    const val DEFAULT_NAME = "Bernadette"
    private val WAKE = listOf("bernadette", "bernadete", "bernadet", "bernardette", "bernardete", "bernardet", "bernadeta", "bernadeth",
        "bernabeth", "bernabet", "bernabe", "bernardo", "bernarda", "bernal", "bernat", "vernadette", "bernadett")

    /** Palabras extra con las que el teléfono suele «oír» el nombre (las edita el usuario). */
    @Volatile var aliases: List<String> = emptyList()

    /** Suena igual en español: b/v, h muda, c/z/s, qu/k, th/tt/dd, letras repetidas. */
    fun phon(s: String): String {
        var t = norm(s).replace(" ", "")
        t = t.replace("v", "b").replace("w", "b").replace("h", "").replace("z", "s")
            .replace(Regex("c([ei])"), "s$1").replace("qu", "k").replace("c", "k").replace("ll", "y")
        return t.replace(Regex("(.)\\1+"), "$1")
    }

    fun norm(s: String): String {
        val d = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        return d.replace(Regex("[^a-z0-9:.\\s]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val t = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = t
            }
        }
        return d[b.length]
    }

    /**
     * Si el texto contiene el nombre de la asistente devuelve lo dicho DESPUÉS (puede ser ""), si no null.
     * Tolera pequeñas confusiones del reconocedor de voz (más tolerante cuanto más largo el nombre).
     */
    fun afterWake(text: String, name: String = DEFAULT_NAME, extraTokens: Int = 1): String? {
        val tokens = norm(text).split(" ").map { it.trim('.', ':') }.filter { it.isNotEmpty() }
        val nameN = norm(name)
        val nt = nameN.split(" ").filter { it.isNotEmpty() }
        if (tokens.isEmpty() || nt.isEmpty()) return null
        val cands = ArrayList<String>()
        cands.add(nt.joinToString(""))
        if (nameN == norm(DEFAULT_NAME)) cands.addAll(WAKE)
        aliases.map { norm(it).replace(" ", "") }.filter { it.length >= 4 }.forEach { cands.add(it) }
        val pc = cands.map { phon(it) }.distinct()
        for (i in tokens.indices) {
            for (k in nt.size..(nt.size + extraTokens)) {
                if (i + k > tokens.size) continue
                val w = phon(tokens.subList(i, i + k).joinToString(""))
                if (w.length < 4) continue
                for (c in pc) {
                    val lim = when { c.length <= 3 -> 0; c.length <= 6 -> 1; else -> 2 }
                    if (lev(w, c) <= lim) return tokens.drop(i + k).joinToString(" ")
                }
            }
        }
        return null
    }

    // ------------------------------------------------------------ números en palabras
    private val UNITS = mapOf(
        "cero" to 0, "un" to 1, "uno" to 1, "una" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12,
        "trece" to 13, "catorce" to 14, "quince" to 15, "dieciseis" to 16, "diecisiete" to 17,
        "dieciocho" to 18, "diecinueve" to 19, "veinte" to 20, "veintiun" to 21, "veintiuno" to 21,
        "veintiuna" to 21, "veintidos" to 22, "veintitres" to 23, "veinticuatro" to 24, "veinticinco" to 25,
        "veintiseis" to 26, "veintisiete" to 27, "veintiocho" to 28, "veintinueve" to 29
    )
    private val TENS = mapOf("treinta" to 30, "cuarenta" to 40, "cincuenta" to 50, "sesenta" to 60)

    /** Cambia los números escritos con letras por dígitos: «ocho y media» → «8 y media». */
    fun digits(s: String): String {
        val t = norm(s).replace(Regex("(\\d)\\.(\\d{2})\\b"), "$1:$2").split(" ")
        val out = ArrayList<String>()
        var i = 0
        while (i < t.size) {
            val w = t[i]
            val ten = TENS[w]
            if (ten != null) {
                val u = if (i + 2 < t.size && t[i + 1] == "y") UNITS[t[i + 2]] else null
                if (u != null && u in 1..9) { out.add((ten + u).toString()); i += 3; continue }
                out.add(ten.toString()); i++; continue
            }
            val v = UNITS[w]
            out.add(v?.toString() ?: w)
            i++
        }
        return out.joinToString(" ")
    }

    fun numberWord(n: Int): String {
        val u = listOf("cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez",
            "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve",
            "veinte", "veintiuno", "veintidós", "veintitrés", "veinticuatro", "veinticinco", "veintiséis",
            "veintisiete", "veintiocho", "veintinueve")
        if (n < 30) return u[n]
        val t = mapOf(30 to "treinta", 40 to "cuarenta", 50 to "cincuenta")
        val r = n % 10
        return t[n - r]!! + if (r == 0) "" else " y " + u[r]
    }

    /** «las ocho y media», «la una en punto», «las nueve menos cuarto». */
    fun spokenTime(h24: Int, m: Int): String {
        var h = h24
        val tail: String
        when {
            m == 0 -> tail = " en punto"
            m == 30 -> tail = " y media"
            m == 15 -> tail = " y cuarto"
            m == 45 -> { h = (h + 1) % 24; tail = " menos cuarto" }
            else -> tail = " y " + numberWord(m)
        }
        val h12 = if (h % 12 == 0) 12 else h % 12
        val art = if (h12 == 1) "la" else "las"
        val hw = if (h12 == 1) "una" else numberWord(h12)
        return "$art $hw$tail"
    }

    fun period(h24: Int): String = when (h24) {
        in 0..5 -> " de la madrugada"
        in 6..11 -> " de la mañana"
        12 -> " del mediodía"
        in 13..19 -> " de la tarde"
        else -> " de la noche"
    }

    // ------------------------------------------------------------ interpretación
    fun parse(text: String, now: LocalDateTime): Cmd {
        val s = digits(text)
        val n = norm(text)
        if (s.isBlank()) return Cmd.Unknown
        val has = { r: String -> Regex(r).containsMatchIn(s) }

        if (has("\\b(cancela|cancelar|olvidalo|dejalo|no importa|nada|gracias)\\b")) return Cmd.Cancel
        if (has("\\blinterna\\b")) {
            return if (has("\\b(apaga|apagar|apagues|desactiva|desactivar|quita)\\b")) Cmd.Torch(false) else Cmd.Torch(true)
        }
        if (has("\\b(temporizador|timer|avisame en|cuenta regresiva)\\b")) {
            val sec = durationSeconds(s)
            return if (sec > 0) Cmd.Timer(sec) else Cmd.Unknown
        }
        if (has("\\b(alarma|despiertame|despertame|despiertarme)\\b")) {
            val t = timeSpec(s) ?: return Cmd.Unknown
            var h = t.h
            var guessed = false
            if (t.ambiguous) {
                guessed = true
                val a = h % 12
                val b = a + 12
                fun delta(x: Int): Int { var d = (x * 60 + t.min) - (now.hour * 60 + now.minute); if (d <= 0) d += 1440; return d }
                h = if (delta(a) <= delta(b)) a else b
            }
            return Cmd.Alarm(h, t.min, guessed)
        }
        if (has("\\b(calendario|agenda|evento|recordatorio|recordame|recuerdame|agendame)\\b")) {
            return parseEvent(s, now) ?: Cmd.Unknown
        }
        // leer notificaciones / mensajes
        if (Regex("\\b(lee|leeme|leer|leame|lea|decime|dime|dimelo|cuentame|contame)\\b.*\\b(notificacion|notificaciones|mensaje|mensajes)\\b").containsMatchIn(n) ||
            Regex("\\b(que|cuales) (mensajes|notificaciones) (tengo|hay)\\b|\\btengo (mensajes|notificaciones)\\b").containsMatchIn(n)) {
            return parseRead(n)
        }
        // abrir apps (con o sin búsqueda)
        val open = Regex("\\b(abre|abri|abrir|abrime|inicia|iniciar|lanza|lanzar|ejecuta|ejecutar)\\s+(.+)$").find(n)
        if (open != null) {
            var rest = open.groupValues[2]
            var search: String? = null
            val sp = Regex("^(.+?)\\s+(?:y|e|y luego|y despues|y ahi)?\\s*(?:busca|buscar|buscame|busque|pon|ponme|poner|reproduce|reproducir)\\s+(.+)$").find(rest)
            if (sp != null) { rest = sp.groupValues[1]; search = cleanSearch(sp.groupValues[2]) }
            val app = cleanApp(rest)
            if (app.isNotEmpty()) return Cmd.OpenApp(app, search?.ifEmpty { null })
        }
        val sr = Regex("\\b(busca|buscar|buscame|busque)\\s+(.+)$").find(n)
        if (sr != null) {
            val body = sr.groupValues[2]
            val inApp = Regex("^(.+?)\\s+(?:en|dentro de)\\s+(.+)$").find(body)
            if (inApp != null) {
                val app = cleanApp(inApp.groupValues[2])
                val q = cleanSearch(inApp.groupValues[1])
                if (app.isNotEmpty() && q.isNotEmpty() && app != "google" && app != "internet") return Cmd.OpenApp(app, q)
                if (q.isNotEmpty()) return Cmd.WebSearch(q)
            }
            val q = cleanSearch(body)
            if (q.isNotEmpty()) return Cmd.WebSearch(q)
        }
        if (has("\\bque hora\\b|\\bla hora\\b|\\bhora es\\b")) return Cmd.TellTime
        if (has("\\bque dia\\b|\\bque fecha\\b|\\bla fecha\\b|\\bfecha de hoy\\b")) return Cmd.TellDate
        return Cmd.Unknown
    }

    private fun cleanApp(r: String): String {
        var q = r.replace(Regex("^(la |el |los |las )?(aplicacion|app|programa)( de| del)? "), "")
        q = q.replace(Regex("^(la |el |los |las |de |del )+"), "").trim()
        return q.replace(Regex("\\s+(por favor|porfa)$"), "")
    }

    private fun cleanSearch(r: String): String =
        r.replace(Regex("^(en|de|sobre|por|el|la|los|las|un|una)\\s+(?=\\S)"), "")
            .replace(Regex("\\s+(por favor|porfa)$"), "").trim()

    private fun parseRead(n: String): Cmd {
        val single = Regex("\\b(el|ese|mi|el ultimo|ultimo) (ultimo )?(mensaje|notificacion)\\b").containsMatchIn(n) &&
            !Regex("\\b(mensajes|notificaciones)\\b").containsMatchIn(n)
        val also = Regex("\\b(?:abre|abri|abrir)\\s+([a-z0-9]+)").find(n)?.groupValues?.get(1)
        val m = Regex("\\b(?:mensajes?|notificacion(?:es)?)\\s+(?:de|del|desde)\\s+(.+)$").find(n)
        var who: String? = null
        var app: String? = null
        if (m != null) {
            var r = m.groupValues[1].replace(Regex("\\s+(por favor|porfa)$"), "")
            val en = Regex("^(.+?)\\s+en\\s+(.+)$").find(r)
            if (en != null) { r = en.groupValues[1]; app = en.groupValues[2] }
            r = r.replace(Regex("^(la|el|los|las|mi)\\s+(?=\\S)"), "")
            who = r.ifEmpty { null }
        }
        return Cmd.ReadNotifs(who, app, single, also)
    }

    // ------------------------------------------------------------ tiempo
    private data class TimeSpec(val h: Int, val min: Int, val ambiguous: Boolean)

    private fun durationSeconds(s: String): Int {
        var total = 0
        if (Regex("\\bmedia hora\\b").containsMatchIn(s)) total += 1800
        val r = Regex("(\\d+)\\s*(horas?|hs|minutos?|mins?|segundos?|segs?)\\b(?:\\s+y\\s+media\\b)?")
        for (m in r.findAll(s)) {
            val n = m.groupValues[1].toInt()
            val u = m.groupValues[2]
            val half = m.value.endsWith("media")
            when {
                u.startsWith("h") -> total += n * 3600 + (if (half) 1800 else 0)
                u.startsWith("m") -> total += n * 60 + (if (half) 30 else 0)
                else -> total += n
            }
        }
        return total
    }

    /** Hora dicha en la frase (ya con números en dígitos). */
    private fun timeSpec(s: String): TimeSpec? {
        val m = Regex("\\b(?:a la|a las|para la|para las|las|la)\\s+(\\d{1,2})(?::(\\d{2}))?(.*)$").find(s)
            ?: Regex("\\b(\\d{1,2}):(\\d{2})(.*)$").find(s)
            ?: return null
        val rawH = m.groupValues[1].toInt()
        var h = rawH
        var min = 0
        var rest = m.groupValues[3]
        if (m.groupValues[2].isNotEmpty()) min = m.groupValues[2].toInt()
        else {
            val t = rest.trim()
            val mm = Regex("^y (\\d{1,2})\\b(.*)").find(t)
            val bare = Regex("^(\\d{2})\\b(.*)").find(t)
            val menos = Regex("^menos (\\d{1,2})\\b(.*)").find(t)
            fun back() { h = if (rawH == 1) 12 else if (rawH == 0) 23 else rawH - 1 }
            when {
                t.startsWith("y media") -> { min = 30; rest = t.removePrefix("y media") }
                t.startsWith("y cuarto") -> { min = 15; rest = t.removePrefix("y cuarto") }
                t.startsWith("menos cuarto") -> { min = 45; back(); rest = t.removePrefix("menos cuarto") }
                menos != null -> { min = 60 - menos.groupValues[1].toInt(); back(); rest = menos.groupValues[2] }
                mm != null -> { min = mm.groupValues[1].toInt(); rest = mm.groupValues[2] }
                bare != null -> { min = bare.groupValues[1].toInt(); rest = bare.groupValues[2] }
                t.startsWith("en punto") -> rest = t.removePrefix("en punto")
            }
        }
        if (rawH > 24 || min > 59) return null
        if (h == 24) h = 0
        val eligible = rawH in 1..12
        val ctx = " $rest "
        val night = Regex("\\b(de la noche|por la noche)\\b").containsMatchIn(ctx)
        val pm = night || Regex("\\b(p m|pm|de la tarde|por la tarde)\\b").containsMatchIn(ctx)
        val am = Regex("\\b(a m|am|de la manana|de la madrugada|por la manana|por la madrugada)\\b").containsMatchIn(ctx)
        val noon = Regex("\\bmediodia\\b").containsMatchIn(ctx)
        return when {
            noon && h == 12 -> TimeSpec(12, min, false)
            !eligible -> TimeSpec(h, min, false)
            night && h == 12 -> TimeSpec(0, min, false)
            pm && h in 1..11 && !(night && h < 6) -> TimeSpec(h + 12, min, false)
            am || pm -> TimeSpec(if (am && h == 12) 0 else h, min, false)
            else -> TimeSpec(h, min, true)
        }
    }

    // ------------------------------------------------------------ calendario
    private val MONTHS = listOf("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
        "septiembre", "octubre", "noviembre", "diciembre")
    private val DAYS = listOf("lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo")

    private fun parseEvent(s: String, now: LocalDateTime): Cmd.Event? {
        // día
        var daysAhead: Int? = null
        val today = now.toLocalDate()
        val noPer = s.replace(Regex("\\b(de la|por la) manana\\b"), " ")
        when {
            Regex("\\bpasado manana\\b").containsMatchIn(noPer) -> daysAhead = 2
            Regex("\\bmanana\\b").containsMatchIn(noPer) -> daysAhead = 1
            Regex("\\bhoy\\b").containsMatchIn(noPer) -> daysAhead = 0
        }
        if (daysAhead == null) {
            val wd = Regex("\\b(?:el |este |proximo )?(lunes|martes|miercoles|jueves|viernes|sabado|domingo)\\b").find(noPer)
            if (wd != null) {
                val target = DAYS.indexOf(wd.groupValues[1]) + 1
                var d = (target - today.dayOfWeek.value + 7) % 7
                if (d == 0) d = 7
                daysAhead = d
            }
        }
        if (daysAhead == null) {
            val dm = Regex("\\b(?:el )?(\\d{1,2}) de (${MONTHS.joinToString("|")})\\b").find(noPer)
            if (dm != null) {
                val day = dm.groupValues[1].toInt()
                val mon = MONTHS.indexOf(dm.groupValues[2]) + 1
                try {
                    var date = LocalDate.of(today.year, mon, day)
                    if (date.isBefore(today)) date = date.plusYears(1)
                    daysAhead = ChronoUnit.DAYS.between(today, date).toInt()
                } catch (_: Exception) {}
            }
        }
        // hora
        val ts = timeSpec(s)
        var hour = 0
        var guessed = false
        if (ts != null) {
            hour = ts.h
            if (ts.ambiguous) {
                guessed = true
                if (daysAhead == null || daysAhead == 0) {
                    val a = hour % 12
                    val b = a + 12
                    fun delta(x: Int): Int { var d = (x * 60 + ts.min) - (now.hour * 60 + now.minute); if (d <= 0) d += 1440; return d }
                    hour = if (delta(a) <= delta(b)) a else b
                    if (daysAhead == null) daysAhead = if ((hour * 60 + ts.min) > now.hour * 60 + now.minute) 0 else 1
                } else {
                    hour = if (hour in 1..6) hour + 12 else hour % 24
                }
            } else if (daysAhead == null) {
                daysAhead = if ((hour * 60 + ts.min) > now.hour * 60 + now.minute) 0 else 1
            }
        }
        // título
        var t = s
        t = t.replace(Regex("\\b(?:a la|a las|para la|para las|las|la)\\s+\\d{1,2}(?::\\d{2})?(?:\\s+y media|\\s+y cuarto|\\s+menos cuarto|\\s+menos \\d{1,2}|\\s+y \\d{1,2}|\\s+en punto|\\s+\\d{2})?(?:\\s+(?:de la|por la)\\s+(?:manana|tarde|noche|madrugada)|\\s+p m|\\s+a m|\\s+pm|\\s+am)?"), " ")
        t = t.replace(Regex("\\b\\d{1,2}:\\d{2}\\b"), " ")
        t = t.replace(Regex("\\b(pasado manana|hoy)\\b"), " ")
        t = t.replace(Regex("(?<!de la )(?<!por la )\\bmanana\\b"), " ")
        t = t.replace(Regex("\\b(?:el |este |proximo )?(${DAYS.joinToString("|")})\\b"), " ")
        t = t.replace(Regex("\\b(?:el )?\\d{1,2} de (${MONTHS.joinToString("|")})\\b"), " ")
        val trig = Regex("\\b(calendario|agenda|evento|recordatorio|recordame|recuerdame|agendame)\\b").find(t)
        var title = ""
        if (trig != null) {
            title = t.substring(trig.range.last + 1)
            if (trig.groupValues[1] in listOf("calendario", "agenda", "evento", "recordatorio") && title.isBlank() || cleanTitle(title).isEmpty()) {
                title = t.substring(0, trig.range.first)
            }
        }
        title = cleanTitle(title)
        if (title.isEmpty()) title = "Evento"
        if (guessed && (daysAhead ?: 0) != 0 && hour in 6..11 && Regex("\\b(cena|cenar|noche)\\b").containsMatchIn(title)) hour += 12
        return Cmd.Event(title, daysAhead ?: 0, hour, ts?.min ?: 0, ts != null, guessed)
    }

    private fun cleanTitle(x: String): String {
        var t = " " + x.trim() + " "
        t = t.replace(Regex("\\s(pon|poner|ponme|agrega|agregar|agregame|crea|crear|creame|anota|anotar|anotame|agenda|agendar|agendame|anade|programa|programar|por favor|porfa)\\s"), " ")
        t = t.replace(Regex("\\s(en|a|al|de|del|mi|el|la|un|una) (el |mi |la )?(calendario|agenda)\\s"), " ")
        t = t.replace(Regex("\\s(un|el|una|mi)\\s+(evento|recordatorio|cita)\\s"), " ")
        t = t.replace(Regex("\\s(evento|recordatorio)\\s"), " ")
        t = t.replace(Regex("^\\s*(que|de|para|en|a|el|la|un|una|y)\\s+"), " ")
        t = t.replace(Regex("^\\s*(tengo|tenes|hay)\\s+"), " ")
        var prev = ""
        while (prev != t) {
            prev = t
            t = t.replace(Regex("\\s+(que|de|del|para|en|a|al|el|la|mi|y|el dia)\\s*$"), " ")
        }
        return t.replace(Regex("\\s+"), " ").trim()
    }
}
