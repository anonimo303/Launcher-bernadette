package com.personal.launcher.mahoraga

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.SystemClock
import android.provider.Settings
import android.telecom.TelecomManager
import com.personal.launcher.Prefs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Un app con procesos vivos en este momento, con lo que consume. */
class Proc(val pkg: String, var cpu: Float, var ramMb: Int)

/** Foto del sistema: quién se está moviendo, cuánto gasta y quién tiene un servicio en primer plano. */
class Snap(val procs: List<Proc>, val fgSvc: Set<String>, val svcOk: Boolean = true)

class BoostResult(
    val level: Int, val before: Int, val after: Int, val soft: Boolean, val seen: Int,
    val closed: List<String>, val kept: List<String>,
    val cacheN: Int, val globalCache: Boolean, val restricted: Int, val frozen: Int, val note: String
) {
    fun lines(): List<String> {
        val out = ArrayList<String>()
        if (soft) {
            out.add("Sin análisis profundo: se pidió a Android cerrar los procesos en caché de $seen apps. Android decide cuáles se cierran de verdad.")
        } else {
            out.add("Nivel ${Boost.levelName(level)}: se analizaron $seen apps activas.")
            if (closed.isNotEmpty()) out.add("Cerradas (${closed.size}): " + closed.take(6).joinToString(", ") + (if (closed.size > 6) "…" else "") + ".")
            else out.add("No había apps gastando recursos en segundo plano que cerrar.")
            if (globalCache) out.add("Caché liberada con limpieza global del sistema.")
            else if (cacheN > 0) out.add("Caché limpiada en $cacheN app(s).")
            if (restricted > 0) out.add("Actividad en segundo plano frenada en $restricted app(s) mientras juegas (se restaura al salir).")
            if (frozen > 0) out.add("$frozen app(s) congeladas mientras juegas (se restauran al salir).")
            if (kept.isNotEmpty()) out.add("No se tocaron (protegidas o en uso): " + kept.joinToString(", ") + ".")
        }
        out.add("RAM libre: $before → $after MB (medido).")
        if (note.isNotEmpty()) out.add(note)
        return out
    }

    /** Frase corta para la ventana de «Preparando el equipo». */
    fun short(): String {
        val diff = after - before
        val ram = if (diff > 0) "+$diff MB de RAM libre" else "RAM libre $after MB"
        return if (soft) "Listo · $ram" else "Listo · ${closed.size} app(s) cerradas · $ram"
    }
}

/**
 * Prepara el equipo antes (y durante) la partida. Primero MIRA el sistema (CPU y RAM por app, servicios en primer plano)
 * y solo después actúa sobre lo que de verdad consume y no estás usando. Todo lo que cambia queda registrado y se restaura al salir.
 *
 * Con Shizuku: cierra apps, limpia su caché, frena su actividad en segundo plano y, si se activa, las congela.
 * Sin Shizuku: Android solo permite pedir el cierre de procesos en caché; no se finge más de lo que hace.
 *
 * NUNCA toca: el juego, MAHORAGA/VERDANT, Shizuku, las apps protegidas, el launcher, el teclado, los servicios de accesibilidad,
 * los oyentes de notificaciones, las VPN, el marcador/SMS predeterminados, las apps de la burbuja ni apps con un servicio en primer plano
 * (música, descargas, navegación…). Tampoco apps del sistema.
 */
object Boost {
    const val K_PRE = "mh_boost_pre"
    const val K_LEVEL = "mh_boost_level"
    const val K_FREEZE = "mh_boost_freeze"
    private const val K_RESTR = "mh_boost_restr"
    private const val K_FROZEN = "mh_boost_frozen"
    private const val K_LAST = "mh_boost_last"
    private const val K_TS = "mh_boost_ts"
    private const val K_OFF = "mh_boost_off"

    @Volatile var busy = false

    fun enabled(c: Context) = Prefs.bool(c, K_PRE, true)
    fun baseLevel(c: Context) = Prefs.int(c, K_LEVEL, 1).coerceIn(0, 2)
    fun levelName(l: Int) = arrayOf("Suave", "Normal", "A fondo")[l.coerceIn(0, 2)]

    /** Nivel real para este juego: el elegido, o más fuerte si en la última vez la RAM siguió baja (adaptación). */
    fun levelFor(c: Context, pkg: String): Int = maxOf(baseLevel(c), Prefs.int(c, "mh_boost_lv_$pkg", 0)).coerceIn(0, 2)

    fun last(c: Context): String? = Prefs.str(c, K_LAST)

    fun recent(c: Context, ms: Long): Boolean {
        val t = Prefs.str(c, K_TS)?.toLongOrNull() ?: return false
        return System.currentTimeMillis() - t < ms
    }

    private fun safe(p: String) = p.matches(Regex("[A-Za-z0-9._]+"))

    private fun thirdParty(pm: PackageManager, pkg: String): Boolean = try {
        (pm.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) == 0
    } catch (e: Exception) { false }

    // ------------------------------------------------------------------ lo que nunca se toca

    fun guard(c: Context, game: String): Set<String> {
        val g = HashSet<String>()
        g.addAll(Protect.list(c))
        g.addAll(Quick.list(c))
        g.add(game); g.add(c.packageName); g.add(Shz.PKG); g.add("android")
        val pm = c.packageManager
        try {
            pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
                ?.activityInfo?.packageName?.let { g.add(it) }
        } catch (e: Exception) { }
        val cr = c.contentResolver
        for (k in listOf(
            Settings.Secure.ENABLED_INPUT_METHODS, Settings.Secure.DEFAULT_INPUT_METHOD,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, "enabled_notification_listeners"
        )) {
            val s = try { Settings.Secure.getString(cr, k) } catch (e: Exception) { null } ?: continue
            for (part in s.split(":")) {
                val p = part.substringBefore("/").trim()
                if (p.isNotEmpty()) g.add(p)
            }
        }
        try {
            for (r in pm.queryIntentServices(Intent("android.net.VpnService"), 0)) r.serviceInfo?.packageName?.let { g.add(it) }
        } catch (e: Exception) { }
        try { (c.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager)?.defaultDialerPackage?.let { g.add(it) } } catch (e: Exception) { }
        try { android.provider.Telephony.Sms.getDefaultSmsPackage(c)?.let { g.add(it) } } catch (e: Exception) { }
        return g
    }

    // ------------------------------------------------------------------ mirar el sistema

    /**
     * Lee, con Shizuku, qué apps están vivas, cuánta CPU/RAM usan y cuáles tienen un servicio en primer plano.
     * Son lecturas independientes: si una falla (o tarda), las demás siguen valiendo. `diag` recibe el motivo si no se pudo leer nada.
     */
    fun snapshot(c: Context, diag: StringBuilder? = null): Snap? {
        fun rd(cmd: String, ms: Long): String = Shz.exec(cmd, ms)?.out ?: ""
        val cpuTxt = rd("dumpsys cpuinfo | head -n 80", 9000L)
        val memTxt = rd("dumpsys meminfo | grep -A 80 \"Total PSS by process:\"", 12000L)
        val psTxt = rd("ps -A -o RSS,NAME", 5000L)
        val svcTxt = rd("dumpsys activity services | grep -E \"ServiceRecord\\{|isForeground=true\"", 12000L)

        val map = LinkedHashMap<String, Proc>()
        val reCpu = Regex("""^\s*[+-]?([\d.]+)%\s+\d+/(\S+?):\s""")
        var nCpu = 0
        for (ln in cpuTxt.lines()) {
            val m = reCpu.find(ln) ?: continue
            val pkg = m.groupValues[2].substringBefore(':')
            val v = m.groupValues[1].toFloatOrNull() ?: continue
            if (!pkg.contains('.')) continue
            map.getOrPut(pkg) { Proc(pkg, 0f, 0) }.cpu += v
            nCpu++
        }
        val reMem = Regex("""^\s*([\d.,]+)K:\s+([A-Za-z0-9._]+)""")
        val withMem = HashSet<String>()
        var nMem = 0
        for (ln in memTxt.lines()) {
            val m = reMem.find(ln) ?: continue
            val kb = m.groupValues[1].replace(",", "").replace(".", "").toLongOrNull() ?: continue
            val pkg = m.groupValues[2]
            if (!pkg.contains('.')) continue
            map.getOrPut(pkg) { Proc(pkg, 0f, 0) }.ramMb += (kb / 1024).toInt()
            withMem.add(pkg)
            nMem++
        }
        // Respaldo de RAM: ps (RSS) para las apps que meminfo no listó.
        val rePs = Regex("""^\s*(\d+)\s+([A-Za-z0-9._:]+)\s*$""")
        val psAdd = HashMap<String, Int>()
        var nPs = 0
        for (ln in psTxt.lines()) {
            val m = rePs.find(ln) ?: continue
            val pkg = m.groupValues[2].substringBefore(':')
            if (!pkg.contains('.') || pkg in withMem) continue
            val kb = m.groupValues[1].toLongOrNull() ?: continue
            psAdd[pkg] = (psAdd[pkg] ?: 0) + (kb / 1024).toInt()
            nPs++
        }
        for ((pkg, mb) in psAdd) map.getOrPut(pkg) { Proc(pkg, 0f, 0) }.ramMb += mb

        val fg = HashSet<String>()
        val reSvc = Regex("""ServiceRecord\{\S+ u\d+ ([A-Za-z0-9._]+)/""")
        var cur: String? = null
        for (ln in svcTxt.lines()) {
            val m = reSvc.find(ln)
            if (m != null) { cur = m.groupValues[1]; continue }
            if (ln.contains("isForeground=true") && cur != null) fg.add(cur)
        }
        if (map.isEmpty()) {
            diag?.append("CPU: $nCpu líneas, memoria: $nMem, procesos: $nPs")
            val first = listOf(cpuTxt, memTxt, psTxt).firstOrNull { it.isNotBlank() }
            if (first == null) diag?.append("; Shizuku no devolvió texto")
            else diag?.append("; respuesta: " + first.lines().first().take(70))
            return null
        }
        // Sin lectura de servicios no se sabe qué apps están en uso: se avisa en el informe y se actúa solo sobre las que consumen mucho.
        return Snap(map.values.toList(), fg, svcTxt.contains("ServiceRecord"))
    }

    // ------------------------------------------------------------------ actuar

    fun runAsync(c: Context, game: String) {
        if (busy) return
        val app = c.applicationContext
        Thread { try { run(app, game) } catch (e: Throwable) { busy = false } }.start()
    }

    /** Bloqueante (llamar desde un hilo). `say` recibe lo que está haciendo en cada paso. */
    fun run(c: Context, game: String, say: (String) -> Unit = {}): BoostResult {
        val app = c.applicationContext
        busy = true
        try {
            val before = Sys.ramAvailMb(app)
            val lvl = levelFor(app, game)
            val g = guard(app, game)
            if (!Shz.granted()) return finish(app, game, soft(app, g, lvl, before, say, ""))
            say("Mirando qué se mueve en el sistema…")
            val dg = StringBuilder()
            val snap = snapshot(app, dg)
                ?: return finish(app, game, soft(app, g, lvl, before, say, "No se pudo leer el estado del sistema con Shizuku ($dg); se usó el cierre suave."))

            val pm = app.packageManager
            // Si no se pudo leer qué apps tienen un servicio activo (música, descargas…), solo se actúa sobre las muy pesadas.
            val tl = if (snap.svcOk) lvl else 0
            val cpuMin = floatArrayOf(5f, 2f, 0.5f)[tl]
            val ramMin = intArrayOf(300, 150, 50)[tl]
            val cap = intArrayOf(8, 14, 22)[tl]
            val cand = snap.procs.filter { it.pkg != game && it.pkg != app.packageName && it.pkg != Shz.PKG && thirdParty(pm, it.pkg) }
            val heavy = cand.filter { it.cpu >= cpuMin || it.ramMb >= ramMin }
            val kept = heavy.filter { it.pkg in g || it.pkg in snap.fgSvc }
                .sortedByDescending { it.cpu * 20 + it.ramMb }.take(4).map { Games.label(app, it.pkg) }
            val targets = heavy.filter { it.pkg !in g && it.pkg !in snap.fgSvc && safe(it.pkg) }
                .sortedByDescending { it.cpu * 20 + it.ramMb }.take(cap)
            say(if (targets.isEmpty()) "Nada que cerrar: el sistema está limpio." else "${targets.size} app(s) gastan recursos sin que las uses. Actuando…")

            var cacheOk = 0
            var global = false
            var restr = emptyList<String>()
            var froz = emptyList<String>()
            if (targets.isNotEmpty()) {
                val canRestore = Mh.usageGranted(app)       // solo se cambian cosas reversibles si se sabrá cuándo dejas de jugar
                val freezeOn = canRestore && Prefs.bool(app, K_FREEZE, false)
                val off = offenders(app)
                val sb = StringBuilder()
                for (t in targets) {
                    val p = t.pkg
                    val restrict = canRestore && (lvl >= 1 || (off[p] ?: 0) >= 3)
                    val freeze = freezeOn && (t.cpu >= 1.5f || t.ramMb >= 120)
                    sb.append("(")
                    sb.append(if (lvl == 0) "am kill $p; " else "am force-stop $p; ")
                    sb.append("echo \"C:$p:\$(pm clear --cache-only $p 2>&1 | head -n 1)\"; ")
                    if (restrict) sb.append(
                        "o=\$(cmd appops get $p RUN_ANY_IN_BACKGROUND 2>&1); " +
                            "case \"\$o\" in *ignore*|*deny*|*rror*) ;; " +
                            "*) cmd appops set $p RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1 && echo \"R:$p\" ;; esac; "
                    )
                    if (freeze) sb.append(
                        "if pm suspend --user 0 $p 2>&1 | grep -qi 'suspended state: true'; then echo \"F:$p:s\"; " +
                            "elif pm disable-user --user 0 $p 2>&1 | grep -qi 'disabled'; then echo \"F:$p:d\"; fi; "
                    )
                    sb.append(") & ")
                }
                sb.append("wait")
                say("Cerrando apps y limpiando caché…")
                val res = Shz.exec(sb.toString(), 28000L)
                val out = res?.out ?: ""
                cacheOk = Regex("(?m)^C:[^:]+:Success").findAll(out).count()
                val cacheBad = Regex("(?m)^C:[^:]+:.*(nknown|sage|rror)").containsMatchIn(out)
                restr = Regex("(?m)^R:(\\S+)").findAll(out).map { it.groupValues[1] }.toList()
                froz = Regex("(?m)^F:([^:\\s]+):([sd])").findAll(out).map { it.groupValues[1] + ":" + it.groupValues[2] }.toList()
                if (cacheOk == 0 && cacheBad) global = Shz.exec("pm trim-caches 999G", 12000L)?.ok == true
                addSet(app, K_RESTR, restr)
                addSet(app, K_FROZEN, froz)
                for (t in targets) off[t.pkg] = (off[t.pkg] ?: 0) + 1
                saveOffenders(app, off)
            }
            say("Midiendo el resultado…")
            SystemClock.sleep(1500L)
            val after = Sys.ramAvailMb(app)
            val names = targets.map { "${Games.label(app, it.pkg)} ${it.ramMb} MB" }
            val note = (if (snap.svcOk) "" else "No se pudo leer qué apps tienen un servicio activo: solo se actuó sobre las más pesadas. ") + adapt(app, game, lvl, after)
            return finish(app, game, BoostResult(lvl, before, after, false, snap.procs.size, names, kept, cacheOk, global, restr.size, froz.size, note))
        } finally {
            busy = false
            Prefs.setStr(app, K_TS, System.currentTimeMillis().toString())
        }
    }

    /** Sin Shizuku Android solo permite pedir el cierre de procesos en caché (permiso KILL_BACKGROUND_PROCESSES). */
    private fun soft(app: Context, g: Set<String>, lvl: Int, before: Int, say: (String) -> Unit, note: String): BoostResult {
        say("Pidiendo a Android que cierre procesos en caché…")
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var n = 0
        for (ai in app.packageManager.getInstalledApplications(0)) {
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 || ai.packageName in g) continue
            try { am.killBackgroundProcesses(ai.packageName); n++ } catch (e: Throwable) { }
        }
        SystemClock.sleep(1200L)
        return BoostResult(lvl, before, Sys.ramAvailMb(app), true, n, emptyList(), emptyList(), 0, false, 0, 0, note)
    }

    /** Guarda el resultado (informe y última vez) y lo devuelve. */
    private fun finish(app: Context, game: String, r: BoostResult): BoostResult {
        val lines = r.lines()
        Prefs.setStr(app, K_LAST, SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date()) + "\n" + lines.joinToString("\n"))
        try {
            val rep = Reports.latest(app, game)
            val a = rep?.actions?.firstOrNull { it.id == "shz_clean" && it.status == "applied" }
            if (rep != null && a != null) { a.detail = "Última vez: " + lines.joinToString(" "); Reports.save(app, rep) }
        } catch (e: Exception) { }
        return r
    }

    /** Adaptación: si tras limpiar la RAM sigue baja, la próxima vez actúa más fuerte; si sobra, vuelve a lo normal. */
    private fun adapt(app: Context, game: String, lvl: Int, after: Int): String {
        val total = (app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).let {
            val mi = ActivityManager.MemoryInfo(); it.getMemoryInfo(mi); (mi.totalMem / 1048576L).toInt()
        }
        if (total <= 0) return ""
        val pct = after * 100 / total
        val key = "mh_boost_lv_$game"
        val cur = Prefs.int(app, key, 0)
        if (pct < 15 && lvl < 2) {
            Prefs.setInt(app, key, lvl + 1)
            return "La RAM sigue baja ($pct %): la próxima vez actuará a nivel ${levelName(lvl + 1)}."
        }
        if (pct >= 35 && cur > baseLevel(app)) Prefs.setInt(app, key, cur - 1)
        return ""
    }

    /** Llamado desde la adaptación: si el diagnóstico encontró problemas de memoria o CPU, sube el nivel para este juego. */
    fun escalate(c: Context, game: String, minLevel: Int) {
        val cur = Prefs.int(c, "mh_boost_lv_$game", 0)
        if (cur < minLevel) Prefs.setInt(c, "mh_boost_lv_$game", minLevel.coerceIn(0, 2))
    }

    fun resetLearning(c: Context, game: String) = Prefs.setInt(c, "mh_boost_lv_$game", 0)

    // ------------------------------------------------------------------ restaurar

    private fun readSet(c: Context, k: String): List<String> =
        (Prefs.str(c, k) ?: "").split(",").filter { it.isNotBlank() }

    private fun addSet(c: Context, k: String, add: List<String>) {
        if (add.isEmpty()) return
        Prefs.setStr(c, k, (readSet(c, k) + add).distinct().joinToString(","))
    }

    fun pending(c: Context): Boolean = readSet(c, K_RESTR).isNotEmpty() || readSet(c, K_FROZEN).isNotEmpty()

    fun pendingCount(c: Context): Int = readSet(c, K_RESTR).size + readSet(c, K_FROZEN).size

    /** Devuelve a las apps lo que se les frenó o congeló. Si Shizuku no está disponible ahora, queda pendiente para después. */
    fun restore(c: Context, done: (() -> Unit)? = null) {
        val app = c.applicationContext
        val r = readSet(app, K_RESTR).filter { safe(it) }
        val f = readSet(app, K_FROZEN).filter { safe(it.substringBefore(":")) }
        if (r.isEmpty() && f.isEmpty()) { done?.invoke(); return }
        if (!Shz.granted()) { done?.invoke(); return }
        // Hilo propio: Shz.stopPoll() vacía la cola del hilo de Shizuku y podría descartar la restauración.
        Thread {
            val sb = StringBuilder()
            for (p in r) sb.append("(cmd appops set $p RUN_ANY_IN_BACKGROUND default) & ")
            for (e in f) {
                val p = e.substringBefore(":")
                sb.append(if (e.substringAfter(":") == "s") "(pm unsuspend --user 0 $p) & " else "(pm enable --user 0 $p) & ")
            }
            sb.append("wait")
            val res = Shz.exec(sb.toString(), 25000L)
            if (res != null) {
                Prefs.setStr(app, K_RESTR, null)
                Prefs.setStr(app, K_FROZEN, null)
                val prev = Prefs.str(app, K_LAST)
                if (prev != null) Prefs.setStr(app, K_LAST, prev + "\nRestauradas ${r.size + f.size} app(s) al salir del juego.")
            }
            done?.invoke()
        }.start()
    }

    // ------------------------------------------------------------------ memoria de reincidentes

    private fun offenders(c: Context): MutableMap<String, Int> {
        val m = LinkedHashMap<String, Int>()
        for (e in (Prefs.str(c, K_OFF) ?: "").split(",")) {
            val p = e.substringBefore("=")
            val n = e.substringAfter("=", "").toIntOrNull()
            if (p.isNotBlank() && n != null) m[p] = n
        }
        return m
    }

    private fun saveOffenders(c: Context, m: Map<String, Int>) {
        Prefs.setStr(c, K_OFF, m.entries.sortedByDescending { it.value }.take(60).joinToString(",") { "${it.key}=${it.value}" })
    }
}
