package com.personal.launcher

import android.app.Notification
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Historial en memoria (24 h, máx. 60) de notificaciones recibidas; lo lee Bernadette. */
object NotifStore {
    class Item(val app: String, val who: String, val title: String, val text: String, val time: Long)

    private val items = ArrayList<Item>()

    @Synchronized
    fun add(app: String, who: String, title: String, text: String) {
        val now = System.currentTimeMillis()
        items.removeAll { now - it.time > 24L * 3600_000L }
        if (items.any { it.app == app && it.who == who && it.text == text && now - it.time < 600_000L }) return
        items.add(Item(app, who, title, text, now))
        while (items.size > 60) items.removeAt(0)
    }

    @Synchronized
    fun query(who: String?, app: String?, limit: Int): List<Item> {
        fun nm(s: String) = BernadetteParser.norm(s)
        var res: List<Item> = items.asReversed()
        if (!app.isNullOrBlank()) {
            val a = nm(app)
            res = res.filter { val l = nm(it.app); l.contains(a) || (l.length >= 3 && a.contains(l)) }
        }
        if (!who.isNullOrBlank()) {
            val w = nm(who)
            val byApp = res.filter { val l = nm(it.app); l == w || l.contains(w) || (l.length >= 3 && w.contains(l)) }
            res = if (byApp.isNotEmpty()) byApp else {
                val toks = w.split(" ").filter { it.isNotEmpty() }
                res.filter { val t = nm(it.who + " " + it.title); toks.all { tk -> t.contains(tk) } }
            }
        }
        return res.take(limit)
    }
}

/**
 * Escucha las notificaciones del sistema: las guarda (para «léeme los mensajes») y las muestra con
 * la animación del launcher. Con «Tapar las del sistema» descarta la original al llegar.
 */
class NotifService : NotificationListenerService() {

    private val seen = HashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val f = n.flags
        if (f and Notification.FLAG_ONGOING_EVENT != 0) return
        if (f and Notification.FLAG_FOREGROUND_SERVICE != 0) return
        if (f and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.category in listOf(Notification.CATEGORY_PROGRESS, Notification.CATEGORY_TRANSPORT,
                Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM, Notification.CATEGORY_CALL,
                Notification.CATEGORY_ALARM)) return

        val ex = n.extras
        val label = appLabel(sbn.packageName)
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString()?.trim()
        if (title.isEmpty() && text.isNullOrEmpty()) return

        // historial para Bernadette: cada mensaje del estilo de mensajería con su remitente
        try {
            @Suppress("DEPRECATION")
            val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
            var stored = false
            if (arr != null) {
                val msgs = Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr)
                for (m in msgs.takeLast(5)) {
                    val t = m.text?.toString()?.trim().orEmpty()
                    if (t.isEmpty()) continue
                    val who = m.senderPerson?.name?.toString() ?: title
                    NotifStore.add(label, who.ifEmpty { label }, title, t)
                    stored = true
                }
            }
            if (!stored && !text.isNullOrEmpty()) NotifStore.add(label, title.ifEmpty { label }, title, text)
        } catch (_: Exception) {}

        if (!Prefs.bool(this, "notif_on", true)) return

        // evita repetir la misma notificación (actualizaciones, reposts)
        val sig = sbn.key + "|" + title + "|" + text
        val now = System.currentTimeMillis()
        if (now - (seen[sig] ?: 0L) < 3000) return
        seen[sig] = now
        if (seen.size > 50) seen.entries.removeAll { now - it.value > 10000 }

        val icon = try { packageManager.getApplicationIcon(sbn.packageName) } catch (e: Exception) { null }
        val shown = NotifOverlay.show(
            this, icon, title.ifEmpty { label },
            if (Prefs.bool(this, "notif_preview", true)) text else null
        )

        // Solo tapamos la del sistema si la del launcher realmente se pudo mostrar
        if (shown && Prefs.bool(this, "notif_hide", true) && sbn.isClearable) {
            try { cancelNotification(sbn.key) } catch (_: Exception) {}
        }
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) { pkg }
}
