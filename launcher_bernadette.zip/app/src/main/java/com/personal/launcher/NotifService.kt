package com.personal.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Escucha las notificaciones del sistema y las muestra con la animación del launcher. Con «Tapar las del sistema» descarta la original al llegar.
 */
class NotifService : NotificationListenerService() {

    private val seen = HashMap<String, Long>()

    // Caché en memoria: tras un rato inactivo el proceso está «frío» y leer SharedPreferences del disco
    // o consultar el permiso de overlay tardaba lo suficiente para que el sistema alcanzara a mostrar
    // su aviso. Estos valores se precargan al conectar el servicio y se mantienen al día.
    @Volatile private var on = true
    @Volatile private var hideOn = true
    @Volatile private var canDraw = false
    private var sp: SharedPreferences? = null
    private val spListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> refreshCache() }

    private fun refreshCache() {
        on = Prefs.bool(this, "notif_on", true)
        hideOn = Prefs.bool(this, "notif_hide", true)
        canDraw = NotifOverlay.canDraw(this)
        updateForeground(Prefs.bool(this, "notif_keep", true))
    }

    private var fg = false

    /**
     * Con la app en segundo plano (sobre todo si TikTok o un juego usa mucho CPU) Android le da muy poca
     * prioridad y tarda en atender la primera notificación: la del sistema alcanza a verse.
     * Mantener el servicio «en primer plano» (aviso silencioso y mínimo) evita esa demora.
     */
    private fun updateForeground(want: Boolean) {
        try {
            if (want && !fg) {
                val nm = getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(
                    NotificationChannel("notif_keep", "Servicio de notificaciones", NotificationManager.IMPORTANCE_MIN)
                        .apply { setShowBadge(false) }
                )
                val n = Notification.Builder(this, "notif_keep")
                    .setSmallIcon(R.drawable.ic_s_bell)
                    .setContentTitle("VERDANT activo")
                    .setContentText("Notificaciones animadas")
                    .setOngoing(true)
                    .build()
                if (Build.VERSION.SDK_INT >= 34) startForeground(7701, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                else startForeground(7701, n)
                fg = true
            } else if (!want && fg) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                fg = false
            }
        } catch (_: Exception) { /* si Android no lo permite en este momento, seguimos sin él */ }
    }

    override fun onCreate() {
        super.onCreate()
        warmUp()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        warmUp()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        // Si el sistema nos desconecta (ahorro de batería, proceso muerto), pedimos volver a conectar
        // para no perder la capacidad de tapar la notificación original.
        try { requestRebind(android.content.ComponentName(this, NotifService::class.java)) } catch (_: Exception) {}
    }

    private fun warmUp() {
        refreshCache()
        if (sp == null) {
            sp = getSharedPreferences("verdant", MODE_PRIVATE).also { it.registerOnSharedPreferenceChangeListener(spListener) }
        }
        // fuerza la carga de la clase del overlay y de lo que usa, para que no ocurra con la primera notificación
        try { NotifOverlay.canDraw(this); Prefs.animScale(this) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        sp?.unregisterOnSharedPreferenceChangeListener(spListener)
        sp = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val f = n.flags
        if (f and Notification.FLAG_ONGOING_EVENT != 0) return
        if (f and Notification.FLAG_FOREGROUND_SERVICE != 0) return
        if (n.category in listOf(Notification.CATEGORY_PROGRESS, Notification.CATEGORY_TRANSPORT,
                Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM, Notification.CATEGORY_CALL,
                Notification.CATEGORY_ALARM)) return

        if (!on) return

        // ¿Hay que tapar la del sistema? Solo si la del launcher se puede dibujar (permiso de overlay).
        // Se usa la caché (instantánea); se refresca al final por si el permiso cambió.
        val hide = hideOn && canDraw && sbn.isClearable

        // Resumen de grupo (WhatsApp lo manda junto a cada mensaje): no se anima, pero SÍ se tapa,
        // si no el sistema lo muestra encima de la animación.
        if (f and Notification.FLAG_GROUP_SUMMARY != 0) {
            if (hide) dismiss(sbn)
            return
        }

        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString()?.trim()
        if (title.isEmpty() && text.isNullOrEmpty()) return

        // Tapar la original LO ANTES POSIBLE (antes de cargar íconos, dedupe, etc.)
        // para que no llegue a verse el aviso heads-up del sistema.
        if (hide) dismiss(sbn)

        // evita animar dos veces la misma notificación (actualizaciones, reposts).
        // OJO: esto solo afecta a la animación; la original ya se descartó arriba.
        val sig = sbn.key + "|" + title + "|" + text
        val now = System.currentTimeMillis()
        if (now - (seen[sig] ?: 0L) < 3000) return
        seen[sig] = now
        if (seen.size > 50) seen.entries.removeAll { now - it.value > 10000 }

        // ya con la original tapada, se actualiza la caché sin apuro
        canDraw = NotifOverlay.canDraw(this)

        val label = appLabel(sbn.packageName)
        val icon = try { packageManager.getApplicationIcon(sbn.packageName) } catch (e: Exception) { null }
        NotifOverlay.show(
            this, icon, title.ifEmpty { label },
            if (Prefs.bool(this, "notif_preview", true)) text else null
        )
    }

    private fun dismiss(sbn: StatusBarNotification) {
        try { cancelNotification(sbn.key) } catch (_: Exception) {}
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) { pkg }
}
