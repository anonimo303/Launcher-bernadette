package com.personal.launcher

import android.app.Notification
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Escucha las notificaciones del sistema y las muestra con la animación del launcher. Con «Tapar las del sistema» descarta la original al llegar.
 */
class NotifService : NotificationListenerService() {

    private val seen = HashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val f = n.flags
        if (f and Notification.FLAG_ONGOING_EVENT != 0) return
        if (f and Notification.FLAG_FOREGROUND_SERVICE != 0) return
        if (n.category in listOf(Notification.CATEGORY_PROGRESS, Notification.CATEGORY_TRANSPORT,
                Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM, Notification.CATEGORY_CALL,
                Notification.CATEGORY_ALARM)) return

        if (!Prefs.bool(this, "notif_on", true)) return

        // ¿Hay que tapar la del sistema? Solo si la del launcher se puede dibujar (permiso de overlay).
        val hide = Prefs.bool(this, "notif_hide", true) && sbn.isClearable && NotifOverlay.canDraw(this)

        // Resumen de grupo (WhatsApp lo manda junto a cada mensaje): no se anima, pero SÍ se tapa,
        // si no el sistema lo muestra encima de la animación.
        if (f and Notification.FLAG_GROUP_SUMMARY != 0) {
            if (hide) dismiss(sbn)
            return
        }

        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString()?.trim()
        if (title.isEmpty() && text.isNullOrEmpty()) return

        // Tapar la original LO ANTES POSIBLE (antes de cargar íconos, dedupe, etc.)
        // para que no llegue a verse el aviso heads-up del sistema.
        if (hide) dismiss(sbn)

        // evita animar dos veces la misma notificación (actualizaciones, reposts).
        // OJO: esto solo afecta a la animación; la original ya se descartó arriba.
        val sig = sbn.key + "|" + title + "|" + text
        val now = System.currentTimeMillis()
        if (now - (seen[sig] ?: 0L) < 3000) return
        seen[sig] = now
        if (seen.size > 50) seen.entries.removeAll { now - it.value > 10000 }

        val label = appLabel(sbn.packageName)
        val icon = try { packageManager.getApplicationIcon(sbn.packageName) } catch (e: Exception) { null }
        NotifOverlay.show(
            this, icon, title.ifEmpty { label },
            if (Prefs.bool(this, "notif_preview", true)) text else null
        )
    }

    private fun dismiss(sbn: StatusBarNotification) {
        try { cancelNotification(sbn.key) } catch (_: Exception) {}
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) { pkg }
}
