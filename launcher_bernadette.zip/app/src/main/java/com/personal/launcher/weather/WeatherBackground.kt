package com.personal.launcher.weather

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.view.View
import java.util.Random

/**
 * Fondo atmosférico de Clima: degradados azul eléctrico / violeta / morado profundo, nubes de
 * tormenta con profundidad y neones. La escena estática se dibuja UNA vez en una miniatura (1/8)
 * que además sirve de «fondo desenfocado» para el cristal; encima solo se mueven unas pocas nubes
 * suaves (traslaciones baratas, nada de desenfoques por fotograma).
 */
class WeatherBackground(ctx: Context, private val bd: WxBackdrop) : View(ctx) {

    /** 0 = estático, 1 = reducido, 2 = completo. */
    var quality = 2

    private var mood = WxKind.CLOUDY
    private var t = 0f
    private var flash = 0f
    private var nextFlash = 3f
    private val rnd = Random(11)
    private val dst = Rect()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    // ---- nubes que se mueven (se dibujan como 3 manchas suaves) ----
    private val n = 7
    private val px = FloatArray(n)
    private val py = FloatArray(n)
    private val ps = FloatArray(n)
    private val pv = FloatArray(n)
    private val pa = IntArray(n)
    private val pk = IntArray(n)
    private val puffPaints = arrayOfNulls<Paint>(3)

    init {
        val r = Random(5)
        for (i in 0 until n) {
            px[i] = r.nextFloat()
            py[i] = 0.04f + r.nextFloat() * 0.9f
            ps[i] = 0.55f + r.nextFloat() * 0.7f
            pv[i] = 0.012f + r.nextFloat() * 0.02f          // fracción del ancho por segundo
            pa[i] = 38 + r.nextInt(50)
            pk[i] = i % 3
        }
        val cols = intArrayOf(0xFFB9A8FF.toInt(), 0xFF7FA8FF.toInt(), 0xFF2A1A7A.toInt())
        for (k in 0 until 3) {
            puffPaints[k] = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    0f, 0f, 100f,
                    intArrayOf((0xCC shl 24) or (cols[k] and 0xFFFFFF), (0x55 shl 24) or (cols[k] and 0xFFFFFF), cols[k] and 0xFFFFFF),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
                )
            }
        }
    }

    fun setMood(k: WxKind) {
        if (k == mood && bd.scene != null) return
        mood = k
        nextFlash = 1.5f
        renderScene()
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        bd.anchor = this
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        renderScene()
    }

    // ---------------------------------------------------------------- escena estática

    private fun palette(): IntArray = when (mood) {
        // arriba, medio, abajo, neón 1, neón 2
        WxKind.CLEAR -> intArrayOf(0xFF0B1A6E.toInt(), 0xFF1F46C8.toInt(), 0xFF12206F.toInt(), 0xFF4DA6FF.toInt(), 0xFF8A5CFF.toInt())
        WxKind.PARTLY -> intArrayOf(0xFF0A1459.toInt(), 0xFF1D2DA8.toInt(), 0xFF121469.toInt(), 0xFF4A90FF.toInt(), 0xFF8A4CFF.toInt())
        WxKind.CLOUDY -> intArrayOf(0xFF080C36.toInt(), 0xFF171A85.toInt(), 0xFF0F0F55.toInt(), 0xFF3F7BFF.toInt(), 0xFF8044FF.toInt())
        WxKind.FOG -> intArrayOf(0xFF0E1244.toInt(), 0xFF2A2C92.toInt(), 0xFF1A1A63.toInt(), 0xFF6E8CFF.toInt(), 0xFF9C7CFF.toInt())
        WxKind.RAIN -> intArrayOf(0xFF050722.toInt(), 0xFF101266.toInt(), 0xFF090A3E.toInt(), 0xFF2F66F0.toInt(), 0xFF6A3CE8.toInt())
        WxKind.STORM -> intArrayOf(0xFF05030F.toInt(), 0xFF1E0A5E.toInt(), 0xFF0B0536.toInt(), 0xFF5A3CFF.toInt(), 0xFFA23CFF.toInt())
        WxKind.SNOW -> intArrayOf(0xFF101C66.toInt(), 0xFF3447B8.toInt(), 0xFF1C2680.toInt(), 0xFF8FB4FF.toInt(), 0xFFB9A4FF.toInt())
    }

    private fun blob(c: Canvas, x: Float, y: Float, r: Float, color: Int, a: Float) {
        val rgb = color and 0xFFFFFF
        fillPaint.shader = RadialGradient(
            x, y, r,
            intArrayOf(((a * 255).toInt() shl 24) or rgb, (((a * 0.45f) * 255).toInt() shl 24) or rgb, rgb),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, fillPaint)
    }

    private fun renderScene() {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        val s = bd.scale
        val bmp = Bitmap.createBitmap(maxOf(1, w / s), maxOf(1, h / s), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(1f / s, 1f / s)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val pal = palette()
        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, hf, intArrayOf(pal[0], pal[1], pal[2]), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, wf, hf, fillPaint)

        // iluminación neón
        blob(c, wf * 0.88f, hf * 0.08f, wf * 0.85f, pal[4], 0.55f)
        blob(c, wf * 0.05f, hf * 0.30f, wf * 0.80f, pal[3], 0.50f)
        blob(c, wf * 0.70f, hf * 0.58f, wf * 0.90f, pal[4], 0.30f)
        blob(c, wf * 0.12f, hf * 0.92f, wf * 0.90f, pal[3], 0.42f)

        // masas de nubes oscuras con profundidad (fijas)
        val r = Random(7)
        for (i in 0 until 12) {
            val x = r.nextFloat() * wf
            val y = (if (i % 2 == 0) r.nextFloat() * 0.28f else 0.62f + r.nextFloat() * 0.4f) * hf
            val rad = wf * (0.35f + r.nextFloat() * 0.45f)
            blob(c, x, y, rad, 0xFF07061F.toInt(), 0.40f)
            blob(c, x + rad * 0.25f, y - rad * 0.2f, rad * 0.55f, pal[4], 0.16f)
        }
        // sombras superior e inferior para dar profundidad
        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, hf, intArrayOf(0x66000010, 0x00000010, 0x00000010, 0x88000010.toInt()),
            floatArrayOf(0f, 0.25f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, wf, hf, fillPaint)
        fillPaint.shader = null

        bd.scene = bmp
        bd.anchor = this
        bd.refresh()
    }

    // ---------------------------------------------------------------- animación

    fun tick(dt: Float) {
        if (quality <= 0) return
        t += dt
        if (mood == WxKind.STORM) {
            nextFlash -= dt
            if (nextFlash <= 0f) {
                flash = 1f
                nextFlash = 3.5f + rnd.nextFloat() * 5f
            }
        }
        if (flash > 0f) flash = maxOf(0f, flash - dt * 3.2f)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width
        val h = height
        val b = bd.scene
        if (b == null) {
            c.drawColor(0xFF0A0F3D.toInt())
        } else {
            dst.set(0, 0, w, h)
            c.drawBitmap(b, null, dst, bmpPaint)
        }
        // nubes en movimiento
        val count = if (quality >= 2) n else 4
        val wf = w.toFloat()
        val hf = h.toFloat()
        for (i in 0 until count) {
            val sz = wf * ps[i] * 0.9f
            val m = sz
            val span = wf + 2f * m
            var x = (px[i] * span + t * pv[i] * wf) % span
            if (x < 0f) x += span
            x -= m
            val y = py[i] * hf
            val pt = puffPaints[pk[i]] ?: continue
            val sc = sz / 200f
            c.save()
            c.translate(x, y)
            c.scale(sc, sc * 0.62f)
            pt.alpha = pa[i]
            c.drawCircle(-70f, 14f, 100f, pt)
            c.drawCircle(0f, -22f, 120f, pt)
            c.drawCircle(80f, 12f, 95f, pt)
            c.restore()
        }
        if (flash > 0f) c.drawColor(((flash * 90f).toInt() shl 24) or 0x00BFB8FF)
    }
}
