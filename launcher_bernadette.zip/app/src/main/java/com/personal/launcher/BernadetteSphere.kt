package com.personal.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Esfera esmeralda de Bernadette. Usa la imagen de referencia (una sola bitmap compartida)
 * y la anima con capas giratorias, brillo interior y anillos. Dibuja ~30 fps (≈15 fps en reposo
 * cuando es pequeña), sin asignar objetos por fotograma.
 */
class BernadetteSphere(c: Context) : View(c) {

    enum class State { IDLE, LISTENING, PROCESSING, SPEAKING }

    var state = State.IDLE
    /** Esfera pequeña flotante: menos fotogramas en reposo para gastar menos. */
    var small = false

    private var target = 0f
    private var level = 0f
    private var time = 0f
    private var last = 0L
    private var angle = 0f
    private var speed = 5f

    private val bmp: Bitmap = shared(c)
    private val src = android.graphics.Rect(0, 0, bmp.width, bmp.height)
    private val dst = RectF()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN) }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.rgb(70, 255, 170) }
    private val clip = Path()
    private var cx = 0f
    private var cy = 0f
    private var r0 = 0f

    /** Nivel de voz 0..1 (viene del micrófono mientras escucha). */
    fun setLevel(v: Float) { target = v.coerceIn(0f, 1f) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f
        cy = h / 2f
        r0 = min(w, h) * 0.5f * 0.76f
        dst.set(cx - r0, cy - r0, cx + r0, cy + r0)
        glowPaint.shader = RadialGradient(
            cx, cy, r0 * 1.32f,
            intArrayOf(Color.argb(255, 0, 255, 150), Color.argb(90, 0, 200, 110), Color.argb(0, 0, 160, 90)),
            floatArrayOf(0.62f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        corePaint.shader = RadialGradient(
            cx, cy, r0 * 0.6f,
            intArrayOf(Color.argb(255, 210, 255, 230), Color.argb(150, 40, 255, 150), Color.argb(0, 0, 255, 120)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        ringPaint.strokeWidth = min(w, h) * 0.006f + 1f
    }

    override fun onDraw(cv: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0.033f else ((now - last) / 1000f).coerceIn(0.001f, 0.1f)
        last = now
        time += dt
        level += (target - level) * 0.35f
        if (state != State.LISTENING) target *= 0.9f

        val tgtSpeed: Float
        val scale: Float
        val glowA: Float
        val coreA: Float
        val a2: Float
        val rings: Boolean
        val pulse = 0.5f * sin(time * 9f) + 0.5f * sin(time * 5.3f + 1f) // -1..1
        when (state) {
            State.IDLE -> {
                tgtSpeed = 5f
                scale = 1f + 0.012f * sin(time * 2f * PI.toFloat() / 5f)
                glowA = 0.30f; coreA = 0.10f; a2 = 0.40f; rings = false
            }
            State.LISTENING -> {
                tgtSpeed = 18f + 40f * level
                scale = 1f + 0.015f * sin(time * 3f) + 0.07f * level
                glowA = 0.45f + 0.45f * level; coreA = 0.20f + 0.5f * level; a2 = 0.55f; rings = true
            }
            State.PROCESSING -> {
                tgtSpeed = 85f
                scale = 1f + 0.02f * sin(time * 2f * PI.toFloat() * 1.2f)
                glowA = 0.85f; coreA = 0.60f + 0.2f * sin(time * 7f); a2 = 0.85f; rings = false
            }
            State.SPEAKING -> {
                tgtSpeed = 30f
                scale = 1.03f + 0.035f * pulse
                glowA = 0.55f + 0.25f * pulse; coreA = 0.35f + 0.3f * pulse; a2 = 0.65f; rings = true
            }
        }
        speed += (tgtSpeed - speed) * min(1f, dt * 4f)
        angle = (angle + speed * dt) % 360f

        cv.save()
        cv.scale(scale, scale, cx, cy)

        glowPaint.alpha = (glowA * 255).toInt().coerceIn(0, 255)
        cv.drawCircle(cx, cy, r0 * 1.32f, glowPaint)

        // capa base (borde y reflejos fijos)
        paint.alpha = 255
        cv.drawBitmap(bmp, src, dst, paint)

        // capas interiores giratorias, recortadas dentro de la esfera
        clip.reset()
        clip.addCircle(cx, cy, r0 * 0.93f, Path.Direction.CW)
        cv.save()
        cv.clipPath(clip)
        cv.save()
        cv.rotate(angle, cx, cy)
        paint.alpha = (a2 * 255).toInt()
        cv.drawBitmap(bmp, src, dst, paint)
        cv.restore()
        cv.save()
        cv.rotate(-angle * 0.7f + 40f, cx, cy)
        cv.scale(1.12f, 1.12f, cx, cy)
        paint.alpha = (a2 * 0.55f * 255).toInt()
        cv.drawBitmap(bmp, src, dst, paint)
        cv.restore()
        corePaint.alpha = (coreA * 255).toInt().coerceIn(0, 255)
        cv.drawCircle(cx, cy, r0 * 0.6f, corePaint)
        cv.restore()

        if (rings) {
            for (k in 0..1) {
                val ph = ((time * 0.7f + k * 0.5f) % 1f)
                ringPaint.alpha = ((1f - ph) * (0.25f + 0.55f * level.coerceAtLeast(if (state == State.SPEAKING) 0.5f else 0f)) * 255).toInt().coerceIn(0, 255)
                cv.drawCircle(cx, cy, r0 * (1.02f + 0.3f * ph), ringPaint)
            }
        }
        cv.restore()

        postInvalidateDelayed(if (small && state == State.IDLE) 66L else 30L)
    }

    companion object {
        private var cache: Bitmap? = null
        private fun shared(c: Context): Bitmap {
            cache?.let { return it }
            val o = BitmapFactory.Options().apply { inScaled = false }
            val b = BitmapFactory.decodeResource(c.applicationContext.resources, R.drawable.bernadette_sphere, o)
            cache = b
            return b
        }
    }
}
