package com.personal.launcher.mahoraga

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.personal.launcher.Prefs
import com.personal.launcher.R
import rikka.shizuku.Shizuku

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Aplicación MAHORAGA GAMES (módulo independiente dentro del APK de VERDANT). */
@Suppress("DEPRECATION")
class MahoragaActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val nav = ArrayList<() -> Unit>()
    private var live: Runnable? = null
    private var screen = "home"

    private val shzListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        Shz.invalidate()
        runOnUiThread { if (screen == "shizuku" && !isDestroyed) showShizuku() }
    }

    private fun d(v: Int) = Mh.dp(this, v)

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Mh.BG
        try { Shizuku.addRequestPermissionResultListener(shzListener) } catch (e: Throwable) { }
        // Red de seguridad: si quedó algo frenado/congelado de una partida anterior y no se está jugando, se restaura.
        if (Boost.pending(this) && !MonitorService.running) Boost.restore(this)
        handleIntent(intent, true)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent, false)
    }

    private fun handleIntent(i: Intent?, first: Boolean) {
        val pkg = i?.getStringExtra("pkg")
        val scr = i?.getStringExtra("screen")
        nav.clear()
        go { showHome() }
        val g = if (pkg != null) Games.find(this, pkg) else null
        if (g != null) go { showAdapt(g) }
        else if (scr == "settings") go { showSettings() }
        else if (scr == "perms") go { showPerms(null, null) }
        else if (scr == "shizuku") go { showShizuku() }
        else if (scr == "about") go { showSettings() }
    }

    override fun onResume() {
        super.onResume()
        Shz.invalidate()
        if ((screen == "perms" || screen == "shizuku") && nav.isNotEmpty()) nav[nav.size - 1].invoke()
        else live?.let { handler.post(it) }
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shzListener) } catch (e: Throwable) { }
        super.onDestroy()
    }

    override fun onPause() {
        handler.removeCallbacksAndMessages(null)
        super.onPause()
    }

    override fun onBackPressed() {
        if (nav.size > 1) { nav.removeAt(nav.size - 1); nav[nav.size - 1].invoke() } else finish()
    }

    private fun go(f: () -> Unit) { nav.add(f); f() }

    private fun setLive(r: Runnable?) {
        handler.removeCallbacksAndMessages(null)
        live = r
        if (r != null) handler.post(r)
    }

    // ---------------------------------------------------------------- bloques de UI

    private fun col(): LinearLayout { val l = LinearLayout(this); l.orientation = LinearLayout.VERTICAL; return l }

    private fun lp(top: Int = 10, w: Int = MATCH, h: Int = WRAP): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h); p.topMargin = d(top); return p
    }

    private fun card(): LinearLayout {
        val c = col()
        c.setPadding(d(14), d(12), d(14), d(12))
        c.background = Mh.round(Mh.CARD, d(18).toFloat(), Mh.LINE, d(1))
        return c
    }

    private fun label(s: String, sp: Float = 14f, color: Int = Mh.TEXT, bold: Boolean = false) = Mh.text(this, s, sp, color, bold)

    private fun button(s: String, primary: Boolean, onClick: () -> Unit): TextView {
        val t = label(s, 14f, Mh.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(d(12), d(13), d(12), d(13))
        t.background = Mh.round(if (primary) Mh.VIOLET else Mh.CARD2, d(14).toFloat(), if (primary) Mh.VIOLET_L else Mh.LINE, d(1))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun icon(res: Int, tint: Int, size: Int): ImageView {
        val i = ImageView(this); i.setImageResource(res); i.setColorFilter(tint)
        i.layoutParams = LinearLayout.LayoutParams(d(size), d(size)); return i
    }

    /** Página con barra superior. Devuelve el contenedor donde se añaden los bloques. */
    private fun page(title: String, back: Boolean): LinearLayout {
        val body = col()
        body.setPadding(d(16), d(12), d(16), d(24))
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        if (back) {
            val b = label("‹", 30f, Mh.VIOLET_L, true)
            b.setPadding(0, 0, d(14), d(4))
            b.setOnClickListener { onBackPressed() }
            bar.addView(b)
        }
        bar.addView(label(title, 20f, Mh.TEXT, true))
        body.addView(bar, lp(0))
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.setBackgroundColor(Mh.BG)
        sv.addView(body)
        setContentView(sv)
        return body
    }

    private fun mmss(sec: Int) = "%d:%02d".format(sec / 60, sec % 60)

    // ---------------------------------------------------------------- INICIO

    private fun stateOf(g: Game): String {
        if (MonitorService.diagPkg == g.pkg) return "Diagnosticando… ${mmss(MonitorService.diagSecs)} / ${mmss(MonitorService.DIAG_TARGET)}"
        val r = Reports.latest(this, g.pkg) ?: return "Sin diagnóstico"
        return when {
            r.applied -> "Adaptado · ${Mh.fmtDate(r.appliedTs)}"
            r.diag != null -> "Diagnóstico listo · falta aplicar"
            else -> "Sin diagnóstico"
        }
    }

    private fun showHome() {
        screen = "home"
        val b = page("", false)
        // identidad
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val face = ImageView(this)
        face.setImageResource(R.drawable.mh_icon)
        head.addView(face, LinearLayout.LayoutParams(d(84), d(84)))
        val tt = col()
        tt.setPadding(d(10), 0, 0, 0)
        val t1 = label("MAHORAGA", 24f, Mh.TEXT, true); t1.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD_ITALIC)
        val t2 = label("GAMES", 28f, Mh.VIOLET_L, true); t2.setTypeface(Typeface.DEFAULT_BOLD, Typeface.BOLD_ITALIC)
        tt.addView(t1); tt.addView(t2)
        tt.addView(label("Rendimiento en tiempo real", 12f, Mh.SUB))
        head.addView(tt, LinearLayout.LayoutParams(0, WRAP, 1f))
        val gear = icon(R.drawable.mh_ic_gear, Mh.VIOLET_L, 28)
        gear.setOnClickListener { go { showSettings() } }
        head.addView(gear)
        b.addView(head, lp(4))

        // estado en vivo
        val st = card()
        val line1 = label("", 15f, Mh.TEXT, true)
        val line2 = label("", 12f, Mh.SUB)
        st.addView(line1); st.addView(line2)
        b.addView(st, lp(12))

        val row = LinearLayout(this)
        row.addView(button("Diagnóstico del equipo", false) { go { showDeviceDiag() } }, LinearLayout.LayoutParams(0, WRAP, 1f))
        val hb = button("Historial", false) { go { showHistory() } }
        val hlp = LinearLayout.LayoutParams(0, WRAP, 1f); hlp.leftMargin = d(8)
        row.addView(hb, hlp)
        b.addView(row, lp(10))

        b.addView(label("Biblioteca de juegos", 16f, Mh.VIOLET_L, true), lp(18))
        val lib = Games.library(this)
        val states = HashMap<String, TextView>()
        if (lib.isEmpty()) {
            val c = card()
            c.addView(label("No se encontró ningún juego conocido instalado. Añade uno con «+ Añadir juego».", 13f, Mh.SUB))
            b.addView(c, lp(8))
        }
        for (g in lib) {
            val c = card()
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            val ic = ImageView(this)
            ic.setImageDrawable(Games.icon(this, g.pkg))
            r.addView(ic, LinearLayout.LayoutParams(d(46), d(46)))
            val tc = col()
            tc.setPadding(d(12), 0, d(8), 0)
            tc.addView(label(g.name, 16f, Mh.TEXT, true))
            val sTv = label(stateOf(g), 12f, Mh.SUB)
            states[g.pkg] = sTv
            tc.addView(sTv)
            r.addView(tc, LinearLayout.LayoutParams(0, WRAP, 1f))
            r.addView(icon(R.drawable.mh_ic_play, Mh.VIOLET_L, 26))
            c.addView(r)
            c.setOnClickListener { sheet(g) }
            if (Games.isCustom(this, g.pkg)) c.setOnLongClickListener {
                val dlg = Dialog(this)
                dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
                val box = card()
                box.addView(label("Quitar ${g.name} de la biblioteca", 15f, Mh.TEXT, true))
                box.addView(label("No se desinstala nada: solo deja de aparecer aquí.", 12f, Mh.SUB), lp(6))
                box.addView(button("Quitar", true) { Games.removeCustom(this, g.pkg); dlg.dismiss(); showHome() }, lp(12))
                dlg.setContentView(box)
                dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dlg.show()
                true
            }
            b.addView(c, lp(8))
        }
        b.addView(button("+  Añadir juego", false) { pickGame() }, lp(10))

        val tick = object : Runnable {
            override fun run() {
                val s = Sys.sample(this@MahoragaActivity)
                line1.text = (if (s.battTemp.isNaN()) "Temp. N/D" else "%.1f °C".format(s.battTemp)) +
                    "  ·  RAM ${if (s.ramUsedPct >= 0) s.ramUsedPct.toString() + " %" else "N/D"}" +
                    "  ·  Bat. ${if (s.battPct >= 0) s.battPct.toString() + " %" else "N/D"}"
                line2.text = "Estado térmico: ${Mh.thermalName(s.thermal)}  ·  CPU: " +
                    (if (s.cpuPct >= 0) "${s.cpuPct} %" else "no medible") + "  ·  FPS: N/D"
                for (g in lib) states[g.pkg]?.text = stateOf(g)
                handler.postDelayed(this, 2500L)
            }
        }
        setLive(tick)
    }

    private fun pickGame() {
        val pm = packageManager
        val have = Games.library(this).map { it.pkg }.toSet()
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second !in have && it.second != packageName }
            .distinctBy { it.second }.sortedBy { it.first.lowercase() }
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = col()
        box.setPadding(d(16), d(14), d(16), d(10))
        box.background = Mh.round(Mh.CARD, d(20).toFloat(), Mh.LINE, d(1))
        box.addView(label("Elige el juego a añadir", 16f, Mh.VIOLET_L, true))
        val list = col()
        for (a in apps) {
            val t = label(a.first, 15f, Mh.TEXT)
            t.setPadding(0, d(11), 0, d(11))
            t.setOnClickListener { Games.addCustom(this, a.second); dlg.dismiss(); showHome() }
            list.addView(t)
        }
        val sv = ScrollView(this)
        sv.addView(list)
        box.addView(sv, LinearLayout.LayoutParams(MATCH, d(380)))
        dlg.setContentView(box)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), WRAP)
        dlg.show()
    }

    /** Ficha del juego con las tres acciones principales. */
    private fun sheet(g: Game) {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = col()
        box.setPadding(d(18), d(16), d(18), d(16))
        box.background = Mh.round(Mh.CARD, d(24).toFloat(), Mh.VIOLET, d(1))
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val ic = ImageView(this); ic.setImageDrawable(Games.icon(this, g.pkg))
        head.addView(ic, LinearLayout.LayoutParams(d(44), d(44)))
        val tc = col(); tc.setPadding(d(12), 0, 0, 0)
        tc.addView(label(g.name, 18f, Mh.TEXT, true))
        tc.addView(label(stateOf(g), 12f, Mh.SUB))
        head.addView(tc)
        box.addView(head)
        box.addView(button("JUGAR", true) { dlg.dismiss(); playChecked(g) }, lp(14))
        box.addView(button("VER DETALLES", false) { dlg.dismiss(); go { showDetails(g) } }, lp(8))
        box.addView(button("ADAPTACIÓN", false) { dlg.dismiss(); go { showAdapt(g) } }, lp(8))
        dlg.setContentView(box)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.88f).toInt(), WRAP)
        dlg.show()
    }

    private var permsPrompted = false

    /** JUGAR desde MAHORAGA: si falta el Acceso de uso, antes lleva a Permisos (una vez) para que el diagnóstico automático funcione. */
    private fun playChecked(g: Game) {
        if (!permsPrompted && Prefs.bool(this, "mh_auto_diag", true) && !Mh.usageGranted(this)) {
            permsPrompted = true
            toast("Concede los permisos para que MAHORAGA pueda diagnosticar y optimizar sola.")
            go { showPerms(g) { play(g) } }
            return
        }
        play(g)
    }

    private fun play(g: Game) {
        val i = Games.launchIntent(this, g.pkg)
        if (i == null) { toast("No se pudo abrir ${g.name}"); return }
        if (!Boost.enabled(this) || Boost.busy) { launchGame(g, i); return }

        // Antes de abrir el juego: mira el sistema y limpia lo que consume sin que lo uses.
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dlg.setCancelable(false)
        val box = col()
        box.setPadding(d(20), d(18), d(20), d(18))
        box.background = Mh.round(Mh.CARD, d(24).toFloat(), Mh.VIOLET, d(1))
        box.addView(label("Preparando el equipo para ${g.name}", 16f, Mh.VIOLET_L, true))
        val step = label("Mirando qué se mueve en el sistema…", 14f, Mh.TEXT)
        box.addView(step, lp(10))
        dlg.setContentView(box)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.86f).toInt(), WRAP)
        dlg.show()

        val started = java.util.concurrent.atomic.AtomicBoolean(false)
        val open = Runnable {
            if (started.compareAndSet(false, true)) {
                try { if (dlg.isShowing) dlg.dismiss() } catch (e: Exception) { }
                launchGame(g, i)
            }
        }
        handler.postDelayed(open, 30000L)          // si algo se cuelga, el juego se abre igual
        val app = applicationContext
        Thread {
            val r = try { Boost.run(app, g.pkg) { t -> runOnUiThread { step.text = t } } } catch (e: Throwable) { null }
            runOnUiThread {
                if (r != null) { step.text = r.short(); handler.postDelayed(open, 1300L) } else open.run()
            }
        }.start()
    }

    private fun launchGame(g: Game, i: Intent) {
        MonitorService.onAppLaunched(this, g.pkg)
        try { startActivity(i) } catch (e: Exception) { toast("No se pudo abrir ${g.name}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---------------------------------------------------------------- DETALLES / INFORMES

    private fun statsLines(s: Stats): List<String> {
        val o = ArrayList<String>()
        o.add("Duración medida: ${s.seconds / 60} min ${s.seconds % 60} s")
        o.add("RAM libre: mín ${s.ramAvailMin} MB · media ${s.ramAvailAvg} MB de ${s.ramTotalMb} MB")
        if (s.swapTotalMb > 0) o.add("Memoria virtual usada: máx ${s.swapUsedMax} MB de ${s.swapTotalMb} MB")
        if (!s.tempMax.isNaN()) o.add("Temp. batería: inicio %.1f · media %.1f · máx %.1f °C".format(s.tempStart, s.tempAvg, s.tempMax))
        o.add("Estado térmico de Android (máx): ${Mh.thermalName(s.thermalMax)}")
        o.add(if (s.cpuAvg >= 0) "CPU: media ${s.cpuAvg} % · máx ${s.cpuMax} %" else "CPU: no medible en este equipo")
        if (s.freqMax >= 0) o.add("Frecuencia CPU: media ${s.freqAvg} · máx ${s.freqMax} MHz")
        if (s.battStart >= 0) o.add("Batería: ${s.battStart} % → ${s.battEnd} %" + if (s.charging) " (con cargador)" else "")
        o.add(if (s.fpsAvg >= 0) "FPS medidos (Shizuku): media ${s.fpsAvg} · mín ${s.fpsMin}" else "FPS: no disponible (sin medición fiable)")
        return o
    }

    private fun compareLines(b: Stats, a: Stats): List<String> {
        val o = ArrayList<String>()
        if (!b.tempMax.isNaN() && !a.tempMax.isNaN()) o.add("Temp. máx: %.1f → %.1f °C".format(b.tempMax, a.tempMax))
        if (!b.tempAvg.isNaN() && !a.tempAvg.isNaN()) o.add("Temp. media: %.1f → %.1f °C".format(b.tempAvg, a.tempAvg))
        o.add("RAM libre mínima: ${b.ramAvailMin} → ${a.ramAvailMin} MB")
        if (b.cpuAvg >= 0 && a.cpuAvg >= 0) o.add("CPU media: ${b.cpuAvg} → ${a.cpuAvg} %")
        if (b.fpsAvg >= 0 && a.fpsAvg >= 0) o.add("FPS medios (Shizuku): ${b.fpsAvg} → ${a.fpsAvg}")
        o.add("Estado térmico máx: ${Mh.thermalName(b.thermalMax)} → ${Mh.thermalName(a.thermalMax)}")
        o.add("Duración: ${b.seconds / 60} min → ${a.seconds / 60} min")
        return o
    }

    private fun reportView(parent: LinearLayout, r: Report) {
        val g = Games.find(this, r.pkg)
        val h = card()
        h.addView(label("MAHORAGA — ADAPTACIÓN ${r.num}", 16f, Mh.GOLD, true))
        h.addView(label("Juego: ${r.game} · ${Mh.fmtDate(r.ts)}", 13f, Mh.SUB))
        parent.addView(h, lp(10))

        val dg = card()
        dg.addView(label("Diagnóstico", 15f, Mh.VIOLET_L, true))
        for (f in r.findings) {
            val t = label((if (f.problem) "⚠ " else "• ") + f.text, 13f, if (f.problem) Mh.WARN else Mh.TEXT)
            dg.addView(t, lp(5))
        }
        r.diag?.let { s ->
            dg.addView(label("Datos medidos", 13f, Mh.SUB, true), lp(10))
            for (l in statsLines(s)) dg.addView(label(l, 12f, Mh.SUB), lp(2))
        }
        parent.addView(dg, lp(10))

        val ac = card()
        ac.addView(label("Acciones", 15f, Mh.VIOLET_L, true))
        for (a in r.actions) {
            val color = when (a.status) { "applied" -> Mh.GOOD; "recommended" -> Mh.WARN; "reverted" -> Mh.BAD; else -> Mh.SUB }
            ac.addView(label(a.title, 14f, Mh.TEXT, true), lp(10))
            ac.addView(label(a.statusLabel(), 12f, color, true), lp(1))
            ac.addView(label(a.detail, 12f, Mh.SUB), lp(1))
            if (a.needs != "—" && a.needs != "Ninguno") ac.addView(label("Permiso/necesita: ${a.needs}", 11f, Mh.SUB), lp(1))
        }
        parent.addView(ac, lp(10))

        val rs = card()
        rs.addView(label("Resultado", 15f, Mh.VIOLET_L, true))
        val before = r.diag
        val after = r.after
        if (before != null && after != null) {
            rs.addView(label("Antes (diagnóstico) → después (partida con la adaptación, ${Mh.fmtDate(r.afterTs)}):", 12f, Mh.SUB), lp(4))
            for (l in compareLines(before, after)) rs.addView(label("• $l", 13f, Mh.TEXT), lp(3))
            rs.addView(label("Son datos medidos en dos partidas distintas; no garantizan una mejora ni se interpretan como FPS.", 11f, Mh.SUB), lp(6))
        } else if (r.applied) {
            rs.addView(label("Pendiente: se medirá en tu próxima partida (mínimo 90 s con el juego en primer plano).", 13f, Mh.TEXT), lp(4))
        } else {
            rs.addView(label("Todavía no se ha aplicado ninguna adaptación.", 13f, Mh.TEXT), lp(4))
        }
        parent.addView(rs, lp(10))

        if (r.applied) {
            parent.addView(button("Restaurar cambios", false) {
                Brain.revert(this, r)
                toast("Cambios revertidos")
                if (nav.isNotEmpty()) nav[nav.size - 1].invoke()
            }, lp(12))
        }
        if (g == null) parent.addView(label("Este juego ya no está en la biblioteca.", 11f, Mh.SUB), lp(6))
    }

    private fun showDetails(g: Game) {
        screen = "details"
        setLive(null)
        val b = page("Detalles · ${g.name}", true)
        val r = Reports.latest(this, g.pkg)
        if (r == null) {
            val c = card()
            c.addView(label("Aún no hay diagnóstico de ${g.name}. Toca ADAPTACIÓN para empezar.", 14f, Mh.TEXT))
            b.addView(c, lp(12))
            b.addView(button("ADAPTACIÓN", true) { go { showAdapt(g) } }, lp(12))
        } else {
            reportView(b, r)
            val older = Reports.all(this).filter { it.pkg == g.pkg && it.id != r.id }.reversed()
            if (older.isNotEmpty()) {
                b.addView(label("Informes anteriores", 15f, Mh.VIOLET_L, true), lp(16))
                for (o in older) b.addView(reportRow(o), lp(8))
            }
        }
    }

    private fun reportRow(r: Report): View {
        val c = card()
        c.addView(label("ADAPTACIÓN ${r.num} · ${r.game}", 14f, Mh.TEXT, true))
        c.addView(label(Mh.fmtDate(r.ts) + if (r.applied) " · aplicada" else " · sin aplicar", 12f, Mh.SUB))
        c.setOnClickListener { go { showReport(r.id) } }
        return c
    }

    private fun showReport(id: Long) {
        screen = "report"
        setLive(null)
        val r = Reports.all(this).firstOrNull { it.id == id }
        val b = page("Informe", true)
        if (r == null) b.addView(label("No se encontró el informe.", 14f, Mh.SUB), lp(12)) else reportView(b, r)
    }

    private fun showHistory() {
        screen = "history"
        setLive(null)
        val b = page("Historial", true)
        val all = Reports.all(this).reversed()
        if (all.isEmpty()) b.addView(label("Todavía no hay informes. Se crean al terminar un diagnóstico.", 14f, Mh.SUB), lp(12))
        for (r in all) b.addView(reportRow(r), lp(10))
    }

    // ---------------------------------------------------------------- ADAPTACIÓN

    private fun showAdapt(g: Game) {
        screen = "adapt"
        val b = page("Adaptación · ${g.name}", true)
        val r = Reports.latest(this, g.pkg)

        if (MonitorService.diagPkg == g.pkg) {
            val c = card()
            c.addView(label("Diagnóstico en curso", 16f, Mh.GOLD, true))
            val prog = label("", 14f, Mh.TEXT)
            c.addView(prog, lp(6))
            c.addView(label("MAHORAGA mide mientras el juego está en primer plano. Juega con normalidad; al terminar recibirás un aviso.", 12f, Mh.SUB), lp(6))
            b.addView(c, lp(12))
            b.addView(button("JUGAR ${g.name.uppercase()}", true) { play(g) }, lp(12))
            b.addView(button("Cancelar diagnóstico", false) { MonitorService.cancelDiag(this); showAdapt(g) }, lp(8))
            setLive(object : Runnable {
                override fun run() {
                    if (MonitorService.diagPkg != g.pkg) { showAdapt(g); return }
                    prog.text = "${mmss(MonitorService.diagSecs)} de ${mmss(MonitorService.DIAG_TARGET)}"
                    handler.postDelayed(this, 1500L)
                }
            })
            return
        }
        setLive(null)

        if (r == null || r.diag == null) {
            val c = card()
            c.addView(label("Diagnóstico inicial", 16f, Mh.GOLD, true))
            c.addView(label("Antes de adaptar ${g.name}, MAHORAGA estudia cómo se comporta en tu teléfono durante unos 3 a 4 minutos de juego: memoria, temperatura, batería, estado térmico y, si Android lo permite, CPU.\n\nNo se inventa ningún dato: lo que no se pueda medir se marcará como no disponible.", 13f, Mh.TEXT), lp(6))
            b.addView(c, lp(12))
            b.addView(button("Revisar permisos", false) { go { showPerms(g, null) } }, lp(12))
            b.addView(button("Iniciar diagnóstico", true) {
                if (!Prefs.bool(this, "mh_perms_seen", false)) go { showPerms(g) { startDiag(g) } } else startDiag(g)
            }, lp(8))
            return
        }

        if (!r.applied) {
            // se recalcula el plan con los permisos actuales antes de mostrarlo
            r.actions = Brain.plan(this, g, r.diag!!, r.findings)
            Reports.save(this, r)
        }
        reportView(b, r)
        if (!r.applied) {
            b.addView(button("APLICAR ADAPTACIÓN", true) { applyAdaptation(g, r) }, lp(14))
        }
        b.addView(button("Repetir diagnóstico", false) {
            if (r.applied) Brain.revert(this, r)
            startDiag(g)
        }, lp(8))
        b.addView(button("Revisar permisos", false) { go { showPerms(g, null) } }, lp(8))
    }

    private fun startDiag(g: Game) {
        MonitorService.startDiag(this, g.pkg)
        toast("Diagnóstico iniciado. Abre ${g.name} y juega unos minutos.")
        play(g)
        nav.removeAt(nav.size - 1)
        go { showAdapt(g) }
    }

    private fun applyAdaptation(g: Game, r: Report) {
        toast("Aplicando adaptación…")
        Thread {
            val done = Brain.apply(this, r)
            runOnUiThread { if (!isDestroyed) finishApply(g, done) }
        }.start()
    }

    private fun finishApply(g: Game, done: List<Action>) {
        if (done.isEmpty()) {
            toast("No se aplicó ningún ajuste: faltan permisos. Revisa «Permisos».")
        } else {
            val lines = done.map {
                when (it.id) {
                    "monitor" -> "Monitorización durante la partida activada."
                    "thermal" -> "Control térmico activado."
                    "light" -> "Actividad propia de MAHORAGA reducida."
                    "dnd" -> "No molestar automático configurado."
                    "shz_meter" -> "Medición real de CPU y FPS activada."
                    "shz_gamemode" -> "Modo Rendimiento de Android solicitado y aceptado."
                    "shz_clean" -> "Liberación de memoria al entrar al juego."
                    else -> it.title
                }
            }
            if (!MahoragaNotice.show(this, g.name, lines)) toast("Adaptación aplicada. Activa «Mostrar sobre otras apps» para ver la animación.")
        }
        showAdapt(g)
    }

    // ---------------------------------------------------------------- PERMISOS

    private class Perm(val id: String, val title: String, val why: String, val tools: Boolean,
                       val state: () -> Boolean?, val infoText: String, val grant: (() -> Unit)?)

    private fun settingsFor(action: String, withPkg: Boolean) {
        try {
            val i = Intent(action)
            if (withPkg) i.data = Uri.parse("package:$packageName")
            startActivity(i)
        } catch (e: Exception) {
            try { startActivity(Intent(action)) } catch (e2: Exception) { toast("No se pudo abrir los ajustes") }
        }
    }

    private fun showPerms(g: Game?, onDone: (() -> Unit)?) {
        screen = "perms"
        setLive(null)
        val b = page("Permisos", true)
        b.addView(label("MAHORAGA te explica qué necesita y para qué. Puedes aceptar o rechazar cada permiso; las funciones básicas siguen disponibles aunque rechaces los opcionales. No se pide root.", 13f, Mh.SUB), lp(8))

        val zoneOk = !Sys.sample(this).zoneTemp.isNaN()
        val perms = listOf(
            Perm("mem", "Memoria y batería", "Para medir RAM, memoria virtual, batería, voltaje y su temperatura.", false,
                { null }, "Disponible sin permisos", null),
            Perm("therm", "Sensores térmicos", "Estado térmico de Android y temperatura de batería. Las zonas térmicas del sistema solo se leen si Android lo deja.", false,
                { null }, if (zoneOk) "Zonas térmicas legibles" else "Solo estado térmico y batería (zonas del sistema bloqueadas)", null),
            Perm("usage", "Acceso de uso", "Para saber cuándo un juego de tu biblioteca está en primer plano (diagnóstico, monitorización y panel).", false,
                { Mh.usageGranted(this) }, "", { settingsFor(Settings.ACTION_USAGE_ACCESS_SETTINGS, true) }),
            Perm("notif", "Notificaciones y servicio en primer plano", "Para vigilar durante la partida (notificación fija discreta) y avisarte de temperatura alta.", false,
                { if (Build.VERSION.SDK_INT >= 33) Mh.notifGranted(this) else null }, "No requiere permiso en Android 12",
                { if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1) }),
            Perm("battery", "Sin restricciones de batería", "Para que Android no cierre MAHORAGA mientras diagnostica y optimiza en segundo plano.", false,
                { (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName) }, "",
                {
                    try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
                    catch (e: Exception) { settingsFor(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, false) }
                }),
            Perm("overlay", "Mostrar sobre otras apps", "Para la pestaña lateral, el panel gamer y la notificación especial de la rueda dorada.", true,
                { Mh.overlayGranted(this) }, "", { settingsFor(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true) }),
            Perm("dnd", "Acceso a No molestar", "Para activar No molestar durante la partida y restaurarlo al salir.", true,
                { Mh.dndGranted(this) }, "", { settingsFor(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, false) }),
            Perm("access", "Captura de pantalla (Accesibilidad)", "Servicio «MAHORAGA captura»: solo pide a Android que haga la captura. No lee la pantalla.", true,
                { Mh.accessEnabled() }, "", { settingsFor(Settings.ACTION_ACCESSIBILITY_SETTINGS, false) }),
            Perm("rec", "Grabación de pantalla", "Android muestra su propio diálogo cada vez que grabas. Se graba sin audio.", true,
                { null }, "Se autoriza en cada grabación", null),
            Perm("shizuku", "Shizuku (opcional)", "Permite medir CPU y FPS reales y aplicar ajustes de sistema autorizados. Todo sigue funcionando sin él.", true,
                { Shz.granted() }, "", { go { showShizuku() } })
        )
        for (tools in listOf(false, true)) {
            b.addView(label(if (tools) "Permisos de herramientas" else "Permisos de diagnóstico", 16f, Mh.VIOLET_L, true), lp(16))
            for (p in perms.filter { it.tools == tools }) {
                val c = card()
                c.addView(label(p.title, 14f, Mh.TEXT, true))
                c.addView(label(p.why, 12f, Mh.SUB), lp(3))
                val st = p.state()
                val declined = Prefs.bool(this, "mh_no_${p.id}", false)
                val (txt, colr) = when {
                    st == true -> Pair("Concedido", Mh.GOOD)
                    st == false && declined -> Pair("Rechazado: función limitada", Mh.WARN)
                    st == false -> Pair("No concedido", Mh.WARN)
                    else -> Pair(p.infoText, Mh.SUB)
                }
                c.addView(label(txt, 12f, colr, true), lp(6))
                if (st == false && p.grant != null) {
                    val r = LinearLayout(this)
                    r.addView(button("Conceder", true) { Prefs.setBool(this, "mh_no_${p.id}", false); p.grant?.invoke() }, LinearLayout.LayoutParams(0, WRAP, 1f))
                    val no = button("Ahora no", false) { Prefs.setBool(this, "mh_no_${p.id}", true); showPerms(g, onDone) }
                    val nlp = LinearLayout.LayoutParams(0, WRAP, 1f); nlp.leftMargin = d(8)
                    r.addView(no, nlp)
                    c.addView(r, lp(8))
                }
                b.addView(c, lp(8))
            }
        }
        b.addView(button(if (onDone != null) "Continuar" else "Listo", true) {
            if (onDone != null) { Prefs.setBool(this, "mh_perms_seen", true); nav.removeAt(nav.size - 1); onDone() }
            else onBackPressed()
        }, lp(18))
    }

    // ---------------------------------------------------------------- DIAGNÓSTICO DEL EQUIPO

    private fun showDeviceDiag() {
        screen = "devdiag"
        val b = page("Diagnóstico del equipo", true)
        b.addView(label("Lecturas reales ahora mismo y qué deja medir este teléfono. Lo que no se puede medir aparece como no disponible.", 13f, Mh.SUB), lp(8))
        val c = card()
        val tv = label("", 13f, Mh.TEXT)
        c.addView(tv)
        b.addView(c, lp(12))
        val cap = card()
        cap.addView(label("Qué puede medir MAHORAGA aquí", 15f, Mh.VIOLET_L, true))
        val capTv = label("", 12f, Mh.TEXT)
        cap.addView(capTv, lp(6))
        b.addView(cap, lp(12))
        val tick = object : Runnable {
            override fun run() {
                val s = Sys.sample(this@MahoragaActivity)
                val sb = StringBuilder()
                sb.append("RAM: ${s.ramTotalMb - s.ramAvailMb} MB usados de ${s.ramTotalMb} MB (libre ${s.ramAvailMb} MB)")
                if (s.lowMem) sb.append("\nAndroid indica poca memoria")
                if (s.swapTotalMb > 0) sb.append("\nMemoria virtual: ${s.swapTotalMb - s.swapFreeMb} MB usados de ${s.swapTotalMb} MB")
                sb.append("\nBatería: ${if (s.battPct >= 0) s.battPct.toString() + " %" else "N/D"}" + (if (s.battMv > 0) " · %.2f V".format(s.battMv / 1000.0) else "") + (if (s.charging) " · cargando" else ""))
                sb.append("\nTemp. batería: " + (if (s.battTemp.isNaN()) "N/D" else "%.1f °C".format(s.battTemp)))
                sb.append("\nEstado térmico de Android: ${Mh.thermalName(s.thermal)}")
                if (!s.zoneTemp.isNaN()) sb.append("\nZona térmica más caliente: %.1f °C".format(s.zoneTemp))
                if (s.freqMhz >= 0) sb.append("\nFrecuencia CPU (máx. núcleo): ${s.freqMhz} MHz")
                sb.append("\nCarga de CPU: " + (if (s.cpuPct >= 0) "${s.cpuPct} %" else "no medible"))
                tv.text = sb.toString()
                capTv.text = listOf(
                    "RAM y memoria virtual: ✔",
                    "Batería, voltaje y temperatura: ${if (s.battPct >= 0) "✔" else "✘"}",
                    "Estado térmico de Android: ${if (s.thermal >= 0) "✔" else "✘"}",
                    "Zonas térmicas del sistema: ${if (!s.zoneTemp.isNaN()) "✔" else "✘ (bloqueadas por Android)"}",
                    "Frecuencias de CPU: ${if (s.freqMhz >= 0) "✔" else "✘ (bloqueadas por Android)"}",
                    "Carga de CPU: ${if (s.cpuPct >= 0) "✔" else if (Sys.cpuAvailable()) "comprobando…" else "✘ (Android 8+ la bloquea a las apps)"}",
                    "GPU: ✘ (sin acceso sin privilegios)",
                    (if (Shz.granted()) "FPS de otro juego: ✔ con Shizuku (mejor esfuerzo, mientras juegas)" else "FPS de otro juego: ✘ (activa Shizuku)")
                ).joinToString("\n")
                handler.postDelayed(this, 2000L)
            }
        }
        setLive(tick)
    }

    // ---------------------------------------------------------------- CONFIGURACIÓN

    private fun switchRow(parent: LinearLayout, title: String, sub: String, key: String, def: Boolean, after: ((Boolean) -> Unit)? = null) {
        val c = card()
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        val tc = col()
        tc.addView(label(title, 14f, Mh.TEXT, true))
        tc.addView(label(sub, 12f, Mh.SUB))
        r.addView(tc, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(this)
        sw.isChecked = Prefs.bool(this, key, def)
        sw.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sw.trackTintList = ColorStateList.valueOf(Mh.VIOLET)
        sw.setOnCheckedChangeListener { _, on -> Prefs.setBool(this, key, on); after?.invoke(on) }
        r.addView(sw)
        c.addView(r)
        parent.addView(c, lp(8))
    }

    private fun showShizuku() {
        screen = "shizuku"
        setLive(null)
        val b = page("Configuración con Shizuku", true)
        b.addView(label("Shizuku es opcional: deja que MAHORAGA ejecute comandos de sistema (nivel adb) que tú autorizas, para medir mejor y ajustar lo que Android permite mientras juegas. Sin Shizuku todo lo demás sigue funcionando.", 13f, Mh.SUB), lp(8))

        val inst = Shz.installed(this)
        val run = Shz.running()
        Shz.invalidate()
        val ok = Shz.granted()
        val st = card()
        st.addView(label("Estado", 15f, Mh.VIOLET_L, true))
        fun line(t: String, good: Boolean) = st.addView(label((if (good) "✔ " else "✘ ") + t, 13f, if (good) Mh.GOOD else Mh.WARN), lp(5))
        line("Shizuku instalado", inst)
        line("Shizuku en ejecución", run)
        line("Permiso concedido a MAHORAGA", ok)
        if (ok) st.addView(label("Modo: ${Shz.mode()}", 12f, Mh.SUB), lp(5))
        b.addView(st, lp(12))

        if (!inst) {
            b.addView(label("Instala la app Shizuku (shizuku.rikka.app) y vuelve aquí.", 13f, Mh.TEXT), lp(12))
            b.addView(button("Abrir página de Shizuku", true) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app"))) } catch (e: Exception) { toast("No se pudo abrir el navegador") }
            }, lp(8))
        } else if (!run) {
            b.addView(label("Inicia el servicio desde la app de Shizuku. En Android 11 o superior se hace con la «Depuración inalámbrica» activada y conectado a una red Wi-Fi. Si no usas root, hay que repetirlo tras reiniciar el teléfono.", 13f, Mh.TEXT), lp(12))
            b.addView(button("Abrir Shizuku", true) {
                val i = packageManager.getLaunchIntentForPackage(Shz.PKG)
                if (i != null) startActivity(i) else toast("No se pudo abrir Shizuku")
            }, lp(8))
        } else if (!ok) {
            b.addView(label(if (Shz.denied()) "Denegaste el permiso con «no volver a preguntar». Concédelo desde la app de Shizuku, en las apps autorizadas." else "Shizuku está activo. Autoriza a MAHORAGA para poder usarlo.", 13f, Mh.TEXT), lp(12))
            b.addView(button("Conceder permiso a MAHORAGA", true) {
                if (!Shz.request()) toast("Shizuku no respondió. Comprueba que esté en ejecución.")
            }, lp(8))
        } else {
            b.addView(button("Conceder permisos automáticamente", true) {
                val me = packageName
                Shz.async {
                    for (cmd in listOf(
                        "appops set $me GET_USAGE_STATS allow",
                        "appops set $me SYSTEM_ALERT_WINDOW allow",
                        "pm grant $me android.permission.POST_NOTIFICATIONS",
                        "cmd notification allow_dnd $me",
                        "cmd deviceidle whitelist +$me"
                    )) Shz.exec(cmd)
                    runOnUiThread { if (!isDestroyed) { toast("Permisos solicitados. Revisa «Permisos» para ver cuáles quedaron concedidos."); showShizuku() } }
                }
            }, lp(12))
            b.addView(button("Probar conexión", false) {
                Shz.async {
                    val r = Shz.exec("id")
                    runOnUiThread { toast(if (r != null && r.ok) "Shizuku responde: ${r.out.take(60)}" else "Shizuku no respondió") }
                }
            }, lp(12))
            b.addView(label("Qué usará MAHORAGA al adaptar un juego", 15f, Mh.VIOLET_L, true), lp(16))
            switchRow(b, "Medir CPU y FPS reales", "Carga de CPU, FPS y temperatura de piel mientras el juego está en primer plano (cada 3 s, ligero).", "mh_shz_meter", true) { on ->
                if (!on) Shz.stopPoll()
            }
            switchRow(b, "Modo de juego de Android: rendimiento", "Pide al sistema el modo Rendimiento para el juego (si lo soporta). Se restaura al revertir.", "mh_shz_game", true)
            b.addView(label("La preparación del sistema antes de jugar (cerrar apps, limpiar caché, frenar el segundo plano) se configura en Configuración → «Preparar el sistema para jugar».", 12f, Mh.SUB), lp(8))
            b.addView(label("Estos ajustes se incluyen la próxima vez que pulses ADAPTACIÓN en un juego.", 12f, Mh.SUB), lp(8))
        }

        val no = card()
        no.addView(label("Lo que MAHORAGA NO hace con Shizuku", 14f, Mh.VIOLET_L, true))
        no.addView(label("• No desactiva protecciones térmicas ni fuerza frecuencias de CPU/GPU.\n• No toca archivos ni procesos de los juegos, ni inyecta código.\n• No cierra procesos esenciales de Android: solo apps instaladas por ti, nunca las protegidas, el teclado, las VPN, el launcher ni las que tienen un servicio activo (música, descargas, navegación).\n• Solo ejecuta comandos fijos del propio módulo, nunca texto escrito por ti.\n• «Conceder permisos automáticamente» solo da a MAHORAGA sus propios permisos (uso, superposición, notificaciones, No molestar y batería).\n• Cada cambio queda en el informe como aplicado, recomendado, no disponible o revertido.", 12f, Mh.SUB), lp(6))
        b.addView(no, lp(16))
    }

    /** Por app: «No poner burbuja flotante» (por ejemplo en TikTok, aunque se siga optimizando). */
    private fun bubbleSection(parent: LinearLayout) {
        val c = card()
        c.addView(label("Burbuja flotante por app", 15f, Mh.VIOLET_L, true))
        c.addView(label("Interruptor ENCENDIDO = esa app muestra la burbuja. Apagado = no la muestra (MAHORAGA sigue pudiendo adaptarla y optimizarla igual). Cada app es independiente de las demás.", 12f, Mh.SUB), lp(4))
        if (!Mh.panelEnabled(this)) c.addView(label("«Panel flotante en los juegos» (arriba) está apagado: mientras siga así no sale la burbuja en ninguna app, aunque la tengas encendida aquí.", 12f, Mh.WARN), lp(6))
        val lib = Games.library(this)
        if (lib.isEmpty()) c.addView(label("Aún no hay apps en tu biblioteca. Añádelas desde la pantalla principal de MAHORAGA.", 12f, Mh.SUB), lp(8))
        for (g in lib) {
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            val ic = ImageView(this)
            ic.setImageDrawable(Games.icon(this, g.pkg))
            r.addView(ic, LinearLayout.LayoutParams(d(34), d(34)))
            val tc = col()
            tc.setPadding(d(10), 0, d(6), 0)
            tc.addView(label(g.name, 14f, Mh.TEXT, true))
            tc.addView(label("Mostrar burbuja flotante", 11f, Mh.SUB))
            r.addView(tc, LinearLayout.LayoutParams(0, WRAP, 1f))
            val sw = Switch(this)
            sw.isChecked = Mh.bubbleOn(this, g.pkg)
            sw.thumbTintList = ColorStateList.valueOf(Color.WHITE)
            sw.trackTintList = ColorStateList.valueOf(Mh.VIOLET)
            sw.setOnCheckedChangeListener { _, on ->
                Mh.setBubbleOn(this, g.pkg, on)
                if (!on) EdgeUi.hideAll()
            }
            r.addView(sw)
            c.addView(r, lp(10))
        }
        parent.addView(c, lp(8))
    }

    /** Qué apps aparecen como accesos dentro de la burbuja (se abren en ventana pequeña). */
    private fun quickSection(parent: LinearLayout) {
        val c = card()
        c.addView(label("Apps en la burbuja", 15f, Mh.VIOLET_L, true))
        c.addView(label("Elige las apps que aparecen en el panel para abrirlas en ventana pequeña mientras juegas (máximo ${Quick.MAX}).", 12f, Mh.SUB), lp(4))
        val list = Quick.list(this)
        if (list.isEmpty()) c.addView(label("No hay ninguna app elegida.", 12f, Mh.SUB), lp(8))
        for (p in list) {
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            val ic = ImageView(this)
            ic.setImageDrawable(Games.icon(this, p))
            r.addView(ic, LinearLayout.LayoutParams(d(34), d(34)))
            val nm = label(Quick.name(this, p), 14f, Mh.TEXT, true)
            nm.setPadding(d(10), 0, d(6), 0)
            r.addView(nm, LinearLayout.LayoutParams(0, WRAP, 1f))
            val rm = label("Quitar", 13f, Mh.BAD, true)
            rm.setPadding(d(10), d(8), d(4), d(8))
            rm.setOnClickListener { Quick.remove(this, p); showSettings() }
            r.addView(rm)
            c.addView(r, lp(8))
        }
        if (list.size < Quick.MAX) {
            c.addView(button("Añadir app", true) {
                pickApp("Elige la app para la burbuja", list.toSet()) { Quick.add(this, it); showSettings() }
            }, lp(12))
        }
        c.addView(button("Restablecer (YouTube, TikTok, Kick)", false) { Quick.reset(this); showSettings() }, lp(8))
        parent.addView(c, lp(8))
    }

    /** Preparar el sistema antes de jugar: mira qué consume, cierra, limpia caché y frena; restaura al salir. */
    private fun boostSection(parent: LinearLayout) {
        val c = card()
        c.addView(label("Preparar el sistema para jugar", 15f, Mh.VIOLET_L, true))
        c.addView(label("Al pulsar JUGAR, MAHORAGA primero mira qué apps se están moviendo en segundo plano (CPU y RAM reales) y después actúa: cierra las que consumen y no usas, limpia su caché y frena su actividad mientras juegas. Si tras limpiar la RAM sigue baja, la próxima vez actúa más fuerte.", 12f, Mh.SUB), lp(4))
        if (!Shz.granted()) c.addView(label("Shizuku no está activo: solo puede pedir a Android que cierre procesos en caché. Para analizar y cerrar de verdad, activa Shizuku (Configuración con Shizuku).", 12f, Mh.WARN), lp(6))
        parent.addView(c, lp(8))
        switchRow(parent, "Preparar el sistema antes de jugar", "Se hace al pulsar JUGAR, antes de abrir el juego (unos segundos).", Boost.K_PRE, true)

        val lv = card()
        lv.addView(label("Intensidad", 14f, Mh.TEXT, true))
        val names = arrayOf("Suave", "Normal", "A fondo")
        val descs = arrayOf(
            "Solo apps que gastan mucho (≥ 5 % de CPU o ≥ 300 MB). Cierre seguro de Android.",
            "Apps que gastan ≥ 2 % de CPU o ≥ 150 MB. Cierra, limpia caché y frena su segundo plano mientras juegas.",
            "Casi todo lo que esté activo (≥ 50 MB). Es lo que más libera; las apps tardan más en volver a abrirse."
        )
        val cur = Boost.baseLevel(this)
        val row = LinearLayout(this)
        for (n in 0..2) {
            val bt = button(names[n], n == cur) { Prefs.setInt(this, Boost.K_LEVEL, n); showSettings() }
            row.addView(bt, LinearLayout.LayoutParams(0, WRAP, 1f).also { if (n > 0) it.leftMargin = d(6) })
        }
        lv.addView(row, lp(8))
        lv.addView(label(descs[cur], 12f, Mh.SUB), lp(8))
        parent.addView(lv, lp(8))

        switchRow(parent, "Congelar apps pesadas mientras juego", "Además de cerrarlas, las suspende (o desactiva si no se puede suspender) hasta que dejes de jugar; entonces se restauran solas. Las apps protegidas nunca se congelan. Requiere Shizuku y el Acceso de uso.", Boost.K_FREEZE, false)

        val info = card()
        val last = Boost.last(this)
        if (last != null) {
            info.addView(label("Última preparación", 14f, Mh.TEXT, true))
            info.addView(label(last, 12f, Mh.SUB), lp(4))
        } else info.addView(label("Aún no se ha preparado el sistema. Pulsa JUGAR en un juego de la biblioteca.", 12f, Mh.SUB))
        if (Boost.pending(this)) {
            info.addView(label("Hay ${Boost.pendingCount(this)} app(s) frenadas o congeladas que se restauran al dejar de jugar.", 12f, Mh.WARN), lp(8))
            info.addView(button("Restaurar todo ahora", true) {
                Boost.restore(this) { runOnUiThread { if (!isDestroyed) { toast("Apps restauradas"); showSettings() } } }
            }, lp(8))
        }
        info.addView(label("Nunca toca: el juego, MAHORAGA/VERDANT, Shizuku, tus apps protegidas y las de la burbuja, el launcher, el teclado, accesibilidad, oyentes de notificaciones, VPN, marcador y SMS predeterminados, apps con un servicio activo (música, descargas, navegación) ni apps del sistema.", 11f, Mh.SUB), lp(8))
        parent.addView(info, lp(8))
    }

    /** Apps que MAHORAGA nunca toca (por ejemplo una VPN como HTTP Custom). */
    private fun protectSection(parent: LinearLayout) {
        val c = card()
        c.addView(label("Apps protegidas", 15f, Mh.VIOLET_L, true))
        c.addView(label("MAHORAGA NO puede tocar estas apps: no se cierran, no se les limpia la caché, no se frenan ni se congelan (por ejemplo, una VPN como HTTP Custom para que no se desconecte). Además, MAHORAGA protege solo el teclado, el launcher, las VPN y las apps con servicio activo.", 12f, Mh.SUB), lp(4))
        val list = Protect.list(this)
        if (list.isEmpty()) c.addView(label("No hay ninguna app protegida.", 12f, Mh.SUB), lp(8))
        for (p in list) {
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            val ic = ImageView(this)
            ic.setImageDrawable(Games.icon(this, p))
            r.addView(ic, LinearLayout.LayoutParams(d(34), d(34)))
            val nm = label(Protect.name(this, p), 14f, Mh.TEXT, true)
            nm.setPadding(d(10), 0, d(6), 0)
            r.addView(nm, LinearLayout.LayoutParams(0, WRAP, 1f))
            val rm = label("Quitar", 13f, Mh.BAD, true)
            rm.setPadding(d(10), d(8), d(4), d(8))
            rm.setOnClickListener { Protect.remove(this, p); showSettings() }
            r.addView(rm)
            c.addView(r, lp(8))
        }
        c.addView(button("Proteger otra app", true) {
            pickApp("Elige la app a proteger", list.toSet()) { Protect.add(this, it); showSettings() }
        }, lp(12))
        parent.addView(c, lp(8))
    }

    /** Lista de apps instaladas para elegir una. */
    private fun pickApp(title: String, exclude: Set<String>, onPick: (String) -> Unit) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second !in exclude && it.second != packageName }
            .distinctBy { it.second }.sortedBy { it.first.lowercase() }
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = col()
        box.setPadding(d(16), d(14), d(16), d(10))
        box.background = Mh.round(Mh.CARD, d(20).toFloat(), Mh.LINE, d(1))
        box.addView(label(title, 16f, Mh.VIOLET_L, true))
        val list = col()
        for (a in apps) {
            val t = label(a.first, 15f, Mh.TEXT)
            t.setPadding(0, d(11), 0, d(11))
            t.setOnClickListener { dlg.dismiss(); onPick(a.second) }
            list.addView(t)
        }
        val sv = ScrollView(this)
        sv.addView(list)
        box.addView(sv, LinearLayout.LayoutParams(MATCH, d(380)))
        dlg.setContentView(box)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), WRAP)
        dlg.show()
    }

    private fun showSettings() {
        screen = "settings"
        setLive(null)
        val b = page("Configuración de MAHORAGA", true)
        switchRow(b, "Panel flotante en los juegos", "Interruptor general: si lo apagas no sale la burbuja en ninguna app. Encendido, cada app decide con su propio interruptor en «Burbuja flotante por app».", "mh_panel", true) { on ->
            if (!on) EdgeUi.hideAll()
            showSettings()
        }
        switchRow(b, "Diagnóstico automático", "Solo cuando abres una app con JUGAR desde dentro de MAHORAGA y todavía no se ha medido, empieza sola el diagnóstico (unos 3 a 4 min). Si la abres fuera de MAHORAGA, no hace nada y no gasta batería.", "mh_auto_diag", true)
        switchRow(b, "Optimización automática", "Al terminar el diagnóstico aplica solo los ajustes autorizados, sin que pulses nada.", "mh_auto_apply", true)
        boostSection(b)
        bubbleSection(b)
        quickSection(b)
        protectSection(b)
        switchRow(b, "Detección de juegos siempre activa", "Mantiene una notificación fija para mostrar el panel sin abrir los juegos desde MAHORAGA. Gasta algo más de batería.", "mh_always", false) { on ->
            if (on) MonitorService.ensure(this)
        }
        b.addView(button("Configuración con Shizuku", true) { go { showShizuku() } }, lp(12))
        b.addView(button("Permisos", false) { go { showPerms(null, null) } }, lp(8))
        b.addView(button("Historial de informes", false) { go { showHistory() } }, lp(8))
        b.addView(button("Restablecer posición de la pestaña", false) {
            Prefs.setInt(this, "mh_tab_y", 35); toast("Pestaña restablecida")
        }, lp(8))

        val a = card()
        a.addView(label("Información y límites reales", 15f, Mh.VIOLET_L, true))
        a.addView(label(
            "• MAHORAGA GAMES va dentro del mismo APK que VERDANT. VERDANT no ofrece desinstalarlo desde su cajón, pero desde los ajustes de Android solo se puede desinstalar junto con VERDANT: Android controla eso.\n" +
            "• No usa root, no inyecta código, no toca archivos de los juegos y no fuerza frecuencias.\n" +
            "• Con Shizuku analiza qué consume y cierra, limpia y frena apps instaladas (nunca las protegidas). Sin Shizuku, Android solo deja pedir el cierre de procesos en caché.\n" +
            "• FPS, GPU y, según el equipo, la carga de CPU no se pueden medir sin privilegios: se muestran como no disponibles, nunca estimados. Con Shizuku se miden CPU y FPS reales (la GPU sigue sin poder leerse).\n" +
            "• Las ventanas pequeñas de otras apps dependen de que el sistema admita ventanas flotantes; si no, MAHORAGA lo indica en vez de simularlo.\n" +
            "• Versión del módulo: 1.5", 12f, Mh.SUB), lp(6))
        b.addView(a, lp(14))
    }
}
