package com.personal.launcher

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/**
 * Pantalla «Web»: un navegador dentro del launcher. Se escribe cualquier enlace y la página se
 * ve y se desliza aquí, sin abrir Chrome. Recuerda la última página y las sesiones iniciadas
 * (cookies). El WebView solo se crea al abrir la pantalla por primera vez y se pausa al salir.
 */
@SuppressLint("SetJavaScriptEnabled")
class WebPanel(ctx: Context) : LinearLayout(ctx) {

    private val url = EditText(ctx)
    private val progress = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal)
    private val holder = FrameLayout(ctx)
    private var web: WebView? = null
    private var started = false
    private var topInset = 0
    private var bottomInset = 0

    init {
        orientation = VERTICAL
        setBackgroundColor(Color.parseColor("#FF020B06"))

        // Barra superior: atrás · dirección · ir · recargar
        val bar = LinearLayout(ctx)
        bar.orientation = HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = Ui.glass(ctx, 22)
        bar.setPadding(Ui.dp(ctx, 6), Ui.dp(ctx, 4), Ui.dp(ctx, 6), Ui.dp(ctx, 4))

        bar.addView(button("‹") { web?.let { if (it.canGoBack()) it.goBack() } })
        url.setSingleLine(true)
        url.hint = "Escribe o pega un enlace"
        url.setHintTextColor(Ui.SUB)
        url.setTextColor(Ui.TEXT)
        url.textSize = 14f
        url.background = null
        url.imeOptions = EditorInfo.IME_ACTION_GO
        url.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        url.setSelectAllOnFocus(true)
        url.setOnEditorActionListener { _, a, ev ->
            if (a == EditorInfo.IME_ACTION_GO || (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER)) {
                go(url.text.toString()); true
            } else false
        }
        bar.addView(url, LayoutParams(0, WRAP, 1f))
        bar.addView(button("Ir") { go(url.text.toString()) })
        bar.addView(button("⟳") { web?.reload() ?: go(url.text.toString()) })
        val blp = LayoutParams(MATCH, WRAP)
        blp.bottomMargin = Ui.dp(ctx, 6)
        addView(bar, blp)

        progress.max = 100
        progress.visibility = GONE
        progress.progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
        addView(progress, LayoutParams(MATCH, Ui.dp(ctx, 3)))

        addView(holder, LayoutParams(MATCH, 0, 1f))
        applyPadding()
    }

    private fun button(t: String, onClick: () -> Unit): TextView {
        val b = TextView(context)
        b.text = t
        b.setTextColor(Ui.ACCENT)
        b.textSize = 20f
        b.typeface = Typeface.DEFAULT_BOLD
        b.gravity = Gravity.CENTER
        b.minWidth = Ui.dp(context, 44)
        b.setPadding(Ui.dp(context, 8), Ui.dp(context, 8), Ui.dp(context, 8), Ui.dp(context, 8))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun applyPadding() {
        setPadding(Ui.dp(context, 12), Ui.dp(context, 12) + topInset, Ui.dp(context, 12), bottomInset)
    }

    fun setTopInset(px: Int) { topInset = px; applyPadding() }
    fun setBottomInset(px: Int) { bottomInset = px; applyPadding() }

    /** Cierra la historia de la página en lugar de salir de la pantalla. true = lo consumió. */
    fun onBack(): Boolean {
        val w = web ?: return false
        if (url.hasFocus()) { url.clearFocus(); hideKeyboard(); return true }
        if (w.canGoBack()) { w.goBack(); return true }
        return false
    }

    private fun hideKeyboard() {
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(url.windowToken, 0)
    }

    // ------------------------------------------------------------------ ciclo de vida

    fun start() {
        if (web == null) createWeb()
        web?.onResume()
        web?.resumeTimers()
        if (!started) {
            started = true
            val last = Prefs.str(context, "web_url")
            if (!last.isNullOrBlank()) go(last, false)
        }
    }

    fun stop() {
        web?.onPause()
        web?.pauseTimers()
    }

    override fun onDetachedFromWindow() {
        web?.let { holder.removeView(it); it.destroy() }
        web = null
        started = false
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ navegador

    private fun createWeb() {
        val w = WebView(context)
        w.setBackgroundColor(Color.parseColor("#FF020B06"))
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                val sch = u.scheme ?: return false
                if (sch == "http" || sch == "https" || sch == "about" || sch == "data") return false
                // tel:, whatsapp:, intent: … se pasan a la app que corresponda
                try { context.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                return true
            }

            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
                if (!url.hasFocus()) url.setText(u)
                progress.visibility = VISIBLE
            }

            override fun onPageFinished(v: WebView, u: String) {
                progress.visibility = GONE
                if (u.startsWith("http")) Prefs.setStr(context, "web_url", u)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                progress.progress = p
                progress.visibility = if (p >= 100) GONE else VISIBLE
            }
        }
        // Descargas: se entregan al navegador/administrador del sistema
        w.setDownloadListener { u, _, _, _, _ ->
            try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
        holder.addView(w, FrameLayout.LayoutParams(MATCH, MATCH))
        web = w
    }

    /** Acepta enlaces completos, dominios sueltos («secure.com/panel») o texto para buscar. */
    private fun normalize(raw: String): String {
        val t = raw.trim()
        if (t.contains("://")) return t
        if (!t.contains(" ") && t.contains(".")) return "https://$t"
        return "https://www.google.com/search?q=" + Uri.encode(t)
    }

    private fun go(raw: String, hide: Boolean = true) {
        if (raw.isBlank()) return
        if (web == null) createWeb()
        val u = normalize(raw)
        url.setText(u)
        url.clearFocus()
        if (hide) hideKeyboard()
        web?.loadUrl(u)
    }
}
