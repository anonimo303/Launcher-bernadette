package com.personal.launcher

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Barra de progreso simple (sin recursos de imagen). */
private class BarView(ctx: Context) : View(ctx) {
    var fraction = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    /** Si es false la barra no se pone amarilla/roja (se usa cuando el dato no es una carga real). */
    var warn = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        p.color = 0x33FFFFFF
        r.set(0f, 0f, width.toFloat(), h)
        c.drawRoundRect(r, h / 2f, h / 2f, p)
        if (fraction > 0f) {
            p.color = when {
                !warn -> Ui.ACCENT
                fraction > 0.9f -> Color.parseColor("#FF6B6B")
                fraction > 0.75f -> Color.parseColor("#FFC857")
                else -> Ui.ACCENT
            }
            r.set(0f, 0f, maxOf(h, width * fraction), h)
            c.drawRoundRect(r, h / 2f, h / 2f, p)
        }
    }
}

/** Tarjeta de una métrica: título, valor, barra y detalle. */
private class MetricCard(ctx: Context, title: String) : LinearLayout(ctx) {
    private val value = TextView(ctx)
    private val bar = BarView(ctx)
    private val detail = TextView(ctx)

    init {
        orientation = VERTICAL
        background = Ui.glass(ctx, 22)
        setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 14), Ui.dp(ctx, 16), Ui.dp(ctx, 14))

        val row = LinearLayout(ctx)
        row.orientation = HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(ctx)
        t.text = title
        t.setTextColor(Ui.TEXT)
        t.textSize = 17f
        t.typeface = Typeface.DEFAULT_BOLD
        row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        value.setTextColor(Ui.ACCENT)
        value.textSize = 17f
        value.typeface = Typeface.DEFAULT_BOLD
        row.addView(value)
        addView(row, LayoutParams(MATCH, WRAP))

        val blp = LayoutParams(MATCH, Ui.dp(ctx, 8))
        blp.topMargin = Ui.dp(ctx, 10)
        addView(bar, blp)

        detail.setTextColor(Ui.SUB)
        detail.textSize = 13f
        detail.setPadding(0, Ui.dp(ctx, 8), 0, 0)
        addView(detail, LayoutParams(MATCH, WRAP))

        val lp = LayoutParams(MATCH, WRAP)
        lp.bottomMargin = Ui.dp(ctx, 10)
        layoutParams = lp
    }

    fun set(fraction: Float?, valueText: String, detailText: String, warn: Boolean = true) {
        bar.warn = warn
        bar.fraction = fraction ?: 0f
        value.text = valueText
        detail.text = detailText
    }
}

/**
 * Pantalla «Recursos del teléfono»: RAM, batería y almacenamiento con datos reales.
 * Solo se actualiza (cada 1,5 s) mientras la pantalla está visible, para no gastar CPU.
 */
class ResourcesPanel(ctx: Context) : ScrollView(ctx) {

    private val col = LinearLayout(ctx)
    private val ram = MetricCard(ctx, "Memoria RAM")
    private val bat = MetricCard(ctx, "Batería")
    private val sto = MetricCard(ctx, "Almacenamiento")
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager


    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            update()
            if (Prefs.bool(context, "res_live", true)) {
                handler.postDelayed(this, if (Prefs.perfSave(context)) 3500L else 1500L)
            }
        }
    }

    init {
        isVerticalScrollBarEnabled = false
        setBackgroundColor(Color.parseColor("#FF020B06"))
        col.orientation = LinearLayout.VERTICAL
        setBottomInset(0)

        val title = TextView(ctx)
        title.text = "Recursos del teléfono"
        title.setTextColor(Ui.TEXT)
        title.textSize = 24f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setPadding(Ui.dp(ctx, 4), Ui.dp(ctx, 4), 0, Ui.dp(ctx, 14))
        col.addView(title)
        col.addView(ram)
        col.addView(bat)
        col.addView(sto)
        addView(col, LayoutParams(MATCH, WRAP))
        update()
    }

    private var topInset = 0
    private var bottomInset = 0

    private fun applyPadding() {
        col.setPadding(Ui.dp(context, 16), Ui.dp(context, 16) + topInset, Ui.dp(context, 16), bottomInset + Ui.dp(context, 16))
    }

    fun setBottomInset(px: Int) {
        bottomInset = px
        applyPadding()
    }

    fun setTopInset(px: Int) {
        topInset = px
        applyPadding()
    }

    fun start() {
        if (running) return
        running = true
        // La primera lectura espera a que termine el deslizamiento: leer /proc, batería y disco
        // en el hilo principal justo al empezar la animación la hacía saltar.
        handler.postDelayed(tick, 380L)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(tick)
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ datos

    private fun gb(bytes: Long): String = "%.1f GB".format(bytes / 1073741824.0)

    private fun update() {
        updateRam()
        updateBattery()
        updateStorage()
    }

    private fun updateRam() {
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem
        val used = total - mi.availMem
        val f = if (total > 0) used.toFloat() / total else 0f
        ram.set(
            f, "${(f * 100).toInt()}%",
            "Usada ${gb(used)} de ${gb(total)} · Libre ${gb(mi.availMem)}" +
                if (mi.lowMemory) "\nAndroid indica poca memoria disponible" else ""
        )
    }

    private fun updateBattery() {
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (i == null) {
            bat.set(null, "—", "No disponible")
            return
        }
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val volt = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val f = if (level >= 0 && scale > 0) level.toFloat() / scale else 0f
        val st = when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Cargando"
            BatteryManager.BATTERY_STATUS_FULL -> "Completa"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Descargando"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Sin cargar"
            else -> "Estado desconocido"
        }
        val src = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> " · Cargador"
            BatteryManager.BATTERY_PLUGGED_USB -> " · USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> " · Inalámbrica"
            else -> ""
        }
        val sb = StringBuilder(st).append(src)
        if (temp != Int.MIN_VALUE) sb.append(" · ").append("%.1f °C".format(temp / 10.0))
        if (volt > 0) sb.append(" · ").append("%.2f V".format(volt / 1000.0))
        bat.set(f, "${(f * 100).toInt()}%", sb.toString())
    }

    private fun updateStorage() {
        try {
            val st = StatFs(Environment.getDataDirectory().path)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBlocksLong * st.blockSizeLong
            val used = total - free
            val f = if (total > 0) used.toFloat() / total else 0f
            sto.set(f, "${(f * 100).toInt()}%", "Usado ${gb(used)} de ${gb(total)} · Libre ${gb(free)}")
        } catch (e: Exception) {
            sto.set(null, "—", "No disponible")
        }
    }
}
