package com.personal.launcher.mahoraga

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import com.personal.launcher.Prefs
import com.personal.launcher.R

/**
 * Servicio ligero en primer plano. Solo muestrea cuando hace falta:
 *  · diagnóstico inicial (≈ 3,5 min de juego),
 *  · juego adaptado en primer plano (cada 5 s con «actividad propia reducida»).
 * Se detiene solo tras 2 min sin juegos (salvo que el usuario active «detección siempre activa»).
 */
class MonitorService : Service() {

    companion object {
        private const val CH_MON = "mh_monitor"
        private const val CH_ALERT = "mh_alert"
        private const val NID = 7001
        const val DIAG_TARGET = 210

        @Volatile var running = false
        @Volatile var diagPkg: String? = null
        @Volatile var diagSecs = 0

        private fun go(c: Context, action: String, pkg: String? = null) {
            try {
                val i = Intent(c, MonitorService::class.java).setAction(action)
                if (pkg != null) i.putExtra("pkg", pkg)
                c.startForegroundService(i)
            } catch (e: Exception) { }
        }

        fun ensure(c: Context) = go(c, "ensure")
        fun startDiag(c: Context, pkg: String) = go(c, "diag", pkg)
        fun cancelDiag(c: Context) = go(c, "diag_cancel")
        fun stop(c: Context) { try { c.stopService(Intent(c, MonitorService::class.java)) } catch (e: Exception) { } }

        /** Gancho llamado desde VERDANT al abrir cualquier app: arranca la vigilancia solo si es un juego de la biblioteca. */
        /** SOLO lo llama MAHORAGA cuando abres una app con JUGAR desde dentro de MAHORAGA: ahí se enciende el servicio. */
        fun onAppLaunched(c: Context, pkg: String) {
            if (Games.find(c, pkg) != null && Mh.usageGranted(c)) go(c, "launch", pkg)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var diagAcc: StatsAcc? = null
    private var diagStarted = 0L
    private var watchPkg: String? = null
    private var watchAcc: StatsAcc? = null
    private var lastAlert = 0L
    private var lastClean = 0L
    private var lastGameSeen = 0L
    private var idleSince = 0L
    private var nextDelay = 4000L
    private var armPkg: String? = null   // app abierta desde MAHORAGA: la única que arranca el diagnóstico automático
    private var armAt = 0L
    private var studiedPkg: String? = null

    // ---- MAHORAGA IA: solo trabaja en partidas abiertas con JUGAR desde dentro de MAHORAGA
    private var iaPkg: String? = null        // juego abierto desde MAHORAGA, pendiente de detectar en primer plano
    private var iaAt = 0L
    private var iaActive: String? = null     // partida con la IA trabajando

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try { step() } catch (e: Exception) { }
            if (running) handler.postDelayed(this, nextDelay)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_MON, "MAHORAGA vigilando", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Avisos de MAHORAGA", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        startFg("Esperando un juego")
        when (i?.action) {
            "diag" -> {
                diagPkg = i.getStringExtra("pkg")
                diagAcc = StatsAcc()
                diagSecs = 0
                diagStarted = SystemClock.elapsedRealtime()
                Fg.reset()
            }
            "launch" -> {
                armPkg = i.getStringExtra("pkg"); armAt = SystemClock.elapsedRealtime()
                iaPkg = armPkg; iaAt = armAt
            }
            "diag_cancel" -> { diagPkg = null; diagAcc = null; diagSecs = 0 }
            "tune_yes" -> answerTune(i.getStringExtra("pkg"), true)
            "tune_no" -> answerTune(i.getStringExtra("pkg"), false)
        }
        running = true
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun startFg(text: String) {
        val n = Notification.Builder(this, CH_MON)
            .setSmallIcon(R.drawable.mh_ic_trend)
            .setContentTitle("MAHORAGA GAMES")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openApp(null))
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NID, n)
    }

    private fun openApp(pkg: String?): PendingIntent {
        val i = Intent(this, MahoragaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) i.putExtra("pkg", pkg)
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun alert(title: String, text: String, pkg: String?) {
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.mh_ic_trend)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openApp(pkg))
            .build()
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % 100000).toInt() + 10, n)
    }

    private fun step() {
        val now = SystemClock.elapsedRealtime()
        val usage = Mh.usageGranted(this)
        val top = if (usage) Fg.top(this) else null
        val game = if (top != null) Games.find(this, top) else null
        EdgeUi.sync(this, game)
        if (game != null && Prefs.bool(this, "mh_shz_meter", true) && Shz.granted()) Shz.startPoll(game.pkg) else Shz.stopPoll()

        if (game != null && diagPkg == null && armPkg != null && Prefs.bool(this, "mh_auto_diag", true)) maybeAutoDiag(game, now)
        iaStep(game, now)

        val dp = diagPkg
        if (dp != null) {
            val inGame = if (usage) top == dp else true
            if (inGame) {
                val acc = diagAcc ?: StatsAcc().also { diagAcc = it }
                acc.add(Sys.sample(this), now)
                diagSecs = acc.seconds
                if (diagSecs >= DIAG_TARGET) finishDiag(usage)
            }
            if (diagPkg != null && now - diagStarted > 25 * 60_000L) {
                diagPkg = null; diagAcc = null; diagSecs = 0
                alert("Diagnóstico cancelado", "No se midió suficiente tiempo de juego. Vuelve a intentarlo desde ADAPTACIÓN.", null)
            }
        } else if (game != null) {
            watch(game, now)
        } else {
            endWatch()
        }

        if (game != null) lastGameSeen = now
        else if (lastGameSeen != 0L && now - lastGameSeen > 90_000L && Boost.pending(this)) {
            lastGameSeen = 0L
            Boost.restore(this)
        }

        val busy = game != null || diagPkg != null
        if (!busy) {
            if (idleSince == 0L) idleSince = now
            else if (now - idleSince > 120_000L && !Prefs.bool(this, "mh_always", false)) { shutdown(); return }
        } else idleSince = 0L
        val light = game != null && Brain.activeIds(this, game.pkg).contains("light")
        nextDelay = if (!busy) 4000L else if (light && diagPkg == null) 5000L else 2000L
    }

    private fun finishDiag(usage: Boolean) {
        val pkg = diagPkg ?: return
        val st = diagAcc?.stats()
        diagPkg = null; diagAcc = null; diagSecs = 0
        val g = Games.find(this, pkg) ?: return
        if (st == null) return
        val r = Report(System.currentTimeMillis(), Reports.nextNum(this), pkg, g.name, System.currentTimeMillis())
        r.diag = st
        r.verified = usage
        r.findings = Brain.findings(st, usage)
        r.actions = Brain.plan(this, g, st, r.findings)
        Reports.save(this, r)
        if (Prefs.bool(this, "mh_auto_apply", true)) autoApply(r, g)
        else alert("Diagnóstico de ${g.name} listo", "Abre MAHORAGA y toca ADAPTACIÓN para ver qué detectó y aplicar los ajustes autorizados.", pkg)
    }

    /** Sin estudio previo, o con más de 14 días: vuelve a medir para adaptarse a cómo lo usas ahora. */
    private fun needsStudy(pkg: String): Boolean {
        val r = Reports.latest(this, pkg)
        if (r == null || r.diag == null) return true
        return System.currentTimeMillis() - r.ts > 14L * 24 * 3600 * 1000
    }

    /** Aviso con botones Sí / No: aplicar la mejora exige reiniciar el juego. Sí = aplica y vuelve a abrirlo. */
    private fun askTune(g: Game) {
        val fl = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val yes = PendingIntent.getService(this, 71,
            Intent(this, MonitorService::class.java).setAction("tune_yes").putExtra("pkg", g.pkg), fl)
        val no = PendingIntent.getService(this, 72,
            Intent(this, MonitorService::class.java).setAction("tune_no").putExtra("pkg", g.pkg), fl)
        val ic = android.graphics.drawable.Icon.createWithResource(this, R.drawable.mh_ic_trend)
        val txt = "Encontré cómo hacer que ${g.name} vaya más fluido y caliente menos (bajar un poco la resolución). " +
            "Para aplicarlo hay que cerrar el juego y volver a abrirlo. ¿Lo hago ahora?"
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.mh_ic_trend)
            .setContentTitle("MAHORAGA · ¿Reiniciar ${g.name}?")
            .setContentText("Sí = aplica y vuelve al juego. No = se aplica al cerrarlo.")
            .setStyle(Notification.BigTextStyle().bigText(txt))
            .addAction(Notification.Action.Builder(ic, "Sí, aplicar ahora", yes).build())
            .addAction(Notification.Action.Builder(ic, "No, después", no).build())
            .setAutoCancel(true)
            .setTimeoutAfter(10 * 60_000L)
            .build()
        getSystemService(NotificationManager::class.java).notify(7002, n)
    }

    private fun answerTune(pkg: String?, yes: Boolean) {
        getSystemService(NotificationManager::class.java).cancel(7002)
        if (pkg == null) return
        if (!yes) { Prefs.setBool(this, "mh_tune_wait_$pkg", true); return }   // se aplica solo al cerrar el juego
        val app = applicationContext
        Shz.async {
            val f = Prefs.str(app, "mh_tune_f_$pkg") ?: "0.9"
            if (Tune.applyResolution(pkg, f)) {
                Prefs.setBool(app, "mh_tune_wait_$pkg", false)
                Tune.restartGame(pkg)
            }
        }
    }

    /** Solo si abriste esta app con JUGAR desde MAHORAGA (hace menos de 2 min) y aún no tiene informe. */
    private fun maybeAutoDiag(game: Game, now: Long) {
        val p = armPkg ?: return
        if (now - armAt > 120_000L) { armPkg = null; return }
        if (p != game.pkg) return
        armPkg = null
        if (!needsStudy(game.pkg)) return
        diagPkg = game.pkg
        diagAcc = StatsAcc()
        diagSecs = 0
        diagStarted = now
        // Misma animación de la rueda dorada que «se ha adaptado»; si no hay permiso de superposición, aviso normal.
        val shown = MahoragaNotice.show(
            this, game.name,
            listOf("Midiendo CPU, memoria y temperatura (3 a 4 min)", "Úsala con normalidad: al terminar optimiza sola"),
            "COMENZANDO EL PROCESO DE ADAPTACIÓN", "${game.name} · midiendo 3 a 4 min"
        )
        if (!shown) alert("Comenzando el proceso de adaptación", "MAHORAGA está midiendo ${game.name} (unos 3 a 4 min). Úsala con normalidad; al terminar optimiza sola.", game.pkg)
    }

    /** Al terminar el diagnóstico aplica los ajustes autorizados, sin que el usuario pulse nada. */
    private fun autoApply(r: Report, g: Game) {
        val n = r.findings.count { it.problem }
        alert("Diagnóstico de ${g.name} listo",
            (if (n > 0) "Detectó $n punto${if (n == 1) "" else "s"} a mejorar. " else "Sin problemas claros. ") + "Ahora comenzando optimización…", g.pkg)
        val app = applicationContext
        Thread {
            val done = try { Brain.apply(app, r) } catch (e: Exception) { emptyList<Action>() }
            handler.post {
                if (done.isEmpty()) {
                    alert("No se aplicó ninguna optimización", "Faltan permisos. Revisa «Permisos» dentro de MAHORAGA.", g.pkg)
                } else {
                    val lines = Brain.lines(done)
                    if (!MahoragaNotice.show(app, g.name, lines)) alert("Optimización de ${g.name} aplicada", lines.joinToString("\n"), g.pkg)
                    if (done.any { it.id == "shz_tune" } && Prefs.bool(app, "mh_tune_wait_${g.pkg}", false)) askTune(g)
                }
            }
        }.start()
    }

    private fun watch(game: Game, now: Long) {
        if (watchPkg != game.pkg) {
            endWatch()
            watchPkg = game.pkg
            watchAcc = StatsAcc()
            if (Prefs.bool(this, "mh_dnd_auto_${game.pkg}", false)) Dnd.enter(this)
            // Si ya se preparó el sistema al pulsar JUGAR (hace < 3 min), no se repite.
            if (Brain.activeIds(this, game.pkg).contains("shz_clean") && Boost.enabled(this) &&
                !Boost.recent(this, 180_000L) && now - lastClean > 600_000L) {
                lastClean = now
                Boost.runAsync(this, game.pkg)
            }
            updateText("Vigilando: ${game.name}")
        }
        val ids = Brain.activeIds(this, game.pkg)
        val thermal = Brain.thermalOn(this, game.pkg)
        if (ids.isEmpty() && !thermal) return
        val s = Sys.sample(this)
        if (ids.contains("monitor")) watchAcc?.add(s, now)
        if (thermal && !s.battTemp.isNaN() && now - lastAlert > 300_000L) {
            val warn = 41f
            if (s.battTemp >= warn) {
                lastAlert = now
                alert("Temperatura alta: %.1f °C".format(s.battTemp), "Haz una pausa corta o quita la funda para que se enfríe. MAHORAGA ya está usando lo mínimo posible.", game.pkg)
            }
        }
    }

    private fun endWatch() {
        // Sin juego en primer plano, No molestar no debe quedar activo (salvo que lo activaras a mano desde el panel).
        if (Prefs.int(this, "mh_dnd_prev", -99) != -99 && !Prefs.bool(this, "mh_dnd_manual", false)) Dnd.exit(this)
        val p = watchPkg ?: return
        val acc = watchAcc
        watchPkg = null; watchAcc = null
        studiedPkg = null
        Tune.afterGame(this, p)
        updateText("Esperando un juego")
        val st = acc?.stats() ?: return
        if (st.seconds < 90) return
        val r = Reports.latest(this, p) ?: return
        if (!r.applied) return
        r.after = st
        r.afterTs = System.currentTimeMillis()
        Reports.save(this, r)
    }

    private fun updateText(t: String) {
        val n = Notification.Builder(this, CH_MON)
            .setSmallIcon(R.drawable.mh_ic_trend)
            .setContentTitle("MAHORAGA GAMES")
            .setContentText(t)
            .setOngoing(true)
            .setContentIntent(openApp(null))
            .build()
        getSystemService(NotificationManager::class.java).notify(NID, n)
    }

    // ------------------------------------------------------------------ MAHORAGA IA

    private fun iaStep(game: Game?, now: Long) {
        val act = iaActive
        if (act != null && (game == null || game.pkg != act)) {
            // pequeña gracia por si cambias un momento de app y vuelves al juego
            if (game == null && now - lastGameSeen <= 90_000L) return
            iaStop()
        }
        if (!Prefs.bool(this, "mh_ia_auto", true)) { if (iaActive != null) iaStop(); return }
        if (game == null) {
            if (Net.forced(this)) Net.endAsync(this)     // por si el servicio murió con el Wi-Fi forzado
            return
        }
        if (iaActive == null) {
            // Juego abierto fuera de MAHORAGA (o hace demasiado): la IA no hace nada.
            if (iaPkg != game.pkg || now - iaAt > 180_000L) return
            iaActive = game.pkg
            iaPkg = null
            iaStart(game)
        }
    }

    /** Al abrir el juego desde MAHORAGA: optimiza el equipo y la red sin que pulses nada. */
    private fun iaStart(game: Game) {
        val app = applicationContext
        val studying = diagPkg == game.pkg     // si ya está midiendo, optimiza al terminar (autoApply)
        Thread {
            val sum = if (studying) null else try { Ia.optimize(app, game) } catch (e: Exception) { null }
            val net = if (Prefs.bool(app, "mh_ia_net", true)) try { Net.begin(app, game) } catch (e: Exception) { null } else null
            handler.post {
                val lines = (sum?.applied ?: emptyList()) + (net ?: emptyList())
                if (lines.isNotEmpty() && !MahoragaNotice.show(app, game.name, lines, "MAHORAGA IA · OPTIMIZADO", "${game.name} · optimizado automáticamente"))
                    alert("MAHORAGA IA optimizó ${game.name}", lines.joinToString("\n"), game.pkg)
                if (sum != null && sum.applied.any { it.startsWith("Resolución del juego") } && Prefs.bool(app, "mh_tune_wait_${game.pkg}", false)) askTune(game)
            }
        }.start()
    }

    private fun iaStop() {
        iaActive = null
        Net.endAsync(this)
    }

    private fun shutdown() {
        iaStop()
        running = false
        handler.removeCallbacks(tick)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        iaStop()
        running = false
        handler.removeCallbacks(tick)
        if (!Prefs.bool(this, "mh_dnd_manual", false)) Dnd.exit(this)
        Boost.restore(this)
        EdgeUi.hideAll()
        Shz.stopPoll()
        super.onDestroy()
    }
}
