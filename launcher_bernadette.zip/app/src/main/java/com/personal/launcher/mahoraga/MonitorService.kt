package com.personal.launcher.mahoraga

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import com.personal.launcher.Prefs
import com.personal.launcher.R

/**
 * Servicio ligero en primer plano. Solo muestrea cuando hace falta:
 *  · diagnóstico inicial (≈ 3,5 min de juego),
 *  · juego adaptado en primer plano (cada 5 s con «actividad propia reducida»).
 * Se detiene solo tras 2 min sin juegos (salvo que el usuario active «detección siempre activa»).
 */
class MonitorService : Service() {

    companion object {
        private const val CH_MON = "mh_monitor"
        private const val CH_ALERT = "mh_alert"
        private const val NID = 7001
        const val DIAG_TARGET = 210

        @Volatile var running = false
        @Volatile var diagPkg: String? = null
        @Volatile var diagSecs = 0

        private fun go(c: Context, action: String, pkg: String? = null) {
            try {
                val i = Intent(c, MonitorService::class.java).setAction(action)
                if (pkg != null) i.putExtra("pkg", pkg)
                c.startForegroundService(i)
            } catch (e: Exception) { }
        }

        fun ensure(c: Context) = go(c, "ensure")
        fun startDiag(c: Context, pkg: String) = go(c, "diag", pkg)
        fun cancelDiag(c: Context) = go(c, "diag_cancel")
        fun stop(c: Context) { try { c.stopService(Intent(c, MonitorService::class.java)) } catch (e: Exception) { } }

        /** Gancho llamado desde VERDANT al abrir cualquier app: arranca la vigilancia solo si es un juego de la biblioteca. */
        fun onAppLaunched(c: Context, pkg: String) {
            if (Games.find(c, pkg) != null && Mh.usageGranted(c)) ensure(c)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var diagAcc: StatsAcc? = null
    private var diagStarted = 0L
    private var watchPkg: String? = null
    private var watchAcc: StatsAcc? = null
    private var lastAlert = 0L
    private var lastClean = 0L
    private var idleSince = 0L
    private var nextDelay = 4000L

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try { step() } catch (e: Exception) { }
            if (running) handler.postDelayed(this, nextDelay)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_MON, "MAHORAGA vigilando", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Avisos de MAHORAGA", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        startFg("Esperando un juego")
        when (i?.action) {
            "diag" -> {
                diagPkg = i.getStringExtra("pkg")
                diagAcc = StatsAcc()
                diagSecs = 0
                diagStarted = SystemClock.elapsedRealtime()
                Fg.reset()
            }
            "diag_cancel" -> { diagPkg = null; diagAcc = null; diagSecs = 0 }
        }
        running = true
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun startFg(text: String) {
        val n = Notification.Builder(this, CH_MON)
            .setSmallIcon(R.drawable.mh_ic_trend)
            .setContentTitle("MAHORAGA GAMES")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openApp(null))
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NID, n)
    }

    private fun openApp(pkg: String?): PendingIntent {
        val i = Intent(this, MahoragaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) i.putExtra("pkg", pkg)
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun alert(title: String, text: String, pkg: String?) {
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.mh_ic_trend)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openApp(pkg))
            .build()
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % 100000).toInt() + 10, n)
    }

    private fun step() {
        val now = SystemClock.elapsedRealtime()
        val usage = Mh.usageGranted(this)
        val top = if (usage) Fg.top(this) else null
        val game = if (top != null) Games.find(this, top) else null
        EdgeUi.sync(this, game)
        if (game != null && Prefs.bool(this, "mh_shz_meter", true) && Shz.granted()) Shz.startPoll(game.pkg) else Shz.stopPoll()

        val dp = diagPkg
        if (dp != null) {
            val inGame = if (usage) top == dp else true
            if (inGame) {
                val acc = diagAcc ?: StatsAcc().also { diagAcc = it }
                acc.add(Sys.sample(this), now)
                diagSecs = acc.seconds
                if (diagSecs >= DIAG_TARGET) finishDiag(usage)
            }
            if (diagPkg != null && now - diagStarted > 25 * 60_000L) {
                diagPkg = null; diagAcc = null; diagSecs = 0
                alert("Diagnóstico cancelado", "No se midió suficiente tiempo de juego. Vuelve a intentarlo desde ADAPTACIÓN.", null)
            }
        } else if (game != null) {
            watch(game, now)
        } else {
            endWatch()
        }

        val busy = game != null || diagPkg != null
        if (!busy) {
            if (idleSince == 0L) idleSince = now
            else if (now - idleSince > 120_000L && !Prefs.bool(this, "mh_always", false)) { shutdown(); return }
        } else idleSince = 0L
        val light = game != null && Brain.activeIds(this, game.pkg).contains("light")
        nextDelay = if (!busy) 4000L else if (light && diagPkg == null) 5000L else 2000L
    }

    private fun finishDiag(usage: Boolean) {
        val pkg = diagPkg ?: return
        val st = diagAcc?.stats()
        diagPkg = null; diagAcc = null; diagSecs = 0
        val g = Games.find(this, pkg) ?: return
        if (st == null) return
        val r = Report(System.currentTimeMillis(), Reports.nextNum(this), pkg, g.name, System.currentTimeMillis())
        r.diag = st
        r.verified = usage
        r.findings = Brain.findings(st, usage)
        r.actions = Brain.plan(this, g, st, r.findings)
        Reports.save(this, r)
        alert("Diagnóstico de ${g.name} listo", "Abre MAHORAGA y toca ADAPTACIÓN para ver qué detectó y aplicar los ajustes autorizados.", pkg)
    }

    private fun watch(game: Game, now: Long) {
        if (watchPkg != game.pkg) {
            endWatch()
            watchPkg = game.pkg
            watchAcc = StatsAcc()
            if (Brain.activeIds(this, game.pkg).contains("dnd")) Dnd.enter(this)
            if (Brain.activeIds(this, game.pkg).contains("shz_clean") && Shz.granted() && now - lastClean > 600_000L) {
                lastClean = now
                Shz.cleanMemory(this, game.pkg)
            }
            updateText("Vigilando: ${game.name}")
        }
        val ids = Brain.activeIds(this, game.pkg)
        val thermal = Brain.thermalOn(this, game.pkg)
        if (ids.isEmpty() && !thermal) return
        val s = Sys.sample(this)
        if (ids.contains("monitor")) watchAcc?.add(s, now)
        if (thermal && !s.battTemp.isNaN() && now - lastAlert > 300_000L) {
            val warn = 41f
            if (s.battTemp >= warn) {
                lastAlert = now
                alert("Temperatura alta: %.1f °C".format(s.battTemp), "Considera bajar los gráficos del juego o hacer una pausa.", game.pkg)
            }
        }
    }

    private fun endWatch() {
        val p = watchPkg ?: return
        val acc = watchAcc
        watchPkg = null; watchAcc = null
        if (Prefs.int(this, "mh_dnd_prev", -99) != -99 && !Prefs.bool(this, "mh_dnd_manual", false)) Dnd.exit(this)
        updateText("Esperando un juego")
        val st = acc?.stats() ?: return
        if (st.seconds < 90) return
        val r = Reports.latest(this, p) ?: return
        if (!r.applied) return
        r.after = st
        r.afterTs = System.currentTimeMillis()
        Reports.save(this, r)
    }

    private fun updateText(t: String) {
        val n = Notification.Builder(this, CH_MON)
            .setSmallIcon(R.drawable.mh_ic_trend)
            .setContentTitle("MAHORAGA GAMES")
            .setContentText(t)
            .setOngoing(true)
            .setContentIntent(openApp(null))
            .build()
        getSystemService(NotificationManager::class.java).notify(NID, n)
    }

    private fun shutdown() {
        running = false
        handler.removeCallbacks(tick)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        if (!Prefs.bool(this, "mh_dnd_manual", false)) Dnd.exit(this)
        EdgeUi.hideAll()
        Shz.stopPoll()
        super.onDestroy()
    }
}
