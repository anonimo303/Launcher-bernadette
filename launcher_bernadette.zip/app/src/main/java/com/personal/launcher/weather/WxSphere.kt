package com.personal.launcher.weather

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Esfera meteorológica «3D» dibujada con Canvas (sin OpenGL, sin imágenes):
 *  · cuerpo de cristal con luz azul/violeta, borde de Fresnel, reflejo y anillos orbitales que
 *    pasan por detrás y por delante (profundidad real);
 *  · el clima vive DENTRO: las nubes están en longitud/latitud y giran alrededor de la esfera
 *    (se estrechan y se desvanecen hacia el borde), lluvia, nieve, rayos, sol o luna;
 *  · se puede girar con el dedo (con inercia). Solo anima cuando el reloj de Clima la llama.
 */
class WxSphere(ctx: Context) : View(ctx) {

    /** 0 = fija, 1 = reducida, 2 = completa. */
    var quality = 2

    private var kind = WxKind.CLOUDY
    private var night = false
    private var level = 2

    private var yaw = 0f
    private var spin = AUTO
    private var tilt = 0f
    private var t = 0f
    private var dragging = false
    private var lastX = 0f
    private var lastY = 0f
    private var lastMs = 0L
    private var dragVel = 0f

    private val d = ctx.resources.displayMetrics.density
    private var cx = 0f
    private var cy = 0f
    private var r = 0f

    // ---- pinturas (los shaders dependen del tamaño y se crean en onSizeChanged) ----
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bodyPaints = Array(8) { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val vignette = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bottomGlow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val warm = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rimGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val specArc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val ringGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ringCore = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val rainFar = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xFF9CC4FF.toInt() }
    private val rainNear = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xFFD6E6FF.toInt() }
    private val snowSmall = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xFFFFFFFF.toInt() }
    private val snowBig = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xFFFFFFFF.toInt() }
    private val fogPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFDCE2FF.toInt() }
    private val flashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFC8C0FF.toInt() }
    private val boltGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = 0xFFA070FF.toInt() }
    private val boltCore = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = 0xFFFFFFFF.toInt() }
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }

    private val clip = Path()
    private val bolt = Path()
    private val oval = RectF()
    private val box = RectF()
    private val rimMatrix = Matrix()
    private var rimShader: SweepGradient? = null

    // ---- nubes (longitud / latitud sobre la esfera) ----
    private val nMax = 8
    private var nc = 0
    private val lon = FloatArray(nMax)
    private val lat = FloatArray(nMax)
    private val csz = FloatArray(nMax)
    private val ctint = IntArray(nMax)
    private val clouds: Array<Bitmap> by lazy {
        arrayOf(WxArt.cloudBitmap(WxArt.TINT_LIGHT), WxArt.cloudBitmap(WxArt.TINT_GRAY), WxArt.cloudBitmap(WxArt.TINT_DARK))
    }

    // ---- partículas (en fracciones del radio) ----
    private val pMax = 64
    private var np = 0
    private val ppx = FloatArray(pMax)
    private val ppy = FloatArray(pMax)
    private val ppv = FloatArray(pMax)
    private val ppz = FloatArray(pMax)
    private val farBuf = FloatArray(pMax * 4)
    private val nearBuf = FloatArray(pMax * 4)
    private val pts1 = FloatArray(pMax * 2)
    private val pts2 = FloatArray(pMax * 2)
    private val starX = FloatArray(16)
    private val starY = FloatArray(16)
    private val starP = FloatArray(16)

    private val rnd = Random(21)
    private var nextBolt = 2f
    private var boltT = 0f
    private var flashS = 0f

    init {
        contentDescription = "Esfera meteorológica. Desliza para girarla."
        for (i in 0 until 16) {
            val a = rnd.nextFloat() * 6.2831855f
            val rr = sqrt(rnd.nextFloat()) * 0.85f
            starX[i] = cos(a) * rr
            starY[i] = sin(a) * rr
            starP[i] = rnd.nextFloat() * 6f
        }
    }

    // ---------------------------------------------------------------- configuración

    /** [lv]: 1 ligera, 2 moderada, 3 intensa. */
    fun setWeather(k: WxKind, n: Boolean, lv: Int) {
        kind = k
        night = n
        level = lv
        configure()
        invalidate()
    }

    /** Impulso de giro (la entrada de la pantalla de detalle lo usa para «lanzar» la esfera). */
    fun kick(v: Float) {
        spin += v
    }

    private fun configure() {
        val g = Random(3)
        nc = 0
        fun cloud(lo: Float, la: Float, sz: Float, tint: Int) {
            if (nc >= nMax) return
            lon[nc] = lo; lat[nc] = la; csz[nc] = sz; ctint[nc] = tint
            nc++
        }
        when (kind) {
            WxKind.CLEAR -> {}
            WxKind.PARTLY -> {
                cloud(0.3f, 0.30f, 0.52f, 0); cloud(2.4f, -0.05f, 0.42f, 0); cloud(4.5f, 0.38f, 0.46f, 1)
            }
            WxKind.CLOUDY -> for (i in 0 until 6) {
                cloud(i * 1.05f, (if (i % 2 == 0) -0.30f else 0.18f) + (g.nextFloat() - 0.5f) * 0.2f, 0.48f + g.nextFloat() * 0.14f, if (i % 3 == 0) 0 else 1)
            }
            WxKind.FOG -> {
                cloud(0.5f, 0.0f, 0.55f, 0); cloud(2.6f, 0.25f, 0.5f, 0); cloud(4.7f, -0.2f, 0.52f, 1)
            }
            WxKind.RAIN -> for (i in 0 until 5) {
                cloud(i * 1.26f, -0.50f + (g.nextFloat() - 0.5f) * 0.22f, 0.54f + g.nextFloat() * 0.12f, 1)
            }
            WxKind.STORM -> for (i in 0 until 5) {
                cloud(i * 1.26f, -0.50f + (g.nextFloat() - 0.5f) * 0.22f, 0.56f + g.nextFloat() * 0.12f, 2)
            }
            WxKind.SNOW -> for (i in 0 until 4) {
                cloud(i * 1.6f, -0.52f + (g.nextFloat() - 0.5f) * 0.2f, 0.52f + g.nextFloat() * 0.1f, if (i % 2 == 0) 0 else 1)
            }
        }
        // partículas
        val f = if (quality >= 2) 1f else 0.55f
        np = when (kind) {
            WxKind.RAIN -> (intArrayOf(0, 22, 34, 48)[level.coerceIn(1, 3)] * f).toInt()
            WxKind.STORM -> (50 * f).toInt()
            WxKind.SNOW -> (intArrayOf(0, 20, 30, 42)[level.coerceIn(1, 3)] * f).toInt()
            else -> 0
        }.coerceAtMost(pMax)
        for (i in 0 until np) {
            ppx[i] = (g.nextFloat() * 2f - 1f) * 1.05f
            ppz[i] = g.nextFloat()
            if (kind == WxKind.SNOW) {
                ppy[i] = g.nextFloat() * 2.2f - 1.1f
                ppv[i] = 0.10f + g.nextFloat() * 0.18f
            } else {
                ppy[i] = -0.25f + g.nextFloat() * 1.4f
                ppv[i] = 0.9f + g.nextFloat() * 0.7f
            }
        }
        nextBolt = 1.2f + g.nextFloat() * 1.5f
        boltT = 0f
        flashS = 0f
    }

    // ---------------------------------------------------------------- tamaño

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        cx = w / 2f
        cy = h / 2f
        r = min(w, h) * 0.35f
        if (r <= 0f) return
        clip.reset()
        clip.addCircle(cx, cy, r, Path.Direction.CW)
        haloPaint.shader = RadialGradient(
            cx, cy, r * 1.62f,
            intArrayOf(0x66A06CFF, 0x66806CFF, 0x224F7CFF, 0x004F7CFF),
            floatArrayOf(0f, 0.62f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        val cols = arrayOf(
            intArrayOf(0xFF4C8DFF.toInt(), 0xFF2A4FE0.toInt(), 0xFF16206E.toInt()),   // CLEAR
            intArrayOf(0xFF3F6CF0.toInt(), 0xFF2B3BC4.toInt(), 0xFF161B68.toInt()),   // PARTLY
            intArrayOf(0xFF3A4FD0.toInt(), 0xFF2A2D9E.toInt(), 0xFF14134F.toInt()),   // CLOUDY
            intArrayOf(0xFF4B5BC4.toInt(), 0xFF343A9A.toInt(), 0xFF1A1A5A.toInt()),   // FOG
            intArrayOf(0xFF2E3FB8.toInt(), 0xFF211F86.toInt(), 0xFF0F0D44.toInt()),   // RAIN
            intArrayOf(0xFF3A2A9E.toInt(), 0xFF271A74.toInt(), 0xFF0C0830.toInt()),   // STORM
            intArrayOf(0xFF6C86E8.toInt(), 0xFF4458C8.toInt(), 0xFF212A78.toInt()),   // SNOW
            intArrayOf(0xFF2A2F9E.toInt(), 0xFF191A6A.toInt(), 0xFF0A0A3A.toInt())    // noche despejada
        )
        for (i in 0 until 8) {
            bodyPaints[i].shader = RadialGradient(
                cx - r * 0.3f, cy - r * 0.35f, r * 1.5f, cols[i], floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
        vignette.shader = RadialGradient(
            cx, cy, r,
            intArrayOf(0x00050A30, 0x00050A30, 0x66050A30, 0xB0050A30.toInt()),
            floatArrayOf(0f, 0.55f, 0.85f, 1f), Shader.TileMode.CLAMP
        )
        bottomGlow.shader = RadialGradient(
            cx, cy + r * 0.95f, r, intArrayOf(0x668B5CFF, 0x008B5CFF), null, Shader.TileMode.CLAMP
        )
        shade.shader = LinearGradient(
            0f, cy, 0f, cy + r * 0.9f, 0x00050A30, 0x77050A30, Shader.TileMode.CLAMP
        )
        warm.shader = RadialGradient(
            cx - r * 0.2f, cy - r * 0.25f, r * 1.3f, intArrayOf(0x70FFC857, 0x00FFC857), null, Shader.TileMode.CLAMP
        )
        gloss.shader = RadialGradient(
            cx - r * 0.38f, cy - r * 0.5f, r * 0.5f, intArrayOf(0x66FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP
        )
        val sw = SweepGradient(
            cx, cy,
            intArrayOf(0xFF6EA8FF.toInt(), 0xFFB388FF.toInt(), 0xFF4FD0FF.toInt(), 0xFFB388FF.toInt(), 0xFF6EA8FF.toInt()),
            null
        )
        rimShader = sw
        rim.shader = sw
        rimGlow.shader = sw
        rim.strokeWidth = 2f * d
        rimGlow.strokeWidth = 7f * d
        rimGlow.alpha = 70
        specArc.strokeWidth = 3f * d
        specArc.color = 0x88FFFFFF.toInt()
        ringGlow.strokeWidth = 4.5f * d
        ringCore.strokeWidth = 1.4f * d
        rainFar.strokeWidth = 1.1f * d
        rainNear.strokeWidth = 1.6f * d
        snowSmall.strokeWidth = 2.4f * d
        snowBig.strokeWidth = 4f * d
        boltGlow.strokeWidth = 7f * d
        boltCore.strokeWidth = 2.2f * d
    }

    // ---------------------------------------------------------------- animación

    fun tick(dt: Float) {
        t += dt
        if (!dragging) {
            yaw += spin * dt
            spin += (AUTO - spin) * min(1f, dt * 1.2f)
            tilt -= tilt * min(1f, dt * 3f)
        }
        yaw = (yaw % TWO_PI + TWO_PI) % TWO_PI
        stepParticles(dt)
        if (kind == WxKind.STORM) {
            nextBolt -= dt
            if (nextBolt <= 0f) {
                newBolt()
                nextBolt = 2.4f + rnd.nextFloat() * 3.6f
            }
        }
        if (boltT > 0f) boltT = maxOf(0f, boltT - dt)
        if (flashS > 0f) flashS = maxOf(0f, flashS - dt * 3.5f)
        invalidate()
    }

    private fun stepParticles(dt: Float) {
        if (np == 0) return
        if (kind == WxKind.SNOW) {
            for (i in 0 until np) {
                ppy[i] += ppv[i] * dt
                if (ppy[i] > 1.1f) {
                    ppy[i] = -1.1f
                    ppx[i] = (rnd.nextFloat() * 2f - 1f) * 1.05f
                }
            }
        } else {
            for (i in 0 until np) {
                ppy[i] += ppv[i] * dt
                if (ppy[i] > 1.15f) {
                    ppy[i] = -0.25f
                    ppx[i] = (rnd.nextFloat() * 2f - 1f) * 1.05f
                }
            }
        }
    }

    private fun newBolt() {
        var x = cx + (rnd.nextFloat() - 0.5f) * r * 0.9f
        var y = cy - r * 0.3f
        bolt.reset()
        bolt.moveTo(x, y)
        for (i in 0 until 6) {
            x += (rnd.nextFloat() - 0.5f) * r * 0.38f
            y += r * 0.2f
            bolt.lineTo(x, y)
        }
        boltT = 0.32f
        flashS = 1f
    }

    // ---------------------------------------------------------------- dibujo

    override fun onDraw(c: Canvas) {
        if (r <= 0f) return
        c.drawCircle(cx, cy, r * 1.62f, haloPaint)
        ring(c, r * 1.42f, r * 0.36f, -14f, false, 0xFF58B8FF.toInt(), 0.7f, 0f)
        ring(c, r * 1.28f, r * 0.52f, 24f, false, 0xFFB28CFF.toInt(), -0.45f, 2.4f)

        val bi = if (kind == WxKind.CLEAR && night) 7 else kind.ordinal
        c.save()
        c.clipPath(clip)
        c.drawCircle(cx, cy, r, bodyPaints[bi])
        drawContent(c)
        c.drawCircle(cx, cy, r, vignette)
        c.drawCircle(cx, cy, r, bottomGlow)
        c.drawCircle(cx, cy, r, shade)
        if (flashS > 0f) {
            flashPaint.alpha = (flashS * 105f).toInt()
            c.drawCircle(cx, cy, r, flashPaint)
        }
        c.drawCircle(cx, cy, r, gloss)
        c.restore()

        // borde de cristal: brillo + línea fina (el color gira con la esfera)
        rimShader?.let {
            rimMatrix.setRotate(Math.toDegrees(yaw.toDouble()).toFloat(), cx, cy)
            it.setLocalMatrix(rimMatrix)
        }
        c.drawCircle(cx, cy, r, rimGlow)
        c.drawCircle(cx, cy, r, rim)
        oval.set(cx - r * 0.9f, cy - r * 0.9f, cx + r * 0.9f, cy + r * 0.9f)
        c.drawArc(oval, 205f, 55f, false, specArc)

        ring(c, r * 1.42f, r * 0.36f, -14f, true, 0xFF58B8FF.toInt(), 0.7f, 0f)
        ring(c, r * 1.28f, r * 0.52f, 24f, true, 0xFFB28CFF.toInt(), -0.45f, 2.4f)
    }

    /** Anillo orbital: [front] = mitad que pasa por delante de la esfera. Lleva un satélite luminoso. */
    private fun ring(c: Canvas, a: Float, b: Float, rot: Float, front: Boolean, color: Int, speed: Float, phase: Float) {
        c.save()
        c.rotate(rot, cx, cy)
        oval.set(cx - a, cy - b, cx + a, cy + b)
        val start = if (front) 0f else 180f
        ringGlow.color = color
        ringGlow.alpha = 46
        c.drawArc(oval, start, 180f, false, ringGlow)
        ringCore.color = color
        ringCore.alpha = if (front) 235 else 120
        c.drawArc(oval, start, 180f, false, ringCore)
        if (quality >= 1) {
            val th = t * speed + phase
            val sy = sin(th)
            if ((sy > 0f) == front) {
                val x = cx + a * cos(th)
                val y = cy + b * sy
                dot.color = color
                dot.alpha = 70
                c.drawCircle(x, y, 7f * d, dot)
                dot.alpha = 255
                c.drawCircle(x, y, 2.8f * d, dot)
            }
        }
        c.restore()
    }

    private fun drawContent(c: Canvas) {
        when (kind) {
            WxKind.CLEAR -> if (night) {
                drawStars(c)
                WxArt.moon(c, cx - r * 0.15f, cy - r * 0.2f, r * 0.34f)
            } else {
                c.drawCircle(cx, cy, r, warm)
                WxArt.sun(c, cx - r * 0.2f + sin(t * 0.5f) * r * 0.03f, cy - r * 0.25f, r * 0.30f, true, t * 10f)
            }
            WxKind.PARTLY -> {
                if (night) {
                    drawStars(c)
                    WxArt.moon(c, cx - r * 0.3f, cy - r * 0.3f, r * 0.26f)
                } else {
                    c.drawCircle(cx, cy, r, warm)
                    WxArt.sun(c, cx - r * 0.3f, cy - r * 0.3f, r * 0.24f, true, t * 10f)
                }
                drawClouds(c)
            }
            WxKind.CLOUDY -> drawClouds(c)
            WxKind.FOG -> {
                drawClouds(c)
                for (i in 0 until 4) {
                    val y = cy + r * (-0.5f + 0.34f * i) + sin(t * 0.5f + i) * r * 0.04f
                    val off = sin(t * 0.25f + i * 1.7f) * r * 0.25f
                    box.set(cx - r * 1.2f + off, y, cx + r * 1.2f + off, y + r * 0.15f)
                    fogPaint.alpha = 52 + 22 * (i % 2)
                    c.drawRoundRect(box, r * 0.075f, r * 0.075f, fogPaint)
                }
            }
            WxKind.RAIN -> {
                drawRain(c)
                drawClouds(c)
            }
            WxKind.STORM -> {
                drawRain(c)
                drawClouds(c)
                if (boltT > 0f) {
                    val k = if (((boltT * 22f).toInt() and 1) == 0) 1f else 0.55f
                    boltGlow.alpha = (130 * k).toInt()
                    boltCore.alpha = (255 * k).toInt()
                    c.drawPath(bolt, boltGlow)
                    c.drawPath(bolt, boltCore)
                }
            }
            WxKind.SNOW -> {
                drawSnow(c)
                drawClouds(c)
            }
        }
    }

    private fun drawStars(c: Canvas) {
        for (i in 0 until 16) {
            val a = 0.35f + 0.65f * (0.5f + 0.5f * sin(t * 1.8f + starP[i]))
            starPaint.alpha = (a * 255f).toInt()
            c.drawCircle(cx + starX[i] * r, cy + starY[i] * r, (1f + (i % 3) * 0.5f) * d, starPaint)
        }
    }

    private fun drawClouds(c: Canvas) {
        val cl = clouds
        for (i in 0 until nc) {
            val a = lon[i] + yaw
            val dep = cos(a)
            if (dep < 0.05f) continue
            val s = sin(a)
            val lv = lat[i]
            val x = cx + r * sqrt(1f - lv * lv) * s * 0.95f
            val y = cy + r * lv * 0.9f + tilt * r * 0.35f * dep
            val sz = r * csz[i]
            val sx = sz * (0.3f + 0.7f * dep)
            val sy = sz * (0.78f + 0.22f * dep)
            val left = x - WxArt.BMP_OX * sx
            val top = y - WxArt.BMP_OY * sy
            box.set(left, top, left + WxArt.BMP_UW * sx, top + WxArt.BMP_UH * sy)
            bmpPaint.alpha = (255f * min(1f, dep * 1.8f)).toInt()
            c.save()
            c.rotate(s * 9f, x, y)
            c.drawBitmap(cl[ctint[i]], null, box, bmpPaint)
            c.restore()
        }
    }

    private fun drawRain(c: Canvas) {
        var nf = 0
        var nn = 0
        val slant = r * 0.045f
        for (i in 0 until np) {
            val x = cx + ppx[i] * r
            val y = cy + ppy[i] * r
            val near = ppz[i] > 0.5f
            val len = r * (if (near) 0.17f else 0.11f)
            if (near) {
                nearBuf[nn++] = x; nearBuf[nn++] = y
                nearBuf[nn++] = x - slant; nearBuf[nn++] = y + len
            } else {
                farBuf[nf++] = x; farBuf[nf++] = y
                farBuf[nf++] = x - slant * 0.7f; farBuf[nf++] = y + len
            }
        }
        rainFar.alpha = 120
        rainNear.alpha = 205
        if (nf > 0) c.drawLines(farBuf, 0, nf, rainFar)
        if (nn > 0) c.drawLines(nearBuf, 0, nn, rainNear)
    }

    private fun drawSnow(c: Canvas) {
        var n1 = 0
        var n2 = 0
        for (i in 0 until np) {
            val x = cx + (ppx[i] + sin(t * 1.3f + ppz[i] * 9f) * 0.05f) * r
            val y = cy + ppy[i] * r
            if (ppz[i] > 0.55f) {
                pts2[n2++] = x; pts2[n2++] = y
            } else {
                pts1[n1++] = x; pts1[n1++] = y
            }
        }
        snowSmall.alpha = 170
        snowBig.alpha = 235
        if (n1 > 0) c.drawPoints(pts1, 0, n1, snowSmall)
        if (n2 > 0) c.drawPoints(pts2, 0, n2, snowBig)
    }

    // ---------------------------------------------------------------- gestos

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // La esfera se gira con el dedo: que ni el deslizador de pantallas ni la lista le roben el gesto.
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                spin = 0f
                dragVel = 0f
                lastX = e.x
                lastY = e.y
                lastMs = e.eventTime
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return true
                val dx = e.x - lastX
                val dy = e.y - lastY
                val dtS = ((e.eventTime - lastMs).coerceAtLeast(1L)) / 1000f
                lastX = e.x
                lastY = e.y
                lastMs = e.eventTime
                val dyaw = dx / (r * 0.9f)
                yaw = (yaw + dyaw + TWO_PI) % TWO_PI
                tilt = (tilt + dy / (r * 1.5f)).coerceIn(-0.5f, 0.5f)
                dragVel = dragVel * 0.6f + (dyaw / dtS) * 0.4f
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                spin = if (quality >= 1) dragVel.coerceIn(-6f, 6f) else 0f
                parent?.requestDisallowInterceptTouchEvent(false)
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private companion object {
        const val AUTO = 0.10f
        const val TWO_PI = 6.2831855f
    }
}
