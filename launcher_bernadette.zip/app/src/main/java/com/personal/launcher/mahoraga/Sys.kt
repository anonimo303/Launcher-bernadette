package com.personal.launcher.mahoraga

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager
import java.io.File

/** Una lectura real del dispositivo. Los valores no disponibles se marcan con -1 / NaN, nunca se inventan. */
class Sample(
    val ramTotalMb: Int, val ramAvailMb: Int, val lowMem: Boolean,
    val swapTotalMb: Int, val swapFreeMb: Int,
    val battPct: Int, val battTemp: Float, val battMv: Int, val charging: Boolean,
    val thermal: Int, val cpuPct: Int, val freqMhz: Int, val zoneTemp: Float,
    val fps: Int = -1, val skinTemp: Float = Float.NaN
) {
    val ramUsedPct: Int get() = if (ramTotalMb > 0) (ramTotalMb - ramAvailMb) * 100 / ramTotalMb else -1
}

object Sys {
    private var lastTotal = 0L
    private var lastIdle = 0L
    private var hasPrev = false
    private var cpuOk = true
    private var zones: List<File>? = null
    private var freqs: List<File>? = null

    fun sample(c: Context): Sample {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val sw = swap()
        var pct = -1; var temp = Float.NaN; var mv = 0; var chg = false
        val b: Intent? = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val l = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val s = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (l >= 0 && s > 0) pct = l * 100 / s
            val t = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            if (t != Int.MIN_VALUE) temp = t / 10f
            mv = b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
            chg = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        }
        val th = try { (c.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus } catch (e: Exception) { -1 }
        return Sample(
            (mi.totalMem / 1048576L).toInt(), (mi.availMem / 1048576L).toInt(), mi.lowMemory,
            sw.first, sw.second, pct, temp, mv, chg, th,
            cpu().let { if (it >= 0) it else Shz.cpuFresh() }, freq(), zoneTemp(),
            Shz.fpsFresh(), Shz.skinFresh()
        )
    }

    private fun swap(): Pair<Int, Int> {
        return try {
            var total = -1; var free = -1
            File("/proc/meminfo").bufferedReader().useLines { lines ->
                for (ln in lines) {
                    if (ln.startsWith("SwapTotal:")) total = (ln.filter { it.isDigit() }.toLong() / 1024).toInt()
                    else if (ln.startsWith("SwapFree:")) free = (ln.filter { it.isDigit() }.toLong() / 1024).toInt()
                }
            }
            Pair(total, free)
        } catch (e: Exception) { Pair(-1, -1) }
    }

    /** Carga de CPU global desde /proc/stat. Android 8+ suele bloquear esta lectura: entonces devuelve -1. */
    private fun cpu(): Int {
        if (!cpuOk) return -1
        val line: String? = try { File("/proc/stat").bufferedReader().use { it.readLine() } } catch (e: Exception) { null }
        if (line == null || !line.startsWith("cpu ")) { cpuOk = false; return -1 }
        val p = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (p.size < 5) { cpuOk = false; return -1 }
        val idle = p[3] + p[4]
        val total = p.sum()
        val dT = total - lastTotal
        val dI = idle - lastIdle
        val had = hasPrev
        lastTotal = total; lastIdle = idle; hasPrev = true
        if (!had || dT <= 0) return -1
        return ((dT - dI) * 100 / dT).toInt().coerceIn(0, 100)
    }

    private fun freq(): Int {
        if (freqs == null) {
            val l = ArrayList<File>()
            for (i in 0 until 8) {
                val f = File("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq")
                try { f.readText(); l.add(f) } catch (e: Exception) { }
            }
            freqs = l
        }
        var max = -1
        for (f in freqs!!) {
            val v = try { f.readText().trim().toInt() / 1000 } catch (e: Exception) { continue }
            if (v > max) max = v
        }
        return max
    }

    private fun zoneTemp(): Float {
        if (zones == null) {
            val l = ArrayList<File>()
            for (i in 0 until 40) {
                val f = File("/sys/class/thermal/thermal_zone$i/temp")
                try { f.readText(); l.add(f) } catch (e: Exception) { }
            }
            zones = l
        }
        var max = Float.NaN
        for (f in zones!!) {
            val v = try { f.readText().trim().toFloat() } catch (e: Exception) { continue }
            val t = if (v > 1000f) v / 1000f else v
            if (t in 15f..110f && (max.isNaN() || t > max)) max = t
        }
        return max
    }

    fun cpuAvailable(): Boolean = cpuOk

    /** RAM libre (MB) sin tocar el estado de las demás lecturas; seguro desde otros hilos. */
    fun ramAvailMb(c: Context): Int {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        return (mi.availMem / 1048576L).toInt()
    }
}
