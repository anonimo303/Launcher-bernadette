package com.personal.launcher.mahoraga

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import com.personal.launcher.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Actividad transparente: solo muestra el diálogo oficial de Android para autorizar la grabación. */
class RecordPermActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), 77)
        } catch (e: Exception) { finish() }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK && data != null) {
            try {
                startForegroundService(
                    Intent(this, RecorderService::class.java).setAction("start")
                        .putExtra("code", resultCode).putExtra("data", data)
                )
            } catch (e: Exception) {
                Toast.makeText(this, "No se pudo iniciar la grabación", Toast.LENGTH_SHORT).show()
            }
        }
        finish()
        overridePendingTransition(0, 0)
    }
}

/** Grabación de pantalla ligera: 720p máx., 30 fps, ~4 Mbps, sin audio. Se guarda en Películas/MAHORAGA. */
class RecorderService : Service() {
    companion object {
        @Volatile var recording = false
        private const val CH = "mh_rec"
        private const val NID = 7002

        fun stop(c: Context) {
            try { c.startService(Intent(c, RecorderService::class.java).setAction("stop")) } catch (e: Exception) { }
        }
    }

    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var uri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "stop") { finishRec(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Grabación de pantalla", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 1, Intent(this, RecorderService::class.java).setAction("stop"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.mh_ic_rec)
            .setContentTitle("MAHORAGA está grabando la pantalla")
            .setContentText("Toca para detener")
            .setOngoing(true)
            .setContentIntent(stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NID, n)

        val code = i?.getIntExtra("code", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data: Intent? = i?.getParcelableExtra("data")
        if (data == null || code != Activity.RESULT_OK || !begin(code, data)) {
            finishRec()
        }
        return START_NOT_STICKY
    }

    private fun begin(code: Int, data: Intent): Boolean {
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data)
            projection = mp
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { Handler(Looper.getMainLooper()).post { finishRec() } }
            }, Handler(Looper.getMainLooper()))

            val dm = resources.displayMetrics
            var w = dm.widthPixels
            var h = dm.heightPixels
            val shortSide = minOf(w, h)
            if (shortSide > 720) {
                val f = 720f / shortSide
                w = (w * f).toInt(); h = (h * f).toInt()
            }
            w = w and 1.inv(); h = h and 1.inv()

            val name = "MAHORAGA_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
            val cv = ContentValues()
            cv.put(MediaStore.Video.Media.DISPLAY_NAME, name)
            cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MAHORAGA")
            cv.put(MediaStore.Video.Media.IS_PENDING, 1)
            val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
            uri = u
            val fd = contentResolver.openFileDescriptor(u, "w") ?: return false
            pfd = fd

            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            r.setVideoSize(w, h)
            r.setVideoFrameRate(30)
            r.setVideoEncodingBitRate(4_000_000)
            r.setOutputFile(fd.fileDescriptor)
            r.prepare()
            recorder = r
            display = mp.createVirtualDisplay("mahoraga_rec", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            r.start()
            recording = true
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun finishRec() {
        val was = recording
        recording = false
        try { recorder?.stop() } catch (e: Exception) { }
        try { recorder?.release() } catch (e: Exception) { }
        recorder = null
        try { display?.release() } catch (e: Exception) { }
        display = null
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        try { pfd?.close() } catch (e: Exception) { }
        pfd = null
        uri?.let {
            try {
                if (was) {
                    val cv = ContentValues()
                    cv.put(MediaStore.Video.Media.IS_PENDING, 0)
                    contentResolver.update(it, cv, null, null)
                } else contentResolver.delete(it, null, null)   // no empezó a grabar: no deja un vídeo vacío
            } catch (e: Exception) { }
        }
        uri = null
        if (was) Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, "Grabación guardada en Películas/MAHORAGA", Toast.LENGTH_LONG).show()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { recording = false; super.onDestroy() }
}
