package com.personal.launcher

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Registro corto de lo que hace la escucha de Bernadette, para ver en los ajustes qué falla. */
object Diag {
    private val lines = ArrayList<String>()
    private var loaded = false
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun log(c: Context, s: String) {
        load(c)
        lines.add(fmt.format(Date()) + "  " + s)
        while (lines.size > 70) lines.removeAt(0)
        Prefs.setStr(c, "bern_diag", lines.joinToString("\n"))
    }

    @Synchronized
    fun text(c: Context): String {
        load(c)
        return if (lines.isEmpty()) "Todavía no hay registros. Activa «Escuchar» y vuelve a abrir esta pantalla."
        else lines.joinToString("\n")
    }

    @Synchronized
    fun clear(c: Context) {
        lines.clear()
        loaded = true
        Prefs.setStr(c, "bern_diag", null)
    }

    private fun load(c: Context) {
        if (loaded) return
        loaded = true
        Prefs.str(c, "bern_diag")?.split("\n")?.filter { it.isNotBlank() }?.let { lines.addAll(it) }
    }

    fun err(e: Int): String = when (e) {
        1 -> "RED_TIEMPO(1)"
        2 -> "RED(2)"
        3 -> "AUDIO(3)"
        4 -> "SERVIDOR(4)"
        5 -> "CLIENTE(5)"
        6 -> "SIN_VOZ(6)"
        7 -> "SIN_COINCIDENCIA(7)"
        8 -> "OCUPADO(8)"
        9 -> "PERMISOS(9)"
        10 -> "DEMASIADAS_PETICIONES(10)"
        11 -> "SERVIDOR_DESCONECTADO(11)"
        12 -> "IDIOMA_NO_SOPORTADO(12)"
        13 -> "IDIOMA_NO_DISPONIBLE(13)"
        else -> "DESCONOCIDO($e)"
    }
}
