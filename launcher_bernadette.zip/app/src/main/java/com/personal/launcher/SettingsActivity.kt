package com.personal.launcher

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

@Suppress("DEPRECATION")
class SettingsActivity : Activity() {

    private lateinit var page: String
    private lateinit var body: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var infoBtn: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        page = intent.getStringExtra("page") ?: "main"
        // Igual que el launcher: con las barras ocultas aquí también se ocultan y no queda hueco
        val hideStatus = Prefs.bool(this, "hide_status", false)
        val hideNav = Prefs.bool(this, "hide_nav", false)
        var ui = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        if (!hideNav) ui = ui or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        if (hideStatus) ui = ui or View.SYSTEM_UI_FLAG_FULLSCREEN
        if (hideNav) ui = ui or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        window.decorView.systemUiVisibility = ui

        val root = FrameLayout(this)

        // Fondo oficial (imagen original, sin recrearlo con colores)
        val bg = ImageView(this)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        bg.setImageResource(R.drawable.fondo_config)
        root.addView(bg, FrameLayout.LayoutParams(MATCH, MATCH))

        val sbId = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (sbId > 0) resources.getDimensionPixelSize(sbId) else Ui.dp(this, 24)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, sb, 0, 0)

        // Cabecera
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12))
        val back = ImageView(this)
        back.setImageResource(R.drawable.ic_back)
        back.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10))
        back.background = Ui.glass(this, 22)
        back.setOnClickListener { finish() }
        val blp = LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44))
        blp.rightMargin = Ui.dp(this, 16)
        header.addView(back, blp)
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        titleView = TextView(this)
        titleView.setTextColor(Ui.TEXT)
        titleView.textSize = 24f
        titleView.typeface = Typeface.DEFAULT_BOLD
        tc.addView(titleView)
        val sub = TextView(this)
        sub.text = "VERDANT Launcher"
        sub.setTextColor(Ui.SUB)
        sub.textSize = 14f
        tc.addView(sub)
        header.addView(tc, LinearLayout.LayoutParams(0, WRAP, 1f))
        infoBtn = ImageView(this)
        infoBtn.setImageResource(R.drawable.ic_s_info)
        infoBtn.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 10))
        infoBtn.background = Ui.glass(this, 22)
        infoBtn.setOnClickListener { open("info") }
        header.addView(infoBtn, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)))
        col.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        // Contenido desplazable
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 28))
        scroll.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    // ---------------------------------------------------------------- constructores de UI

    private fun toast(s: String) {
        Prefs.say(this, s)
    }

    private fun startSafe(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("No se pudo abrir")
        }
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        c.background = Ui.glass(this, 22)
        c.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = Ui.dp(this, 10)
        c.layoutParams = lp
        return c
    }

    private fun iconView(res: Int, sizeDp: Int = 28): ImageView {
        val iv = ImageView(this)
        iv.setImageResource(res)
        val lp = LinearLayout.LayoutParams(Ui.dp(this, sizeDp), Ui.dp(this, sizeDp))
        lp.rightMargin = Ui.dp(this, 14)
        iv.layoutParams = lp
        return iv
    }

    private fun texts(title: String, sub: String?): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        val t = TextView(this)
        t.text = title
        t.setTextColor(Ui.TEXT)
        t.textSize = 17f
        t.typeface = Typeface.DEFAULT_BOLD
        col.addView(t)
        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.setTextColor(Ui.SUB)
            s.textSize = 13f
            col.addView(s)
        }
        return col
    }

    private fun addRow(icon: Int, title: String, sub: String?, onClick: () -> Unit) {
        val c = card()
        if (icon != 0) c.addView(iconView(icon))
        c.addView(texts(title, sub))
        val ch = iconView(R.drawable.ic_chevron, 22)
        (ch.layoutParams as LinearLayout.LayoutParams).rightMargin = 0
        c.addView(ch)
        c.setOnClickListener { onClick() }
        body.addView(c)
    }

    private fun addSwitch(title: String, sub: String?, key: String, def: Boolean) {
        val c = card()
        c.addView(texts(title, sub))
        val sw = Switch(this)
        sw.isChecked = Prefs.bool(this, key, def)
        sw.setOnCheckedChangeListener { _, on -> Prefs.setBool(this, key, on) }
        c.addView(sw)
        c.setOnClickListener { sw.toggle() }
        body.addView(c)
    }

    private fun pill(selected: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = Ui.dp(this, 20).toFloat()
        g.setColor(if (selected) Ui.ACCENT else Color.parseColor("#33000000"))
        g.setStroke(Ui.dp(this, 1) + 1, Color.parseColor("#8C34F0A0"))
        return g
    }

    private fun addChoice(title: String, key: String, def: Int, labels: List<String>, values: List<Int>) {
        val c = card()
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.START
        val t = TextView(this)
        t.text = title
        t.setTextColor(Ui.TEXT)
        t.textSize = 17f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(0, 0, 0, Ui.dp(this, 10))
        c.addView(t)
        val rowL = LinearLayout(this)
        rowL.orientation = LinearLayout.HORIZONTAL
        val cur = Prefs.int(this, key, def)
        for (i in labels.indices) {
            val p = TextView(this)
            p.text = labels[i]
            p.textSize = 14f
            p.gravity = Gravity.CENTER
            val sel = values[i] == cur
            p.setTextColor(if (sel) Color.parseColor("#02140B") else Ui.TEXT)
            p.background = pill(sel)
            p.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 8))
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.rightMargin = Ui.dp(this, 8)
            p.setOnClickListener {
                Prefs.setInt(this, key, values[i])
                build()
            }
            rowL.addView(p, lp)
        }
        c.addView(rowL)
        body.addView(c)
    }

    private fun addInfo(text: String) {
        val c = card()
        val t = TextView(this)
        t.text = text
        t.setTextColor(Ui.SUB)
        t.textSize = 14f
        c.addView(t)
        body.addView(c)
    }

    private fun addSection(text: String) {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Ui.ACCENT)
        t.textSize = 14f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(Ui.dp(this, 4), Ui.dp(this, 10), 0, Ui.dp(this, 8))
        body.addView(t)
    }

    private fun open(p: String) {
        val i = Intent(this, SettingsActivity::class.java)
        i.putExtra("page", p)
        startActivity(i)
    }

    // ---------------------------------------------------------------- páginas

    private fun build() {
        body.removeAllViews()
        infoBtn.visibility = if (page == "main") View.VISIBLE else View.GONE
        when (page) {
            "look" -> buildLook()
            "default" -> buildDefault()
            "home" -> buildHome()
            "drawer" -> buildDrawer()
            "gestures" -> buildGestures()
            "anim" -> buildAnim()
            "nav" -> buildNav()
            "iconpacks" -> buildIconPacks()
            "notif" -> buildNotif()
            "perf" -> buildPerf()
            "immersive" -> buildImmersive()
            "info" -> buildInfo()
            else -> buildMain()
        }
    }

    private fun buildMain() {
        titleView.text = "Configuración"

        val hero = card()
        hero.setPadding(Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo_hero)
        val llp = LinearLayout.LayoutParams(Ui.dp(this, 72), Ui.dp(this, 72))
        llp.rightMargin = Ui.dp(this, 16)
        hero.addView(logo, llp)
        val div = View(this)
        div.setBackgroundColor(Color.parseColor("#6634F0A0"))
        val dlp = LinearLayout.LayoutParams(Ui.dp(this, 1), Ui.dp(this, 56))
        dlp.rightMargin = Ui.dp(this, 16)
        hero.addView(div, dlp)
        hero.addView(texts("Personaliza tu launcher", "Haz que tu pantalla sea única"))
        body.addView(hero)

        addRow(R.drawable.ic_palette, "Apariencia", "Atenuado y fondo de pantalla") { open("look") }
        addRow(R.drawable.ic_sparkle, "Animaciones", "Estilos y velocidad de animaciones") { open("anim") }
        addRow(R.drawable.ic_s_iconpacks, "Icon Packs", "Cambia los iconos de tus apps") { open("iconpacks") }
        addRow(R.drawable.ic_s_home, "Pantalla principal", "Diseño y organización") { open("home") }
        addRow(R.drawable.ic_s_dots, "Cajón de aplicaciones", "Cuadrícula, buscador y más") { open("drawer") }
        addRow(R.drawable.ic_s_hand, "Gestos", "Personaliza tus gestos") { open("gestures") }
        addRow(R.drawable.ic_fullscreen, "Pantalla completa e inmersión", "Oculta las barras del sistema") { open("immersive") }
        addRow(R.drawable.ic_s_bell, "Notificaciones", "Mensajes y duración") { open("notif") }
        addRow(R.drawable.ic_s_gauge, "Rendimiento", "Optimiza el launcher") { open("perf") }
        addRow(R.drawable.ic_s_info, "Información", "Versión y detalles") { open("info") }

        // Divisor inferior (línea · rombo · línea)
        val div2 = LinearLayout(this)
        div2.gravity = Gravity.CENTER
        div2.setPadding(0, Ui.dp(this, 14), 0, 0)
        fun line(): View {
            val v = View(this)
            v.setBackgroundColor(Color.parseColor("#8034F0A0"))
            return v
        }
        div2.addView(line(), LinearLayout.LayoutParams(0, Ui.dp(this, 1), 1f))
        val dia = View(this)
        dia.rotation = 45f
        val dg = GradientDrawable()
        dg.setColor(Color.TRANSPARENT)
        dg.setStroke(Ui.dp(this, 2), Ui.ACCENT)
        dia.background = dg
        val dlp2 = LinearLayout.LayoutParams(Ui.dp(this, 12), Ui.dp(this, 12))
        dlp2.leftMargin = Ui.dp(this, 14)
        dlp2.rightMargin = Ui.dp(this, 14)
        div2.addView(dia, dlp2)
        div2.addView(line(), LinearLayout.LayoutParams(0, Ui.dp(this, 1), 1f))
        body.addView(div2, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun buildLook() {
        titleView.text = "Apariencia"
        addChoice("Atenuar fondo de pantalla", "dim", 0, listOf("Sin atenuar", "Suave", "Fuerte"), listOf(0, 1, 2))
        addRow(R.drawable.ic_palette, "Cambiar fondo de pantalla", "Abre el selector de Android", {
            startSafe(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Fondo de pantalla"))
        })
    }

    private fun buildHome() {
        titleView.text = "Pantalla principal"
        addChoice("Tamaño de iconos", "icon_size", 1, listOf("Pequeño", "Medio", "Grande"), listOf(0, 1, 2))
        addSwitch("Mostrar nombres de apps", null, "labels", true)
        addRow(R.drawable.ic_default, "Colocar engranaje en la pantalla", "Vuelve a poner el acceso a configuración", {
            if (HomeStore.addGear(this)) toast("Engranaje colocado") else toast("El engranaje ya está en la pantalla")
        })
        addRow(R.drawable.ic_home, "Restablecer pantalla principal", "Quita todos los iconos y deja solo el engranaje", {
            Ui.menu(this, "¿Restablecer pantalla principal?", listOf("Restablecer", "Cancelar")) { i ->
                if (i == 0) {
                    HomeStore.reset(this)
                    toast("Pantalla principal restablecida")
                }
            }
        })
        addInfo("Mantén presionado un icono para moverlo; arrástralo a la zona roja superior para quitarlo.")
    }

    private fun buildDrawer() {
        titleView.text = "Cajón de aplicaciones"
        addChoice("Columnas", "drawer_cols", 4, listOf("4", "5", "6"), listOf(4, 5, 6))
        addSwitch("Mostrar buscador", null, "drawer_search", true)
        addInfo("Mantén presionada una app del cajón para añadirla a la pantalla principal, ver su información o desinstalarla.")
    }

    private fun buildGestures() {
        titleView.text = "Gestos"
        addRow(R.drawable.ic_nav, "Navegación", "Pantallas, orden y barra animada") { open("nav") }
        addSwitch("Gestos de deslizamiento", "Deslizar en horizontal entre pantallas", "nav_swipe", false)
        addSwitch("Deslizar hacia arriba abre el cajón", "En la pantalla principal", "swipe_up", true)
        addRow(R.drawable.ic_s_hand, "Doble toque para abrir una aplicación", "Elige qué app se abre al tocar dos veces una zona vacía de Inicio") { chooseDoubleTapApp() }
        val selected = Prefs.str(this, "double_tap_app")
        if (!selected.isNullOrBlank()) {
            val name = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(selected, 0)).toString() } catch (_: Exception) { selected }
            addInfo("Aplicación asignada al doble toque: $name")
            addRow(R.drawable.ic_s_hand, "Quitar acción de doble toque", "Desactiva la apertura automática") {
                Prefs.setStr(this, "double_tap_app", null); build()
            }
        }
        addInfo("El doble toque se reconoce en una zona vacía de la pantalla principal para no interferir con los iconos. Mantener presionado sigue abriendo el menú del launcher.")
    }

    private fun chooseDoubleTapApp() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        val labels = apps.map { it.loadLabel(packageManager).toString() }.toMutableList()
        val pkgs = apps.map { it.activityInfo.packageName }
        labels.add(0, "Ninguna aplicación")
        AlertDialog.Builder(this)
            .setTitle("Aplicación para doble toque")
            .setItems(labels.toTypedArray()) { _, which ->
                Prefs.setStr(this, "double_tap_app", if (which == 0) null else pkgs[which - 1])
                build()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun buildAnim() {
        titleView.text = "Animaciones"
        addSection("Barra de navegación")
        addChoice("Estilo", "nav_style", NavConfig.STYLE_ARC, listOf("Arco", "Haz", "Burbuja"), listOf(0, 1, 2))
        addNavPreview()
        addChoice("Velocidad de animaciones", "anim_speed", 1, listOf("Rápida", "Normal", "Lenta"), listOf(0, 1, 2))
        addSection("Otras animaciones")
        addSwitch("Animación al abrir apps", null, "anim_apps", true)
        addSwitch("Animación del cajón", null, "anim_drawer", true)
        addInfo("Desactivarlas reduce el uso de GPU en equipos modestos.")
    }


    /** Vista previa REAL de la barra con el estilo elegido; se puede tocar para probarla. */
    private fun addNavPreview() {
        val c = card()
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.START
        val t = TextView(this)
        t.text = "Vista previa · toca las pestañas para probar"
        t.setTextColor(Ui.SUB)
        t.textSize = 13f
        t.setPadding(0, 0, 0, Ui.dp(this, 8))
        c.addView(t)
        val bar = NavBar(this)
        val real = NavConfig.barPages(this)
        bar.setPages(if (real.size >= 2) real else PageId.values().toList())
        bar.navStyle = NavConfig.style(this)
        bar.onSelect = { i -> bar.animateTo(i.toFloat(), 1f, 300L) }
        c.addView(bar, LinearLayout.LayoutParams(MATCH, Ui.dp(this, 86)))
        body.addView(c)
    }

    private fun arrowButton(label: String, enabled: Boolean, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = label
        b.setTextColor(Ui.TEXT)
        b.textSize = 15f
        b.gravity = Gravity.CENTER
        b.background = Ui.glass(this, 18)
        b.alpha = if (enabled) 1f else 0.3f
        if (enabled) b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(Ui.dp(this, 38), Ui.dp(this, 38))
        lp.leftMargin = Ui.dp(this, 8)
        b.layoutParams = lp
        return b
    }

    private fun addPageRow(p: PageId, index: Int, count: Int) {
        val c = card()
        c.addView(iconView(p.icon))
        c.addView(texts(p.label, if (p == PageId.HOME) "Siempre visible" else null))
        c.addView(arrowButton("▲", index > 0) {
            NavConfig.move(this, p, -1)
            build()
        })
        c.addView(arrowButton("▼", index < count - 1) {
            NavConfig.move(this, p, 1)
            build()
        })
        val sw = Switch(this)
        sw.isChecked = NavConfig.enabled(this, p)
        sw.isEnabled = p != PageId.HOME
        sw.setOnCheckedChangeListener { _, on -> Prefs.setBool(this, "nav_on_" + p.key, on) }
        val slp = LinearLayout.LayoutParams(WRAP, WRAP)
        slp.leftMargin = Ui.dp(this, 10)
        c.addView(sw, slp)
        body.addView(c)
    }

    private fun buildNav() {
        titleView.text = "Navegación"
        addSwitch(
            "Gestos de deslizamiento",
            "Desliza en horizontal entre las pantallas",
            "nav_swipe", false
        )
        addInfo(
            "Desactivado: la barra animada muestra todas las pantallas, incluido el cajón de aplicaciones, y se navega tocando.\n\n" +
                "Activado: se navega deslizando; el indicador de la barra sigue el gesto y el acceso al cajón se oculta de la barra porque las aplicaciones se abren deslizando."
        )
        addSection("Pantallas y orden")
        val order = NavConfig.order(this)
        for ((i, p) in order.withIndex()) addPageRow(p, i, order.size)
        addInfo("Usa ▲ ▼ para cambiar el orden y el interruptor para ocultar una pantalla. Los tres estilos de barra usan esta misma configuración.")
    }


    private fun buildIconPacks() {
        titleView.text = "Icon Packs"
        val cur = Prefs.str(this, "icon_pack")
        fun choice(title: String, sub: String, pkg: String?) {
            val c = card()
            c.addView(texts(title, sub))
            val mark = TextView(this)
            mark.text = if (cur == pkg) "✓" else ""
            mark.setTextColor(Ui.ACCENT)
            mark.textSize = 20f
            c.addView(mark)
            c.setOnClickListener {
                Prefs.setStr(this, "icon_pack", pkg)
                toast("Iconos aplicados")
                build()
            }
            body.addView(c)
        }
        choice("Iconos originales", "Los iconos que trae cada app", null)
        val packs = IconPacks.installed(this)
        if (packs.isEmpty()) {
            addInfo("No hay icon packs instalados. Instala uno compatible con ADW, Nova o Apex desde tu tienda de apps y aparecerá aquí.")
        } else {
            addSection("Instalados")
            for ((pkg, label) in packs) choice(label, pkg, pkg)
        }
        if (cur != null && IconPacks.installed(this).none { it.first == cur }) {
            addInfo("El icon pack elegido ya no está instalado; se usan los iconos originales.")
        }
        addInfo("Las apps que el pack no cubre conservan su icono original.")
    }

    private fun buildNotif() {
        titleView.text = "Notificaciones"
        val listener = (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "")
            .contains(packageName)
        val overlay = NotifOverlay.canDraw(this)
        addSwitch("Notificaciones animadas", "El logo de la app gira y aparece el nombre del mensaje", "notif_on", true)
        addRow(R.drawable.ic_s_bell, "Acceso a notificaciones",
            if (listener) "Activado ✓" else "Falta activar: permite que VERDANT lea las notificaciones") {
            startSafe(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        addRow(R.drawable.ic_s_bell, "Mostrar sobre otras apps",
            if (overlay) "Activado ✓" else "Falta activar: necesario para verlas en TikTok, juegos, etc.") {
            startSafe(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        addSwitch("Tapar las del sistema", "Descarta la notificación original para ver solo la del launcher", "notif_hide", true)
        addSwitch("Mostrar el texto del mensaje", "Si lo apagas, solo se muestra el nombre", "notif_preview", true)
        addSwitch("Mensajes del launcher", "Avisos breves como «Añadido a la pantalla principal»", "msg_on", true)
        addChoice("Duración", "msg_dur", 0, listOf("Corta", "Larga"), listOf(0, 1))
        addRow(R.drawable.ic_s_bell, "Probar animación", "Muestra «Gaby» con el logo girando") {
            val icon = try { packageManager.getApplicationIcon(packageName) } catch (e: Exception) { null }
            if (!NotifOverlay.show(this, icon, "Gaby", "respondió tu mensaje")) {
                toast("Primero activa «Mostrar sobre otras apps»")
            }
        }
        addInfo("El sistema puede mostrar su aviso una fracción de segundo antes de que el launcher lo tape. " +
            "Las animaciones propias de Android no se pueden desactivar desde una app.")
    }

    private fun buildPerf() {
        titleView.text = "Rendimiento"
        addSwitch("Modo ahorro", "Desactiva animaciones del launcher y actualiza menos el panel de recursos", "perf_save", false)
        addSwitch("Recursos en vivo", "Si lo apagas, el panel de recursos se actualiza solo al abrirlo", "res_live", true)
        addRow(R.drawable.ic_default, "Recargar apps e iconos", "Vuelve a leer las apps instaladas") {
            Prefs.setBool(this, "reload_req", true)
            toast("Se recargarán al volver al inicio")
        }
        addInfo("Los cambios se aplican al volver a la pantalla principal.")
    }

    private fun buildImmersive() {
        titleView.text = "Pantalla completa e inmersión"
        addSwitch("Ocultar barra de estado", "En la pantalla principal", "hide_status", false)
        addSwitch("Ocultar barra de navegación", "Desliza desde el borde para mostrarla", "hide_nav", false)
    }

    private fun buildInfo() {
        titleView.text = "Información"
        var ver = "1.0"
        try {
            ver = packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
        } catch (e: Exception) {
        }
        addInfo("VERDANT Launcher\nVersión $ver")
        addInfo("Paquete: $packageName\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        addInfo("Launcher predeterminado actual:\n" + defaultHomeLabel())
        addRow(R.drawable.ic_default, "Launcher predeterminado", "Establecer o cambiar launcher") { open("default") }
        addRow(R.drawable.ic_info, "Información de la app (Android)", "Permisos, almacenamiento y más", {
            startSafe(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
    }

    // ---------------------------------------------------------------- launcher predeterminado

    private fun homeResolvePkg(): String? {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        val p = ri?.activityInfo?.packageName
        return if (p == null || p == "android") null else p
    }

    private fun defaultHomeLabel(): String {
        val p = homeResolvePkg() ?: return "ninguno (Android preguntará cada vez)"
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString()
        } catch (e: Exception) {
            p
        }
    }

    private fun requestDefault() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(Context.ROLE_SERVICE) as? RoleManager
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                if (rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    toast("VERDANT ya es el launcher predeterminado")
                    return
                }
                try {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 77)
                    return
                } catch (e: Exception) {
                }
            }
        }
        openHomeSettings()
    }

    private fun openHomeSettings() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } catch (e2: Exception) {
                toast("Abre Ajustes > Apps > Apps predeterminadas > App de inicio")
            }
        }
    }

    private fun buildDefault() {
        titleView.text = "Launcher predeterminado"
        val mine = homeResolvePkg() == packageName
        addInfo("Launcher predeterminado actual:\n" + defaultHomeLabel())
        addRow(
            R.drawable.ic_default,
            if (mine) "VERDANT ya es el predeterminado" else "Establecer VERDANT como predeterminado",
            "Usa el diálogo oficial de Android",
            { requestDefault() }
        )
        addRow(R.drawable.ic_home, "Cambiar launcher predeterminado", "Abre el selector de Android", { openHomeSettings() })

        addSection("Launchers instalados")
        val hi = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val list = packageManager.queryIntentActivities(hi, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
        if (list.isEmpty()) addInfo("No hay otros launchers instalados.")
        for (ri in list) {
            val c = card()
            val iv = ImageView(this)
            iv.setImageDrawable(ri.loadIcon(packageManager))
            val lp = LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40))
            lp.rightMargin = Ui.dp(this, 14)
            c.addView(iv, lp)
            c.addView(texts(ri.loadLabel(packageManager).toString(), "Toca para abrirlo ahora"))
            val pkg = ri.activityInfo.packageName
            val cls = ri.activityInfo.name
            c.setOnClickListener {
                val i = Intent(Intent.ACTION_MAIN)
                i.addCategory(Intent.CATEGORY_HOME)
                i.setClassName(pkg, cls)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startSafe(i)
            }
            body.addView(c)
        }
        addInfo("Para dejar otro launcher como predeterminado, usa «Cambiar launcher predeterminado»: Android no permite que una app lo cambie sin tu confirmación.")
    }
}
