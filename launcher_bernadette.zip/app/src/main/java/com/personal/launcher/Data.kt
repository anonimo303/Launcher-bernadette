package com.personal.launcher

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.content.res.Resources
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

class AppInfo(val label: String, val pkg: String, val cls: String, val icon: Drawable) {
    val key: String get() = pkg + "/" + cls
    fun newIcon(): Drawable = icon.constantState?.newDrawable()?.mutate() ?: icon
}

object AppRepo {
    @Volatile var list: List<AppInfo> = emptyList()
    @Volatile var loaded: Boolean = false

    fun load(ctx: Context) {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val res = pm.queryIntentActivities(i, 0)
        val out = ArrayList<AppInfo>()
        val pack = Prefs.str(ctx, "icon_pack")?.let { IconPacks.load(ctx, it) }
        for (r in res) {
            // MAHORAGA GAMES vive en este mismo paquete y SÍ debe aparecer en el cajón; el launcher no.
            if (r.activityInfo.packageName == ctx.packageName && r.activityInfo.name != com.personal.launcher.mahoraga.Mh.ACT) continue
            val key = r.activityInfo.packageName + "/" + r.activityInfo.name
            // su icono oficial nunca se sustituye por el de un icon pack
            val icon = (if (com.personal.launcher.mahoraga.Mh.isEntry(key)) null else pack?.icon(key)) ?: r.loadIcon(pm)
            out.add(AppInfo(r.loadLabel(pm).toString(), r.activityInfo.packageName, r.activityInfo.name, icon))
        }
        out.sortBy { it.label.lowercase() }
        list = out
        loaded = true
    }

    fun find(key: String): AppInfo? = list.firstOrNull { it.key == key }
}

class HomeItem(val key: String, var x: Float, var y: Float)

object HomeStore {
    const val GEAR = "verdant:settings"
    private const val KEY = "items"

    fun load(c: Context): MutableList<HomeItem> {
        val s = Prefs.str(c, KEY)
        val out = ArrayList<HomeItem>()
        if (s == null) {
            out.add(HomeItem(GEAR, 0.05f, 0.08f))
            save(c, out)
            return out
        }
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(HomeItem(o.getString("k"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat()))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun save(c: Context, items: List<HomeItem>) {
        val a = JSONArray()
        for (h in items) {
            val o = JSONObject()
            o.put("k", h.key)
            o.put("x", h.x.toDouble())
            o.put("y", h.y.toDouble())
            a.put(o)
        }
        Prefs.setStr(c, KEY, a.toString())
    }

    fun nextFree(items: List<HomeItem>): Pair<Float, Float> {
        for (r in 0 until 6) {
            for (col in 0 until 4) {
                val x = 0.05f + col * 0.235f
                val y = 0.08f + r * 0.14f
                if (items.none { abs(it.x - x) < 0.1f && abs(it.y - y) < 0.1f }) {
                    return Pair(x, y)
                }
            }
        }
        return Pair(0.05f, 0.5f)
    }

    fun addGear(c: Context): Boolean {
        val items = load(c)
        if (items.any { it.key == GEAR }) return false
        val p = nextFree(items)
        items.add(HomeItem(GEAR, p.first, p.second))
        save(c, items)
        return true
    }

    fun reset(c: Context) {
        Prefs.setStr(c, KEY, null)
        load(c)
    }
}

/** Icon pack compatible con el estándar appfilter.xml (ADW / Nova / Apex y similares). */
class IconPack(private val res: Resources, private val pkg: String, private val map: Map<String, String>) {
    fun icon(key: String): Drawable? {
        val name = map[key] ?: return null
        val id = res.getIdentifier(name, "drawable", pkg)
        if (id == 0) return null
        return try {
            res.getDrawable(id, null)
        } catch (e: Exception) {
            null
        }
    }
}

object IconPacks {
    private val ACTIONS = listOf(
        "org.adw.launcher.THEMES",
        "com.novalauncher.THEME",
        "com.gau.go.launcherex.theme",
        "com.anddoes.launcher.THEME"
    )

    /** Devuelve (paquete, nombre) de los icon packs instalados. */
    fun installed(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val seen = LinkedHashMap<String, String>()
        for (a in ACTIONS) {
            try {
                for (ri in pm.queryIntentActivities(Intent(a), 0)) {
                    val p = ri.activityInfo.packageName
                    if (!seen.containsKey(p)) seen[p] = ri.loadLabel(pm).toString()
                }
            } catch (e: Exception) {
            }
        }
        return seen.map { Pair(it.key, it.value) }.sortedBy { it.second.lowercase() }
    }

    fun load(ctx: Context, pkg: String): IconPack? {
        try {
            val pc = ctx.createPackageContext(pkg, 0)
            val res = pc.resources
            val parser: org.xmlpull.v1.XmlPullParser
            val id = res.getIdentifier("appfilter", "xml", pkg)
            if (id != 0) {
                parser = res.getXml(id)
            } else {
                parser = Xml.newPullParser()
                parser.setInput(pc.assets.open("appfilter.xml"), null)
            }
            val map = HashMap<String, String>()
            var ev = parser.eventType
            while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG && parser.name == "item") {
                    val comp = parser.getAttributeValue(null, "component")
                    val dr = parser.getAttributeValue(null, "drawable")
                    if (comp != null && dr != null && comp.startsWith("ComponentInfo{")) {
                        map[comp.substring(14).trimEnd('}')] = dr
                    }
                }
                ev = parser.next()
            }
            return if (map.isEmpty()) null else IconPack(res, pkg, map)
        } catch (e: Exception) {
            return null
        }
    }
}
