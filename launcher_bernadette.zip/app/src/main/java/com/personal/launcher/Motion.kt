package com.personal.launcher

import android.view.animation.PathInterpolator

/** Curvas compartidas para que todo el launcher se mueva con la misma suavidad. */
object Motion {
    /** Arranca con el impulso del dedo y se asienta despacio, sin frenazo. */
    val settle = PathInterpolator(0.3f, 0.6f, 0.15f, 1f)

    /** Entrada y salida suaves (cajón al cerrarse). */
    val inOut = PathInterpolator(0.4f, 0f, 0.2f, 1f)
}
