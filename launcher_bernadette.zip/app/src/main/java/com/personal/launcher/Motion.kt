package com.personal.launcher

import android.view.animation.PathInterpolator

/** Curvas compartidas para que todo el launcher se mueva con la misma suavidad. */
object Motion {
    /** Arranca con el impulso del dedo y se asienta despacio, sin frenazo. */
    val settle = PathInterpolator(0.25f, 0.9f, 0.3f, 1f)

    /** Entrada y salida suaves (cajón al cerrarse). */
    val inOut = PathInterpolator(0.4f, 0f, 0.2f, 1f)
}
