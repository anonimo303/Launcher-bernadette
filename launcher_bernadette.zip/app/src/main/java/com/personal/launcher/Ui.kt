package com.personal.launcher

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    val TEXT: Int = Color.parseColor("#E8FFF4")
    val SUB: Int = Color.parseColor("#A8D5C0")
    val ACCENT: Int = Color.parseColor("#3EF0A0")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    /** Panel translúcido (glassmorphism barato: relleno con alfa + borde luminoso). */
    fun glass(c: Context, radiusDp: Int, strong: Boolean = false): GradientDrawable {
        val a = if (strong) "#F2062014" else "#40128A52"
        val b = if (strong) "#F2020B06" else "#29051A10"
        val g = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor(a), Color.parseColor(b))
        )
        g.cornerRadius = dp(c, radiusDp).toFloat()
        g.setStroke(dp(c, 1) + 1, Color.parseColor(if (strong) "#B334F0A0" else "#8C34F0A0"))
        return g
    }

    fun menu(a: Activity, title: String, labels: List<String>, onPick: (Int) -> Unit) {
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(a, 20), dp(a, 18), dp(a, 20), dp(a, 10))
        col.background = glass(a, 24, true)
        val t = TextView(a)
        t.text = title
        t.setTextColor(ACCENT)
        t.textSize = 14f
        t.setPadding(0, 0, 0, dp(a, 6))
        col.addView(t)
        for (i in labels.indices) {
            val tv = TextView(a)
            tv.text = labels[i]
            tv.setTextColor(TEXT)
            tv.textSize = 16f
            tv.setPadding(0, dp(a, 14), 0, dp(a, 14))
            tv.setOnClickListener {
                d.dismiss()
                onPick(i)
            }
            col.addView(tv)
        }
        d.setContentView(col)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout(dp(a, 300), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }
}
