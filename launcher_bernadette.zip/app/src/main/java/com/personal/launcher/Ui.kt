package com.personal.launcher

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.view.Window
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    val TEXT: Int = Color.parseColor("#E8FFF4")
    val SUB: Int = Color.parseColor("#A8D5C0")
    val ACCENT: Int = Color.parseColor("#3EF0A0")
    val LEVEL_GOOD: Int = Color.parseColor("#3EF0A0")   // verde
    val LEVEL_MID: Int = Color.parseColor("#FFA23E")    // naranja
    val LEVEL_BAD: Int = Color.parseColor("#FF5A5A")    // rojo

    /**
     * Color según lo que QUEDA (0..1): 85 % o más = verde, de 40 % a 84 % = naranja, menos de 40 % = rojo.
     * Batería: 100/94 verde; 80/70/60 naranja; 30/20/10 rojo. RAM y almacenamiento usan lo que queda libre.
     */
    fun levelColor(remaining: Float): Int = when {
        remaining >= 0.85f -> LEVEL_GOOD
        remaining >= 0.40f -> LEVEL_MID
        else -> LEVEL_BAD
    }

    /** Interruptor con estado inequívoco: ACTIVADO = verde con botón blanco, DESACTIVADO = gris apagado. */
    fun styleSwitch(sw: android.widget.Switch) {
        val on = intArrayOf(android.R.attr.state_checked)
        val states = arrayOf(on, intArrayOf())
        sw.thumbTintList = android.content.res.ColorStateList(states, intArrayOf(Color.parseColor("#FFFFFF"), Color.parseColor("#9A9AB0")))
        sw.trackTintList = android.content.res.ColorStateList(states, intArrayOf(Color.parseColor("#2ECC71"), Color.parseColor("#4A4A62")))
    }

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    /** Panel translúcido (glassmorphism barato: relleno con alfa + borde luminoso). */
    fun glass(c: Context, radiusDp: Int, strong: Boolean = false): GradientDrawable {
        val a = if (strong) "#F2062014" else "#40128A52"
        val b = if (strong) "#F2020B06" else "#29051A10"
        val g = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor(a), Color.parseColor(b))
        )
        g.cornerRadius = dp(c, radiusDp).toFloat()
        g.setStroke(dp(c, 1) + 1, Color.parseColor(if (strong) "#B334F0A0" else "#8C34F0A0"))
        return g
    }

    fun menu(a: Activity, title: String, labels: List<String>, onPick: (Int) -> Unit) {
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(a, 20), dp(a, 18), dp(a, 20), dp(a, 10))
        col.background = glass(a, 24, true)
        val t = TextView(a)
        t.text = title
        t.setTextColor(ACCENT)
        t.textSize = 14f
        t.setPadding(0, 0, 0, dp(a, 6))
        col.addView(t)
        for (i in labels.indices) {
            val tv = TextView(a)
            tv.text = labels[i]
            tv.setTextColor(TEXT)
            tv.textSize = 16f
            tv.setPadding(0, dp(a, 14), 0, dp(a, 14))
            tv.setOnClickListener {
                d.dismiss()
                onPick(i)
            }
            col.addView(tv)
        }
        d.setContentView(col)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout(dp(a, 300), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    /** Igual que [menu] pero cada fila lleva el icono de la app a la izquierda y la lista se puede desplazar. */
    fun menuIcons(a: Activity, title: String, labels: List<String>, icons: List<Drawable?>, onPick: (Int) -> Unit) {
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(a, 20), dp(a, 18), dp(a, 20), dp(a, 10))
        col.background = glass(a, 24, true)
        val t = TextView(a)
        t.text = title
        t.setTextColor(ACCENT)
        t.textSize = 14f
        t.setPadding(0, 0, 0, dp(a, 6))
        col.addView(t)
        val list = LinearLayout(a)
        list.orientation = LinearLayout.VERTICAL
        for (i in labels.indices) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(a, 8), 0, dp(a, 8))
            val iv = ImageView(a)
            iv.setImageDrawable(icons.getOrNull(i)?.constantState?.newDrawable()?.mutate() ?: icons.getOrNull(i))
            row.addView(iv, LinearLayout.LayoutParams(dp(a, 40), dp(a, 40)))
            val tv = TextView(a)
            tv.text = labels[i]
            tv.setTextColor(TEXT)
            tv.textSize = 16f
            tv.maxLines = 1
            tv.ellipsize = android.text.TextUtils.TruncateAt.END
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.leftMargin = dp(a, 14)
            row.addView(tv, lp)
            row.setOnClickListener {
                d.dismiss()
                onPick(i)
            }
            list.addView(row)
        }
        val sv = ScrollView(a)
        sv.addView(list)
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        d.setContentView(col)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val maxH = (a.resources.displayMetrics.heightPixels * 0.75f).toInt()
        val wantH = dp(a, 18 + 10 + 30) + labels.size * dp(a, 56)
        d.window?.setLayout(dp(a, 320), if (wantH < maxH) ViewGroup.LayoutParams.WRAP_CONTENT else maxH)
        d.show()
    }

    /**
     * Cuadro con una imagen (por ejemplo el perrito de «contraseña incorrecta»), del mismo ancho
     * que el cuadro de aplicaciones ocultas, con una ✕ arriba a la derecha para cerrarlo.
     */
    fun imageDialog(a: Activity, res: Int) {
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = FrameLayout(a)
        box.background = glass(a, 24, true)
        box.setPadding(dp(a, 12), dp(a, 12), dp(a, 12), dp(a, 12))
        val iv = ImageView(a)
        iv.setImageResource(res)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.adjustViewBounds = true
        iv.clipToOutline = true
        iv.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: android.view.View, o: android.graphics.Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(a, 16).toFloat())
            }
        }
        box.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val x = TextView(a)
        x.text = "✕"
        x.setTextColor(Color.WHITE)
        x.textSize = 18f
        x.gravity = Gravity.CENTER
        x.background = GradientDrawable().apply { setColor(Color.parseColor("#B3000000")); shape = GradientDrawable.OVAL }
        x.setOnClickListener { d.dismiss() }
        box.addView(x, FrameLayout.LayoutParams(dp(a, 36), dp(a, 36), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(a, 4); rightMargin = dp(a, 4)
        })
        d.setContentView(box)
        d.setCanceledOnTouchOutside(true)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout(dp(a, 320), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }
}
