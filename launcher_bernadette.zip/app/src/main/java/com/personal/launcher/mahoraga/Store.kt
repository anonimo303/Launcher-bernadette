package com.personal.launcher.mahoraga

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Estadísticas agregadas de una sesión. -1 / NaN = no se pudo medir. */
class Stats(
    val seconds: Int, val n: Int,
    val ramTotalMb: Int, val ramAvailMin: Int, val ramAvailAvg: Int, val lowMem: Boolean,
    val swapTotalMb: Int, val swapUsedMax: Int,
    val tempStart: Float, val tempMax: Float, val tempAvg: Float,
    val thermalMax: Int,
    val cpuAvg: Int, val cpuMax: Int, val freqAvg: Int, val freqMax: Int,
    val battStart: Int, val battEnd: Int, val charging: Boolean, val zoneMax: Float,
    val fpsAvg: Int = -1, val fpsMin: Int = -1
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("sec", seconds); o.put("n", n)
        o.put("rt", ramTotalMb); o.put("rmin", ramAvailMin); o.put("ravg", ramAvailAvg); o.put("low", lowMem)
        o.put("st", swapTotalMb); o.put("sum", swapUsedMax)
        if (!tempStart.isNaN()) o.put("t0", tempStart.toDouble())
        if (!tempMax.isNaN()) o.put("tmax", tempMax.toDouble())
        if (!tempAvg.isNaN()) o.put("tavg", tempAvg.toDouble())
        o.put("th", thermalMax)
        o.put("cavg", cpuAvg); o.put("cmax", cpuMax); o.put("favg", freqAvg); o.put("fmax", freqMax)
        o.put("b0", battStart); o.put("b1", battEnd); o.put("chg", charging)
        if (!zoneMax.isNaN()) o.put("zmax", zoneMax.toDouble())
        o.put("fa", fpsAvg); o.put("fm", fpsMin)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject) = Stats(
            o.optInt("sec"), o.optInt("n"),
            o.optInt("rt"), o.optInt("rmin"), o.optInt("ravg"), o.optBoolean("low"),
            o.optInt("st", -1), o.optInt("sum", -1),
            o.optDouble("t0", Double.NaN).toFloat(), o.optDouble("tmax", Double.NaN).toFloat(),
            o.optDouble("tavg", Double.NaN).toFloat(),
            o.optInt("th", -1),
            o.optInt("cavg", -1), o.optInt("cmax", -1), o.optInt("favg", -1), o.optInt("fmax", -1),
            o.optInt("b0", -1), o.optInt("b1", -1), o.optBoolean("chg"),
            o.optDouble("zmax", Double.NaN).toFloat(),
            o.optInt("fa", -1), o.optInt("fm", -1)
        )
    }
}

/** Acumula lecturas sin guardar cada muestra (consumo mínimo de RAM). */
class StatsAcc {
    private var n = 0
    private var firstAt = 0L
    private var lastAt = 0L
    private var ramTotal = 0
    private var ramMin = Int.MAX_VALUE
    private var ramSum = 0L
    private var low = false
    private var swapTotal = -1
    private var swapUsedMax = -1
    private var tStart = Float.NaN
    private var tMax = Float.NaN
    private var tSum = 0f
    private var tN = 0
    private var thermalMax = -1
    private var cpuSum = 0L
    private var cpuN = 0
    private var cpuMax = -1
    private var fSum = 0L
    private var fN = 0
    private var fMax = -1
    private var bStart = -1
    private var bEnd = -1
    private var chg = false
    private var zMax = Float.NaN
    private var fpsSum = 0L
    private var fpsN = 0
    private var fpsMin = -1

    fun add(s: Sample, nowMs: Long) {
        if (n == 0) firstAt = nowMs
        lastAt = nowMs
        n++
        ramTotal = s.ramTotalMb
        if (s.ramAvailMb < ramMin) ramMin = s.ramAvailMb
        ramSum += s.ramAvailMb
        if (s.lowMem) low = true
        if (s.swapTotalMb > 0) {
            swapTotal = s.swapTotalMb
            val used = s.swapTotalMb - s.swapFreeMb
            if (used > swapUsedMax) swapUsedMax = used
        }
        if (!s.battTemp.isNaN()) {
            if (tStart.isNaN()) tStart = s.battTemp
            if (tMax.isNaN() || s.battTemp > tMax) tMax = s.battTemp
            tSum += s.battTemp; tN++
        }
        if (s.thermal > thermalMax) thermalMax = s.thermal
        if (s.cpuPct >= 0) { cpuSum += s.cpuPct; cpuN++; if (s.cpuPct > cpuMax) cpuMax = s.cpuPct }
        if (s.freqMhz >= 0) { fSum += s.freqMhz; fN++; if (s.freqMhz > fMax) fMax = s.freqMhz }
        if (s.battPct >= 0) { if (bStart < 0) bStart = s.battPct; bEnd = s.battPct }
        chg = chg || s.charging
        if (s.fps >= 0) { fpsSum += s.fps; fpsN++; if (fpsMin < 0 || s.fps < fpsMin) fpsMin = s.fps }
        if (!s.zoneTemp.isNaN() && (zMax.isNaN() || s.zoneTemp > zMax)) zMax = s.zoneTemp
    }

    /** Segundos reales transcurridos entre la primera y la última lectura. */
    val seconds: Int get() = if (n == 0) 0 else ((lastAt - firstAt) / 1000L).toInt() + 2

    fun stats(): Stats? {
        if (n == 0) return null
        return Stats(
            seconds, n, ramTotal, ramMin, (ramSum / n).toInt(), low, swapTotal, swapUsedMax,
            tStart, tMax, if (tN > 0) tSum / tN else Float.NaN, thermalMax,
            if (cpuN > 0) (cpuSum / cpuN).toInt() else -1, cpuMax,
            if (fN > 0) (fSum / fN).toInt() else -1, fMax,
            bStart, bEnd, chg, zMax,
            if (fpsN > 0) (fpsSum / fpsN).toInt() else -1, fpsMin
        )
    }
}

class Finding(val text: String, val problem: Boolean)

/** status: applied | recommended | unavailable | reverted */
class Action(val id: String, val title: String, var status: String, var detail: String, val needs: String) {
    fun statusLabel(): String = when (status) {
        "applied" -> "Aplicada correctamente"
        "recommended" -> "Recomendada, no aplicada"
        "unavailable" -> "No disponible"
        "reverted" -> "Revertida"
        else -> status
    }
}

class Report(val id: Long, val num: Int, val pkg: String, val game: String, val ts: Long) {
    var diag: Stats? = null
    var verified = false
    var findings: List<Finding> = emptyList()
    var actions: MutableList<Action> = ArrayList()
    var applied = false
    var appliedTs = 0L
    var after: Stats? = null
    var afterTs = 0L

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id); o.put("num", num); o.put("pkg", pkg); o.put("game", game); o.put("ts", ts)
        diag?.let { o.put("diag", it.toJson()) }
        o.put("ver", verified)
        val f = JSONArray()
        for (x in findings) f.put(JSONObject().put("t", x.text).put("p", x.problem))
        o.put("find", f)
        val a = JSONArray()
        for (x in actions) a.put(JSONObject().put("id", x.id).put("ti", x.title).put("s", x.status).put("d", x.detail).put("n", x.needs))
        o.put("acts", a)
        o.put("applied", applied); o.put("appliedTs", appliedTs)
        after?.let { o.put("after", it.toJson()) }
        o.put("afterTs", afterTs)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Report {
            val r = Report(o.getLong("id"), o.optInt("num"), o.getString("pkg"), o.optString("game"), o.optLong("ts"))
            o.optJSONObject("diag")?.let { r.diag = Stats.fromJson(it) }
            r.verified = o.optBoolean("ver")
            val f = o.optJSONArray("find")
            val fl = ArrayList<Finding>()
            if (f != null) for (i in 0 until f.length()) { val x = f.getJSONObject(i); fl.add(Finding(x.optString("t"), x.optBoolean("p"))) }
            r.findings = fl
            val a = o.optJSONArray("acts")
            if (a != null) for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                r.actions.add(Action(x.optString("id"), x.optString("ti"), x.optString("s"), x.optString("d"), x.optString("n")))
            }
            r.applied = o.optBoolean("applied"); r.appliedTs = o.optLong("appliedTs")
            o.optJSONObject("after")?.let { r.after = Stats.fromJson(it) }
            r.afterTs = o.optLong("afterTs")
            return r
        }
    }
}

object Reports {
    private fun file(c: Context) = File(c.filesDir, "mh_reports.json")

    @Synchronized
    fun all(c: Context): MutableList<Report> {
        val out = ArrayList<Report>()
        try {
            val f = file(c)
            if (!f.exists()) return out
            val a = JSONArray(f.readText())
            for (i in 0 until a.length()) out.add(Report.fromJson(a.getJSONObject(i)))
        } catch (e: Exception) { }
        return out
    }

    @Synchronized
    fun save(c: Context, r: Report) {
        val l = all(c)
        val i = l.indexOfFirst { it.id == r.id }
        if (i >= 0) l[i] = r else l.add(r)
        while (l.size > 40) l.removeAt(0)
        val a = JSONArray()
        for (x in l) a.put(x.toJson())
        try { file(c).writeText(a.toString()) } catch (e: Exception) { }
    }

    fun latest(c: Context, pkg: String): Report? = all(c).lastOrNull { it.pkg == pkg }

    fun nextNum(c: Context): Int = (all(c).maxOfOrNull { it.num } ?: 0) + 1
}
