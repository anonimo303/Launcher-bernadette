package com.personal.launcher.mahoraga

import android.content.Context
import android.os.Build
import com.personal.launcher.Prefs

/**
 * MAHORAGA IA — optimizador de un toque. Funciona en el propio teléfono (sin internet ni servidores).
 *
 *  1. Mira qué puede hacer ESTE equipo: Shizuku activo o no, permisos, versión de Android.
 *  2. Mide el estado actual (o usa el último diagnóstico) y decide qué ajustes tienen sentido.
 *  3. Aplica solo lo que el equipo permite. Sin Shizuku, hace lo que se puede sin él.
 *  4. Si algo falla en este equipo, lo anota y NO vuelve a insistir (salvo que cambie el sistema o
 *     pasen 30 días, o lo pidas tú).
 *
 * Nada se simula: lo que no se pudo hacer se muestra como «no disponible» con su motivo.
 */
object Ia {
    private const val RETRY_MS = 30L * 24 * 3600 * 1000

    /** Acciones cuyo fallo depende del equipo/juego y por eso se recuerda. */
    val REMEMBERED = setOf("shz_gamemode", "shz_tune", "shz_compile", "net_force")

    class Caps(val shizuku: Boolean, val usage: Boolean, val notif: Boolean, val dnd: Boolean, val overlay: Boolean, val sdk: Int) {
        /** Firma del equipo: si cambia (p. ej. actualizas Android), se permite reintentar. */
        val sig: String get() = "sdk=$sdk"
    }

    fun caps(c: Context) = Caps(Shz.granted(), Mh.usageGranted(c), Mh.notifGranted(c), Mh.dndGranted(c), Mh.overlayGranted(c), Build.VERSION.SDK_INT)

    // ------------------------------------------------------------------ memoria de fallos («no insistir»)

    private fun key(pkg: String, id: String) = "mh_ia_f_${pkg}_$id"

    fun fail(c: Context, pkg: String, id: String, why: String) {
        if (id !in REMEMBERED) return
        val clean = why.replace("|", "/").replace("\n", " ").take(80)
        Prefs.setStr(c, key(pkg, id), "${caps(c).sig}|${System.currentTimeMillis()}|$clean")
    }

    /** Motivo si esta acción ya falló antes en este equipo y todavía no toca reintentar; null si se puede intentar. */
    fun blocked(c: Context, pkg: String, id: String): String? {
        val v = Prefs.str(c, key(pkg, id)) ?: return null
        val p = v.split("|")
        if (p.size < 3) return null
        val ts = p[1].toLongOrNull() ?: return null
        if (p[0] != caps(c).sig || System.currentTimeMillis() - ts > RETRY_MS) return null
        return p[2].ifBlank { "el sistema no lo aceptó" }
    }

    class Fail(val pkg: String, val game: String, val id: String, val why: String)

    fun failures(c: Context): List<Fail> {
        val out = ArrayList<Fail>()
        for (g in Games.library(c)) for (id in REMEMBERED) {
            val why = blocked(c, g.pkg, id) ?: continue
            out.add(Fail(g.pkg, g.name, id, why))
        }
        return out
    }

    fun forget(c: Context) {
        for (g in Games.library(c)) for (id in REMEMBERED) Prefs.setStr(c, key(g.pkg, id), null)
    }

    fun nameOf(id: String) = when (id) {
        "shz_gamemode" -> "Modo Rendimiento de Android"
        "shz_tune" -> "Bajar la resolución del juego"
        "shz_compile" -> "Optimizar el código del juego"
        "net_force" -> "Forzar Wi-Fi de baja latencia"
        else -> id
    }

    // ------------------------------------------------------------------ optimización de un toque

    class Summary(val game: String, val instant: Boolean, val caps: Caps,
                  val applied: List<String>, val skipped: List<Pair<String, String>>, val findings: List<Finding>)

    /** Lectura real y puntual del equipo, para poder decidir sin esperar un diagnóstico largo. */
    private fun instantStats(c: Context): Stats {
        Sys.sample(c)                       // la 1.ª lectura de CPU solo fija la referencia
        try { Thread.sleep(1200L) } catch (e: Exception) { }
        val s = Sys.sample(c)
        val t = s.battTemp
        val used = if (s.swapTotalMb > 0) s.swapTotalMb - s.swapFreeMb else -1
        return Stats(
            2, 1, s.ramTotalMb, s.ramAvailMb, s.ramAvailMb, s.lowMem, s.swapTotalMb, used,
            t, t, t, s.thermal, s.cpuPct, s.cpuPct, s.freqMhz, s.freqMhz,
            s.battPct, s.battPct, s.charging, s.zoneTemp, s.fps, s.fps
        )
    }

    /** NO llamar desde el hilo principal (mide ~1 s y puede ejecutar comandos de Shizuku). */
    fun optimize(c: Context, g: Game): Summary {
        val app = c.applicationContext
        val caps = caps(app)
        var r = Reports.latest(app, g.pkg)?.takeIf { it.diag != null }
        val instant = r == null
        val st: Stats
        if (r == null) {
            st = instantStats(app)
            r = Report(System.currentTimeMillis(), Reports.nextNum(app), g.pkg, g.name, System.currentTimeMillis())
            r.diag = st
            r.verified = true
            r.findings = listOf(Finding("Lectura instantánea de MAHORAGA IA (sin diagnóstico largo): refleja el estado de este momento.", false)) +
                Brain.findings(st, true)
        } else st = r.diag!!
        r.actions = Brain.plan(app, g, st, r.findings)
        val done = Brain.apply(app, r)
        val skipped = r.actions.filter { it.status == "unavailable" }.map { it.title to it.detail }
        return Summary(g.name, instant, caps, Brain.lines(done), skipped, r.findings)
    }
}
