package com.personal.launcher.mahoraga

import android.app.AppOpsManager
import android.app.NotificationManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.widget.TextView
import android.graphics.Typeface
import com.personal.launcher.Prefs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Constantes, permisos y utilidades comunes del módulo MAHORAGA GAMES. */
object Mh {
    val BG = Color.parseColor("#0E0724")
    val CARD = Color.parseColor("#1B1146")
    val CARD2 = Color.parseColor("#241659")
    val LINE = Color.parseColor("#4B35A0")
    val VIOLET = Color.parseColor("#8B5CF6")
    val VIOLET_L = Color.parseColor("#B388FF")
    val TEXT = Color.WHITE
    val SUB = Color.parseColor("#B9AEE6")
    val GOOD = Color.parseColor("#3EF0A0")
    val WARN = Color.parseColor("#FFC857")
    val BAD = Color.parseColor("#FF6B6B")
    val GOLD = Color.parseColor("#FFD54A")

    const val ACT = "com.personal.launcher.mahoraga.MahoragaActivity"

    /** ¿La clave del cajón (paquete/clase) corresponde a MAHORAGA GAMES? */
    fun isEntry(key: String): Boolean = key.endsWith("/$ACT")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun round(color: Int, radiusPx: Float, stroke: Int = 0, strokePx: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radiusPx
        if (strokePx > 0) g.setStroke(strokePx, stroke)
        return g
    }

    fun text(c: Context, s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    fun fmtDate(ts: Long): String = SimpleDateFormat("d MMM HH:mm", Locale("es")).format(Date(ts))

    // ---------------------------------------------------------------- permisos reales

    fun usageGranted(c: Context): Boolean = try {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) ==
            AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    fun overlayGranted(c: Context): Boolean = Settings.canDrawOverlays(c)

    fun dndGranted(c: Context): Boolean = try {
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted
    } catch (e: Exception) { false }

    fun accessEnabled(): Boolean = MahoragaAccess.inst != null

    fun notifGranted(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 33) c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED
        else true

    fun freeformSupported(c: Context): Boolean = try {
        c.packageManager.hasSystemFeature("android.software.freeform_window_management") ||
            Settings.Global.getInt(c.contentResolver, "enable_freeform_support", 0) == 1
    } catch (e: Exception) { false }

    fun thermalName(s: Int): String = when (s) {
        0 -> "normal"; 1 -> "ligero"; 2 -> "moderado"; 3 -> "severo"
        4 -> "crítico"; 5 -> "emergencia"; 6 -> "apagado inminente"; else -> "no disponible"
    }

    fun panelEnabled(c: Context) = Prefs.bool(c, "mh_panel", true)

    /**
     * «Mostrar burbuja flotante» en una app concreta (interruptor ENCENDIDO = se muestra). Es independiente de las demás apps:
     * solo el interruptor general «Panel flotante en los juegos» apaga todas a la vez.
     * Antes el interruptor decía «No poner burbuja» (encendido = sin burbuja) y se prestaba a confusión: la primera vez se
     * conserva la posición que veías en pantalla (encendido sigue encendido), ahora con el significado «mostrar».
     */
    fun bubbleOn(c: Context, pkg: String): Boolean {
        bubbleMigrate(c)
        return Prefs.bool(c, "mh_bubble_$pkg", true)
    }
    fun bubbleOff(c: Context, pkg: String) = !bubbleOn(c, pkg)
    fun setBubbleOn(c: Context, pkg: String, on: Boolean) { bubbleMigrate(c); Prefs.setBool(c, "mh_bubble_$pkg", on) }

    private fun bubbleMigrate(c: Context) {
        if (Prefs.bool(c, "mh_bubble_mig", false)) return
        Prefs.setBool(c, "mh_bubble_mig", true)
        try { for (g in Games.library(c)) Prefs.setBool(c, "mh_bubble_${g.pkg}", Prefs.bool(c, "mh_nobubble_${g.pkg}", false)) } catch (e: Exception) { }
    }
}

/** Apps que MAHORAGA NUNCA toca (por ejemplo una VPN como HTTP Custom): se saltan al liberar memoria. */
object Protect {
    private const val KEY = "mh_protect"
    private const val HTTP_CUSTOM = "xyz.easypro.httpcustom"

    fun list(c: Context): List<String> {
        val s = Prefs.str(c, KEY) ?: return listOf(HTTP_CUSTOM)
        return s.split(",").filter { it.isNotBlank() }
    }

    fun has(c: Context, pkg: String) = pkg in list(c)

    private fun save(c: Context, l: List<String>) = Prefs.setStr(c, KEY, l.joinToString(","))

    fun add(c: Context, pkg: String) {
        val l = list(c).toMutableList()
        if (pkg !in l) { l.add(pkg); save(c, l) }
    }

    fun remove(c: Context, pkg: String) = save(c, list(c).filter { it != pkg })

    fun reset(c: Context) = Prefs.setStr(c, KEY, null)

    fun name(c: Context, pkg: String): String = when {
        Games.installed(c, pkg) -> Games.label(c, pkg)
        pkg == HTTP_CUSTOM -> "HTTP Custom (no instalada)"
        else -> pkg
    }
}

/** Apps que el usuario elige para que aparezcan como accesos dentro de la burbuja (ventana pequeña). */
object Quick {
    private const val KEY = "mh_quick"
    const val MAX = 9
    private val TIKTOK = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")

    private fun defaults(c: Context): List<String> {
        val out = ArrayList<String>()
        out.add("com.google.android.youtube")
        out.add(TIKTOK.firstOrNull { Games.installed(c, it) } ?: TIKTOK[0])
        out.add("com.kick.mobile")
        return out
    }

    /** Si abrir la app no es posible, estas tres se abren en la web como antes. */
    fun fallbackUrl(pkg: String): String? = when (pkg) {
        "com.google.android.youtube" -> "https://www.youtube.com"
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill" -> "https://www.tiktok.com"
        "com.kick.mobile" -> "https://kick.com"
        else -> null
    }

    fun name(c: Context, pkg: String): String = when {
        Games.installed(c, pkg) -> Games.label(c, pkg)
        pkg == "com.google.android.youtube" -> "YouTube"
        pkg == "com.kick.mobile" -> "Kick"
        pkg in TIKTOK -> "TikTok"
        else -> pkg
    }

    private fun raw(c: Context): List<String> {
        val s = Prefs.str(c, KEY) ?: return defaults(c)
        return s.split(",").filter { it.isNotBlank() }
    }

    fun list(c: Context): List<String> = raw(c).filter { Games.installed(c, it) || fallbackUrl(it) != null }

    private fun save(c: Context, l: List<String>) = Prefs.setStr(c, KEY, l.joinToString(","))

    fun add(c: Context, pkg: String) {
        val l = raw(c).toMutableList()
        if (pkg !in l && l.size < MAX) { l.add(pkg); save(c, l) }
    }

    fun remove(c: Context, pkg: String) = save(c, raw(c).filter { it != pkg })

    fun reset(c: Context) = Prefs.setStr(c, KEY, null)
}

class Game(val pkg: String, val name: String, val profile: String)

/** Biblioteca de juegos: los conocidos que estén instalados + los que el usuario añada. */
object Games {
    val KNOWN = listOf(
        Game("com.netease.newspike", "Blood Strike", "blood"),
        Game("org.ppsspp.ppsspp", "PPSSPP", "ppsspp"),
        Game("org.ppsspp.ppssppgold", "PPSSPP Gold", "ppsspp"),
        Game("com.mojang.minecraftpe", "Minecraft", "generic"),
        Game("com.dts.freefireth", "Free Fire", "generic"),
        Game("com.dts.freefiremax", "Free Fire MAX", "generic"),
        Game("com.tencent.ig", "PUBG MOBILE", "generic"),
        Game("com.activision.callofduty.shooter", "Call of Duty: Mobile", "generic"),
        Game("com.mobile.legends", "Mobile Legends", "generic")
    )

    fun installed(c: Context, pkg: String): Boolean = try {
        c.packageManager.getApplicationInfo(pkg, 0); true
    } catch (e: Exception) { false }

    private fun customList(c: Context): MutableList<String> =
        (Prefs.str(c, "mh_games") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()

    fun addCustom(c: Context, pkg: String) {
        val l = customList(c)
        if (pkg !in l) { l.add(pkg); Prefs.setStr(c, "mh_games", l.joinToString(",")) }
    }

    fun removeCustom(c: Context, pkg: String) {
        val l = customList(c); l.remove(pkg); Prefs.setStr(c, "mh_games", l.joinToString(","))
    }

    fun isCustom(c: Context, pkg: String) = pkg in customList(c)

    fun label(c: Context, pkg: String): String = try {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    fun library(c: Context): List<Game> {
        val out = ArrayList<Game>()
        for (g in KNOWN) if (installed(c, g.pkg)) out.add(g)
        for (p in customList(c)) {
            if (out.any { it.pkg == p } || !installed(c, p)) continue
            out.add(Game(p, label(c, p), if (p.startsWith("org.ppsspp")) "ppsspp" else "generic"))
        }
        return out
    }

    fun find(c: Context, pkg: String): Game? = library(c).firstOrNull { it.pkg == pkg }

    fun icon(c: Context, pkg: String): Drawable? = try { c.packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }

    fun launchIntent(c: Context, pkg: String): Intent? = c.packageManager.getLaunchIntentForPackage(pkg)
}

/** Detecta la app en primer plano con UsageStatsManager (requiere «Acceso de uso»). */
object Fg {
    private var cur: String? = null
    private var lastQ = 0L

    fun top(c: Context): String? {
        val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastQ == 0L) now - 60_000 else lastQ - 1000
        val ev = um.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            when (e.eventType) {
                1 -> cur = e.packageName                       // ACTIVITY_RESUMED
                2 -> if (e.packageName == cur) cur = null      // ACTIVITY_PAUSED
                17 -> cur = null                               // SCREEN_NON_INTERACTIVE
            }
        }
        lastQ = now
        return cur
    }

    fun reset() { cur = null; lastQ = 0L }
}

/** No molestar: solo con el permiso concedido por el usuario; siempre se restaura el estado anterior. */
object Dnd {
    private const val NONE = -99

    private fun nm(c: Context) = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun filterNow(c: Context): Int = try { nm(c).currentInterruptionFilter } catch (e: Exception) { 0 }

    /** true si MAHORAGA lo activó y sigue activo en el sistema. Si la persona lo apagó por su cuenta, se olvida. */
    fun active(c: Context): Boolean {
        if (Prefs.int(c, "mh_dnd_prev", NONE) == NONE) return false
        if (Mh.dndGranted(c) && filterNow(c) == NotificationManager.INTERRUPTION_FILTER_ALL) {
            Prefs.setInt(c, "mh_dnd_prev", NONE)
            return false
        }
        return true
    }

    fun enter(c: Context): Boolean {
        if (!Mh.dndGranted(c)) return false
        if (active(c)) return true
        var prev = filterNow(c)
        if (prev <= 0) prev = NotificationManager.INTERRUPTION_FILTER_ALL   // «desconocido» se restaura como «todo permitido»
        Prefs.setInt(c, "mh_dnd_prev", prev)
        try { nm(c).setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY) } catch (e: Exception) { }
        return true
    }

    fun exit(c: Context) {
        val prev = Prefs.int(c, "mh_dnd_prev", NONE)
        if (prev == NONE) return
        Prefs.setInt(c, "mh_dnd_prev", NONE)
        if (Mh.dndGranted(c)) {
            val back = if (prev <= 0) NotificationManager.INTERRUPTION_FILTER_ALL else prev
            try { nm(c).setInterruptionFilter(back) } catch (e: Exception) { }
        }
    }
}
