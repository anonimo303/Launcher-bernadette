package com.personal.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.os.SystemClock
import android.view.animation.OvershootInterpolator
import kotlin.math.exp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Barra de navegación animada. Un solo componente con TRES estilos visuales:
 *   0 = Arco     (joroba luminosa sobre la pestaña activa)
 *   1 = Haz      (foco de luz que cae sobre el icono activo)
 *   2 = Burbuja  (burbuja flotante con hueco curvo en la barra)
 *
 * Los tres comparten la misma lógica: [setPages], [setPosition] (arrastre continuo),
 * [animateTo] (toque) y [onSelect]. Solo cambia cómo se dibuja.
 *
 * Rendimiento: solo se redibuja cuando cambia la posición; sin BlurMaskFilter
 * (el brillo se simula con trazos superpuestos) y sin crear objetos por fotograma.
 */
class NavBar(ctx: Context) : View(ctx) {

    var navStyle: Int = 0
        set(v) {
            field = v.coerceIn(0, 2)
            invalidate()
        }

    var onSelect: ((Int) -> Unit)? = null

    /** Posición continua en unidades de pestaña (0 = primera). */
    var pos = 0f
        private set

    /** 0..1: intensidad del indicador (0 = ninguna pestaña activa, p. ej. en el cajón con gestos). */
    var intensity = 1f
        private set

    // Destino del indicador: durante el arrastre el indicador lo "persigue" con un retraso
    // suave (efecto líquido) en lugar de pegarse al dedo de golpe.
    private var tp = 0f
    private var ti = 1f
    private var lastT = 0L
    private var chasing = false
    private val chase = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            val dt = if (lastT == 0L) 0.016f else ((now - lastT) / 1000f).coerceIn(0.001f, 0.05f)
            lastT = now
            val a = 1f - exp(-dt * 9f)
            pos += (tp - pos) * a
            intensity += (ti - intensity) * a
            if (abs(tp - pos) < 0.002f && abs(ti - intensity) < 0.004f) {
                pos = tp
                intensity = ti
                chasing = false
                lastT = 0L
            }
            invalidate()
            if (chasing) postOnAnimation(this)
        }
    }

    private fun stopChase() {
        chasing = false
        lastT = 0L
        removeCallbacks(chase)
    }

    private var pages: List<PageId> = emptyList()
    private var icons: List<Drawable> = emptyList()
    private var anim: ValueAnimator? = null
    private val den = ctx.resources.displayMetrics.density

    private fun dp(v: Float) = v * den

    private val GLOW = 0xFF4FE8C8.toInt()
    private val INACTIVE = 0xFFC9D6D0.toInt()

    private val darkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB3061310L.toInt() }
    private val glassPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.style = Paint.Style.STROKE
        color = 0x59FFFFFF
        strokeWidth = dp(1.2f)
    }
    private val glowStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = GLOW
    }
    private val solid = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val beamPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        textSize = dp(10f)
    }

    private val bar = Path()
    private val cut = Path()
    private val hill = Path()
    private val line = Path()
    private val beam = Path()
    private val rect = RectF()

    private var shTop = Float.NaN
    private var shBottom = Float.NaN

    // ------------------------------------------------------------------ API

    fun setPages(list: List<PageId>) {
        pages = list
        icons = list.map { context.getDrawable(it.icon)!!.mutate() }
        pos = pos.coerceIn(0f, max(0, list.size - 1).toFloat())
        tp = pos
        ti = intensity
        invalidate()
    }

    /** Coloca el indicador sin animar (se usa mientras se arrastra entre pantallas). */
    fun setPosition(p: Float, i: Float) {
        anim?.cancel()
        tp = p
        ti = i.coerceIn(0f, 1f)
        if (!chasing) {
            chasing = true
            lastT = 0L
            postOnAnimation(chase)
        }
    }

    /** Anima el indicador hasta una pestaña (se usa al tocar). */
    fun animateTo(slot: Float, target: Float = 1f, durationMs: Long = 560L) {
        anim?.cancel()
        stopChase()
        val p0 = pos
        val i0 = intensity
        tp = slot
        ti = target
        if (durationMs <= 0L) {
            pos = slot
            intensity = target
            invalidate()
            return
        }
        if (abs(p0 - slot) < 0.001f && abs(i0 - target) < 0.001f) return
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = OvershootInterpolator(0.5f)
            addUpdateListener {
                val t = it.animatedValue as Float
                pos = p0 + (slot - p0) * t
                intensity = (i0 + (target - i0) * min(1f, t)).coerceIn(0f, 1f)
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        stopChase()
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ toques

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (pages.isEmpty()) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                if (e.x >= 0f && e.x <= width && e.y >= 0f && e.y <= height) {
                    val slotW = (width - dp(4f)) / pages.size
                    val i = ((e.x - dp(2f)) / slotW).toInt().coerceIn(0, pages.size - 1)
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    performClick()
                    onSelect?.invoke(i)
                }
            }
            else -> {}
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    // ------------------------------------------------------------------ dibujo

    private fun barHeight(): Float = when (navStyle) {
        0 -> dp(62f)
        else -> dp(56f)
    }

    private fun withAlpha(color: Int, a: Float): Int =
        (color and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24)

    private fun lerpColor(a: Int, b: Int, t: Float): Int {
        val f = t.coerceIn(0f, 1f)
        return Color.argb(
            (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * f).toInt(),
            (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
        )
    }

    private fun drawIcon(c: Canvas, idx: Int, cx: Float, cy: Float, size: Float, color: Int, alpha: Float) {
        val d = icons[idx]
        val h = size / 2f
        d.setBounds((cx - h).toInt(), (cy - h).toInt(), (cx + h).toInt(), (cy + h).toInt())
        d.setTint(color)
        d.alpha = (alpha.coerceIn(0f, 1f) * 255f).toInt()
        d.draw(c)
    }

    private fun ensureShaders(top: Float, bottom: Float) {
        if (top == shTop && bottom == shBottom) return
        shTop = top
        shBottom = bottom
        glassPaint.shader = LinearGradient(
            0f, top, 0f, bottom, 0x40FFFFFF, 0x0DFFFFFF, Shader.TileMode.CLAMP
        )
        hillPaint.shader = LinearGradient(
            0f, top, 0f, bottom, withAlpha(GLOW, 0.34f), withAlpha(GLOW, 0.02f), Shader.TileMode.CLAMP
        )
        beamPaint.shader = LinearGradient(
            0f, top, 0f, bottom, withAlpha(GLOW, 0.50f), withAlpha(GLOW, 0.0f), Shader.TileMode.CLAMP
        )
    }

    /** Trazo con brillo: tres pasadas (ancha tenue, media, fina intensa). */
    private fun strokeGlow(c: Canvas, p: Path, width: Float, k: Float) {
        glowStroke.strokeWidth = width * 3.4f
        glowStroke.alpha = (28 * k).toInt()
        c.drawPath(p, glowStroke)
        glowStroke.strokeWidth = width * 1.9f
        glowStroke.alpha = (70 * k).toInt()
        c.drawPath(p, glowStroke)
        glowStroke.strokeWidth = width
        glowStroke.alpha = (255 * k).toInt()
        c.drawPath(p, glowStroke)
    }

    override fun onDraw(c: Canvas) {
        val n = pages.size
        if (n == 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        val barH = barHeight()
        val bottom = h - dp(1f)
        val top = bottom - barH
        val left = dp(2f)
        val right = w - dp(2f)
        val slotW = (right - left) / n
        val cx = left + slotW * (pos + 0.5f)
        val near = pos.roundToInt().coerceIn(0, n - 1)
        val frac = abs(pos - pos.roundToInt())
        val dip = if (navStyle == 2) sin(frac * Math.PI.toFloat()) * dp(7f) else 0f
        val k = intensity

        ensureShaders(top, bottom)

        // ---- forma de la barra (el estilo Burbuja le abre un hueco curvo)
        rect.set(left, top, right, bottom)
        bar.reset()
        bar.addRoundRect(rect, barH / 2f, barH / 2f, Path.Direction.CW)
        if (navStyle == 2 && k > 0.02f) {
            val depth = (dp(17f) + dip) * k
            val nw = dp(40f)
            val y0 = top - dp(1f)
            cut.reset()
            cut.moveTo(cx - nw, y0)
            cut.cubicTo(cx - nw * 0.45f, y0, cx - nw * 0.55f, top + depth, cx, top + depth)
            cut.cubicTo(cx + nw * 0.55f, top + depth, cx + nw * 0.45f, y0, cx + nw, y0)
            cut.lineTo(cx + nw, top - dp(60f))
            cut.lineTo(cx - nw, top - dp(60f))
            cut.close()
            bar.op(cut, Path.Op.DIFFERENCE)
        }
        c.drawPath(bar, darkPaint)
        c.drawPath(bar, glassPaint)
        c.drawPath(bar, edgePaint)

        when (navStyle) {
            0 -> drawArc(c, n, left, right, top, bottom, barH, slotW, cx)
            1 -> drawBeam(c, n, top, bottom, barH, slotW, cx)
            else -> drawBubble(c, n, top, barH, slotW, cx, dip, near)
        }
    }

    // ---- Estilo 0: Arco -------------------------------------------------

    private fun drawArc(
        c: Canvas, n: Int, left: Float, right: Float, top: Float, bottom: Float,
        barH: Float, slotW: Float, cx: Float
    ) {
        val k = intensity
        val hw = min(dp(54f), slotW * 0.62f)
        val base = bottom - dp(1.4f)
        val peak = base - (base - (top + dp(7f))) * k
        val xa = cx - hw
        val xb = cx + hw
        val r = barH / 2f

        line.reset()
        line.moveTo(min(left + r * 0.6f, xa), base)
        line.lineTo(xa, base)
        line.cubicTo(cx - hw * 0.5f, base, cx - hw * 0.62f, peak, cx - hw * 0.2f, peak)
        line.lineTo(cx + hw * 0.2f, peak)
        line.cubicTo(cx + hw * 0.62f, peak, cx + hw * 0.5f, base, xb, base)
        line.lineTo(max(right - r * 0.6f, xb), base)

        hill.reset()
        hill.moveTo(xa, base)
        hill.cubicTo(cx - hw * 0.5f, base, cx - hw * 0.62f, peak, cx - hw * 0.2f, peak)
        hill.lineTo(cx + hw * 0.2f, peak)
        hill.cubicTo(cx + hw * 0.62f, peak, cx + hw * 0.5f, base, xb, base)
        hill.close()

        hillPaint.alpha = (255 * k).toInt()
        c.drawPath(hill, hillPaint)
        strokeGlow(c, line, dp(1.8f), 1f)

        for (i in 0 until n) {
            val cxi = left + (right - left) / n * (i + 0.5f)
            val act = (1f - abs(i - pos)).coerceIn(0f, 1f) * k
            val col = lerpColor(INACTIVE, Color.WHITE, act)
            val a = 0.72f + 0.28f * act
            val cy = top + dp(21f) - dp(3f) * act
            drawIcon(c, i, cxi, cy, dp(22f), col, a)
            textPaint.color = col
            textPaint.alpha = (255 * a).toInt()
            c.drawText(pages[i].label.take(11), cxi, top + dp(50f), textPaint)
        }
        // punto bajo el icono activo
        solid.color = withAlpha(GLOW, k)
        c.drawCircle(cx, top + dp(35.5f) - dp(3f) * k, dp(1.6f), solid)
    }

    // ---- Estilo 1: Haz de luz ------------------------------------------

    private fun drawBeam(
        c: Canvas, n: Int, top: Float, bottom: Float, barH: Float, slotW: Float, cx: Float
    ) {
        val k = intensity
        val bw = slotW * 0.92f
        val tw = slotW * 0.40f
        beam.reset()
        beam.moveTo(cx - tw / 2f, top)
        beam.lineTo(cx + tw / 2f, top)
        beam.lineTo(cx + bw / 2f, bottom)
        beam.lineTo(cx - bw / 2f, bottom)
        beam.close()

        c.save()
        c.clipPath(bar)
        beamPaint.alpha = (255 * k).toInt()
        c.drawPath(beam, beamPaint)
        // tapa luminosa en el borde superior
        val capW = slotW * 0.44f
        val capH = dp(3.4f)
        solid.color = withAlpha(GLOW, 0.10f * k)
        rect.set(cx - capW * 0.8f, top - dp(3f), cx + capW * 0.8f, top + capH + dp(5f))
        c.drawRoundRect(rect, dp(6f), dp(6f), solid)
        solid.color = withAlpha(GLOW, 0.22f * k)
        rect.set(cx - capW * 0.65f, top - dp(2f), cx + capW * 0.65f, top + capH + dp(2.5f))
        c.drawRoundRect(rect, dp(5f), dp(5f), solid)
        solid.color = withAlpha(GLOW, k)
        rect.set(cx - capW / 2f, top - dp(2f), cx + capW / 2f, top + capH)
        c.drawRoundRect(rect, dp(2f), dp(2f), solid)
        c.restore()

        val cy = top + barH / 2f + dp(1f)
        for (i in 0 until n) {
            val cxi = dp(2f) + slotW * (i + 0.5f)
            val act = (1f - abs(i - pos)).coerceIn(0f, 1f) * k
            val col = lerpColor(INACTIVE, Color.WHITE, act)
            drawIcon(c, i, cxi, cy, dp(24f) * (1f + 0.12f * act), col, 0.66f + 0.34f * act)
        }
    }

    // ---- Estilo 2: Burbuja ---------------------------------------------

    private fun drawBubble(
        c: Canvas, n: Int, top: Float, barH: Float, slotW: Float, cx: Float, dip: Float, near: Int
    ) {
        val k = intensity
        val cy = top + barH / 2f
        val left = dp(2f)

        // iconos de la barra: el de la pestaña activa se desvanece al llegar la burbuja
        for (i in 0 until n) {
            val cxi = left + slotW * (i + 0.5f)
            val d = abs(i - pos)
            val vis = 1f - (1f - (d * 1.6f).coerceIn(0f, 1f)) * k
            drawIcon(c, i, cxi, cy + dp(2f), dp(23f), INACTIVE, 0.78f * vis)
        }

        if (k <= 0.02f) return
        val r = dp(22f) * (1f - 0.08f * sin(abs(pos - pos.roundToInt()) * Math.PI.toFloat()))
        val by = top - dp(8f) + dip

        solid.color = withAlpha(GLOW, 0.10f * k)
        c.drawCircle(cx, by, r + dp(7f), solid)
        solid.color = withAlpha(GLOW, 0.18f * k)
        c.drawCircle(cx, by, r + dp(3.5f), solid)
        solid.color = withAlpha(0xFF14463B.toInt(), 0.94f * k)
        c.drawCircle(cx, by, r, solid)
        solid.color = withAlpha(0xFF3FB59C.toInt(), 0.30f * k)
        c.drawCircle(cx - r * 0.18f, by - r * 0.22f, r * 0.68f, solid)
        edgeCircle(c, cx, by, r, k)
        drawIcon(c, near, cx, by, dp(22f), Color.WHITE, k)
    }

    private fun edgeCircle(c: Canvas, cx: Float, cy: Float, r: Float, k: Float) {
        glowStroke.strokeWidth = dp(1.5f)
        glowStroke.alpha = (210 * k).toInt()
        c.drawCircle(cx, cy, r, glowStroke)
    }
}
