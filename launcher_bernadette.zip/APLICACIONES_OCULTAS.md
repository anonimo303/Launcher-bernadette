# VERDANT Launcher — Aplicaciones ocultas

## Funcionalidad añadida
- Mantener presionada una aplicación en el cajón muestra la acción **Ocultar aplicación**. Se conservan las acciones existentes: añadir a Inicio, información y desinstalar.
- Las aplicaciones ocultas dejan de aparecer en el cajón y en sus resultados de búsqueda. No se desinstalan ni se deshabilitan en Android.
- Mantener presionada una zona vacía de Inicio y elegir **Ver aplicaciones ocultas** abre el listado privado.
- Desde ese listado se puede abrir una aplicación o volver a mostrarla en el cajón.
- En Configuración del launcher → Aplicaciones ocultas se pueden seleccionar varias aplicaciones para ocultar/mostrar y activar o desactivar la protección con PIN.
- El PIN es numérico de 4 a 8 dígitos; se solicita dos veces al configurarlo y se almacena como hash SHA-256 en preferencias privadas de la app.
- Si la protección está desactivada, el listado se abre directamente sin pedir PIN.

## Alcance
El cambio afecta al cajón de VERDANT y al menú de Inicio. No modifica el comportamiento de Android, no bloquea las aplicaciones y no cifra los datos de otras aplicaciones.
