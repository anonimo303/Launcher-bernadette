# MAHORAGA GAMES dentro de VERDANT — resumen de cambios

## Archivos NUEVOS (todo el módulo, paquete `com.personal.launcher.mahoraga`)
- MahoragaActivity.kt — app principal (biblioteca, JUGAR / VER DETALLES / ADAPTACIÓN, permisos, diagnóstico del equipo, historial, configuración)
- Mh.kt, Sys.kt, Store.kt, Brain.kt — utilidades, lecturas reales, informes, análisis/adaptación
- MonitorService.kt — servicio ligero (diagnóstico de ~3,5 min y vigilancia en partida)
- EdgePanel.kt — pestaña lateral + panel gamer flotante (diseño de la imagen 3)
- MahoragaNotice.kt — notificación especial con la rueda dorada (independiente de NotifOverlay)
- Recorder.kt, MahoragaAccess.kt — grabación (MediaProjection) y captura (Accesibilidad)
- res: mh_icon.png (personaje, icono), mh_wheel.png (rueda, solo notificación), iconos vectoriales mh_ic_*, mipmap mh_launcher, estilos/strings mh_*

## Cambios MÍNIMOS en archivos existentes
- Data.kt (AppRepo.load): el launcher seguía omitiendo todo su paquete; ahora solo omite MainActivity, y MAHORAGA entra al cajón sin que un icon pack le cambie el icono.
- MainActivity.kt: (1) showAppMenu: para MAHORAGA no ofrece «Desinstalar»; (2) launch(): 1 línea que arranca la vigilancia si abres un juego de la biblioteca.
- AndroidManifest.xml: permisos nuevos, MahoragaActivity (LAUNCHER), servicios y accesibilidad.
No se tocaron: inicio, navegación, gestos, Recursos, ajustes, fondos, NotifOverlay/NotifService ni Prefs.

## v1.1 — Configuración con Shizuku (opcional)
- Nuevo: Shz.kt + pantalla «Configuración con Shizuku» (MAHORAGA → Configuración).
- Con Shizuku: CPU y FPS reales (SurfaceFlinger, mejor esfuerzo), temperatura de piel, modo de juego de Android (rendimiento, reversible) y «am kill-all» opcional al entrar al juego, con RAM medida antes/después.
- app/build.gradle: dependencias dev.rikka.shizuku:api y provider 13.1.5 (necesitan red al compilar). AndroidManifest: ShizukuProvider.

## v1.2 — Burbuja
- Círculos del monitor (CPU/RAM/Temp./Bat.): ahora son círculos perfectos y los textos quedan centrados dentro.
- Configuración → «Burbuja flotante por app»: interruptor «No poner burbuja flotante» por cada app de la biblioteca (la adaptación sigue funcionando).
- Configuración → «Apps en la burbuja»: eliges qué apps aparecen como accesos en el panel (ventana pequeña). Por defecto YouTube, TikTok y Kick.
