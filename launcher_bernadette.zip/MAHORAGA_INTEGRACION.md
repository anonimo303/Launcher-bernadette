# MAHORAGA GAMES dentro de VERDANT — resumen de cambios

## Archivos NUEVOS (todo el módulo, paquete `com.personal.launcher.mahoraga`)
- MahoragaActivity.kt — app principal (biblioteca, JUGAR / VER DETALLES / ADAPTACIÓN, permisos, diagnóstico del equipo, historial, configuración)
- Mh.kt, Sys.kt, Store.kt, Brain.kt — utilidades, lecturas reales, informes, análisis/adaptación
- MonitorService.kt — servicio ligero (diagnóstico de ~3,5 min y vigilancia en partida)
- EdgePanel.kt — pestaña lateral + panel gamer flotante (diseño de la imagen 3)
- MahoragaNotice.kt — notificación especial con la rueda dorada (independiente de NotifOverlay)
- Recorder.kt, MahoragaAccess.kt — grabación (MediaProjection) y captura (Accesibilidad)
- res: mh_icon.png (personaje, icono), mh_wheel.png (rueda, solo notificación), iconos vectoriales mh_ic_*, mipmap mh_launcher, estilos/strings mh_*

## Cambios MÍNIMOS en archivos existentes
- Data.kt (AppRepo.load): el launcher seguía omitiendo todo su paquete; ahora solo omite MainActivity, y MAHORAGA entra al cajón sin que un icon pack le cambie el icono.
- MainActivity.kt: (1) showAppMenu: para MAHORAGA no ofrece «Desinstalar»; (2) launch(): 1 línea que arranca la vigilancia si abres un juego de la biblioteca.
- AndroidManifest.xml: permisos nuevos, MahoragaActivity (LAUNCHER), servicios y accesibilidad.
No se tocaron: inicio, navegación, gestos, Recursos, ajustes, fondos, NotifOverlay/NotifService ni Prefs.

## v1.1 — Configuración con Shizuku (opcional)
- Nuevo: Shz.kt + pantalla «Configuración con Shizuku» (MAHORAGA → Configuración).
- Con Shizuku: CPU y FPS reales (SurfaceFlinger, mejor esfuerzo), temperatura de piel, modo de juego de Android (rendimiento, reversible) y «am kill-all» opcional al entrar al juego, con RAM medida antes/después.
- app/build.gradle: dependencias dev.rikka.shizuku:api y provider 13.1.5 (necesitan red al compilar). AndroidManifest: ShizukuProvider.

## v1.2 — Burbuja
- Círculos del monitor (CPU/RAM/Temp./Bat.): ahora son círculos perfectos y los textos quedan centrados dentro.
- Configuración → «Burbuja flotante por app»: interruptor «No poner burbuja flotante» por cada app de la biblioteca (la adaptación sigue funcionando).
- Configuración → «Apps en la burbuja»: eliges qué apps aparecen como accesos en el panel (ventana pequeña). Por defecto YouTube, TikTok y Kick.

## v1.3 — Automático (solo desde MAHORAGA)
- El servicio de vigilancia ya NO se enciende al abrir apps desde el cajón de VERDANT ni por abrir el launcher: solo cuando pulsas JUGAR dentro de MAHORAGA. Fuera de eso está apagado (sin gasto de batería) y no muestra avisos.
- Diagnóstico automático: al abrir una app con JUGAR desde MAHORAGA y sin informe previo, empieza solo el diagnóstico (con aviso). Si la abres fuera de MAHORAGA no pasa nada.
- Optimización automática: al terminar el diagnóstico aplica los ajustes autorizados (Brain.apply) y muestra la notificación dorada con lo aplicado.
- JUGAR lleva a Permisos (una vez) si falta el Acceso de uso. Nuevo permiso «Sin restricciones de batería» (REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).
- Con Shizuku: botón «Conceder permisos automáticamente» (uso, superposición, notificaciones, No molestar, batería) solo para MAHORAGA.
- Dos interruptores en Configuración: «Diagnóstico automático» y «Optimización automática» (activados por defecto).

## v1.4 — Apps protegidas y RAM
- Configuración → «Apps protegidas»: MAHORAGA nunca toca esas apps (por defecto HTTP Custom). Al liberar memoria ya no se usa «am kill-all» general: se cierra app por app (am kill, solo segundo plano) saltando juego, MAHORAGA, Shizuku y las protegidas.
- Con Shizuku, el informe añade «Mayores consumidores de RAM ahora» (dumpsys meminfo). Solo informa.

## v1.5 — Preparar el sistema para jugar (ahora ACTÚA, ya no solo recomienda)
- Nuevo: `Boost.kt`. Al pulsar JUGAR, antes de abrir el juego, aparece «Preparando el equipo…» y MAHORAGA:
  1. **Mira** el sistema con Shizuku: CPU por app (`dumpsys cpuinfo`), RAM por app (`dumpsys meminfo`) y apps con servicio en primer plano (`dumpsys activity services`).
  2. **Actúa** solo sobre apps instaladas que consumen y no usas: las cierra (`am force-stop`, o `am kill` en nivel Suave), limpia su caché (`pm clear --cache-only`, con `pm trim-caches` como respaldo) y frena su segundo plano (`appops RUN_ANY_IN_BACKGROUND ignore`).
  3. **Mide** la RAM libre antes y después y lo deja en el informe y en Configuración («Última preparación»).
- Opcional: «Congelar apps pesadas mientras juego» (`pm suspend`, o `pm disable-user` si no se puede suspender).
- Todo lo frenado/congelado se **restaura solo** 90 s después de salir del juego, al parar el servicio, al abrir MAHORAGA o con «Restaurar todo ahora». Si Shizuku no está disponible en ese momento, queda pendiente. Solo se hacen cambios reversibles si hay Acceso de uso (para saber cuándo dejas de jugar).
- **Nunca toca**: el juego, MAHORAGA/VERDANT, Shizuku, apps protegidas y de la burbuja, launcher, teclado, accesibilidad, oyentes de notificaciones, VPN, marcador/SMS predeterminados, apps con servicio en primer plano y apps del sistema. Si una app ya estaba restringida por el usuario, no se modifica.
- **Se adapta**: tres intensidades (Suave/Normal/A fondo). Si tras limpiar la RAM libre sigue < 15 %, la próxima vez de ese juego sube de nivel; si el diagnóstico detecta poca memoria o CPU alta, empieza al menos en Normal. Las apps que reaparecen 3 o más veces quedan siempre con el segundo plano frenado.
- Sin Shizuku: solo `killBackgroundProcesses` (permiso nuevo `KILL_BACKGROUND_PROCESSES`); Android decide qué se cierra. El informe lo dice.
- Cambios: `Brain` (la recomendación «hazlo tú desde Recientes» se sustituye por la acción real), `MonitorService` (restauración y no repetir si ya se preparó), `Shz` (`exec` ahora respeta el tiempo máximo; `cleanMemory` delega en Boost), `MahoragaActivity` (diálogo previo + sección «Preparar el sistema para jugar»), `AndroidManifest` (permiso).
- No verificado en un dispositivo real: el código compila contra stubs y el script de shell se probó con comandos simulados, pero `pm clear --cache-only`, `pm suspend` y `appops` dependen de la versión de Android/fabricante; si alguno falla, el informe lo indica y sigue con lo demás.

## v1.5.1 — Burbuja clara, aviso de inicio y lectura más robusta
- **Burbuja por app en positivo**: el interruptor ahora dice «Mostrar burbuja flotante» (encendido = se muestra). Antes decía «No poner burbuja» y se leía al revés. Al actualizar se conserva la posición que veías (lo que estaba encendido sigue encendido). Cada app es independiente; solo «Panel flotante en los juegos» apaga todas, y Configuración lo avisa si está apagado.
- **Aviso de inicio con la rueda dorada**: al empezar el diagnóstico sale «COMENZANDO EL PROCESO DE ADAPTACIÓN» con la misma animación que «MAHORAGA SE HA ADAPTADO» (si no hay permiso de superposición, notificación normal). `MahoragaNotice.show` acepta título y subtítulo.
- **Lectura del sistema**: cuatro lecturas independientes (cpuinfo, meminfo, ps como respaldo de RAM, servicios activos). Si no se puede leer, el informe indica el motivo. Si falla solo la lectura de servicios activos, solo se actúa sobre las apps más pesadas.

## v1.5.2 — Ventanas pequeñas sin Opciones del desarrollador
- Nuevo `Freeform.kt`: con Shizuku escribe los mismos ajustes que «Activar ventanas de formato libre», «Forzar que se pueda cambiar el tamaño de las actividades» y «…imposibilidad de cambiar de tamaño en una ventana múltiple». Guarda los valores anteriores y se puede desactivar.
- Se activa desde Configuración con Shizuku → «Ventanas pequeñas», o solo al tocar una app de la burbuja si el teléfono aún no las admite.
- Sin verificar en dispositivo: algunos sistemas solo aplican el cambio tras reiniciar una vez; si se apagan las Opciones del desarrollador desde Ajustes, Android puede volver a ponerlas a cero.
