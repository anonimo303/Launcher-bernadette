# VERDANT Launcher — ajustes de MAHORAGA y gestos

Este ZIP contiene el proyecto Android fuente completo para importarlo en HipHop y generar/actualizar el APK. No es un APK.

## Cambios aplicados

### Panel flotante de MAHORAGA
- Se retiraron del panel los accesos predeterminados YouTube, TikTok y Kick.
- Se retiraron los botones Captura y Grabar.
- Se conserva el monitor superior (CPU, RAM, temperatura, batería, voltaje/FPS y estado térmico), la cabecera, el engranaje, Modo Gamer y Control térmico.
- El único acceso rápido que queda es No molestar, a ancho completo.
- Se quitó de la pantalla de configuración la sección de accesos rápidos predeterminados para que no se vuelvan a mostrar en el panel.

### No molestar por aplicación
- En MAHORAGA → Biblioteca de juegos → seleccionar aplicación → ADAPTACIÓN aparece «Mostrar No molestar en el panel».
- La preferencia se guarda por paquete, de modo que puede estar visible en un juego y ocultarse en otro.
- La activación automática de No molestar al iniciar la partida respeta esa preferencia por aplicación.
- El valor inicial es activado para conservar el comportamiento anterior; se puede apagar individualmente.

### Doble toque en VERDANT
- En Configuración → Gestos se añadió «Doble toque para abrir una aplicación».
- Permite elegir cualquier aplicación instalada que tenga una actividad de inicio, o «Ninguna aplicación» para desactivarlo.
- El doble toque se detecta en una zona vacía de Inicio y abre la aplicación elegida. No intercepta los iconos para evitar conflictos con su apertura y movimiento.

## Alcance
Se editaron únicamente `EdgePanel.kt`, `MahoragaActivity.kt`, `MonitorService.kt`, `SettingsActivity.kt` y `MainActivity.kt`, además de este documento. Se conservaron el monitor y las demás funciones de MAHORAGA.

## Conversión
Importa el ZIP en HipHop como proyecto Android y deja que HipHop sincronice/compile el proyecto. No se incluye APK. En este entorno no está disponible Gradle para verificar una compilación; se comprobó la integridad del ZIP.
