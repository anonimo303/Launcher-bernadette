# VERDANT Launcher — cambios del módulo Clima

Este ZIP contiene el proyecto Android fuente completo para abrirlo en HipHop y generar/actualizar el APK allí. No es un APK.

## Archivos tocados
- `app/src/main/java/com/personal/launcher/MainActivity.kt`: límites del paginador horizontal, sin overscroll, y restricción direccional para que desde Inicio el gesto hacia la derecha pueda volver a Clima cuando Clima está inmediatamente antes de Inicio. Se conserva el criterio horizontal (el desplazamiento vertical no inicia el paginador).
- `app/src/main/java/com/personal/launcher/weather/WeatherPanel.kt`: clipping del panel y `OVER_SCROLL_NEVER`; las listas internas también desactivan overscroll.
- `app/src/main/java/com/personal/launcher/weather/WxSphere.kt`: superficie planetaria procedural equirectangular de 512×256, desplazamiento longitudinal ligado al giro, sombreado esférico, atmósfera, reflejos y anillos orbitales. Nubes, lluvia, nieve, niebla, sol y relámpagos se eligen a partir de `WxKind` recibido por el modelo meteorológico.
- `app/src/main/java/com/personal/launcher/weather/WxArt.kt`: capas de luces y sombras para las nubes, deriva suave y animación de precipitación; el runnable se elimina al separarse la vista.

## Datos meteorológicos
Los datos siguen obteniéndose desde la implementación existente de Open-Meteo (`WeatherApi.kt`) y el mapeo existente a `WxKind`. No se fabrican observaciones ni valores meteorológicos para activar efectos.

## Rendimiento y ciclo de vida
- La esfera se actualiza desde el reloj único de `WeatherPanel`; `start()`/`stop()` controlan el reloj al entrar/salir del módulo.
- La textura planetaria se genera una vez por instancia de la vista y se reutiliza mediante `BitmapShader`.
- Se conservan límites de partículas y niveles de calidad ya presentes; el modo ahorro y dispositivos de baja RAM reducen efectos.
- Los iconos animados retiran sus callbacks en `onDetachedFromWindow()` y ralentizan la actualización cuando no están visibles.

## Alcance y limitación visual
La esfera es una ilustración 2.5D en Canvas con textura procedural (continentes aproximados), sombreado, capas atmosféricas y rotación aparente. No es una malla 3D física, no usa datos satelitales ni fotografías de la Tierra. Los iconos y efectos son ilustraciones animadas, no simulaciones físicas de nubes o lluvia.

No se modificaron intencionalmente las pantallas Inicio, Aplicaciones, Recursos, la barra de navegación ni los ajustes, fuera del paginador necesario para la navegación horizontal.

## Conversión
Abrir/importar este ZIP en HipHop como proyecto Android y dejar que HipHop sincronice/compile el proyecto. No se incluye APK ni se afirma que se haya compilado en este entorno.
