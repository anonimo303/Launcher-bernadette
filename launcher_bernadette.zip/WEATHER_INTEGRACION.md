# Sección Clima (VERDANT Weather) — resumen de cambios

## Archivos NUEVOS (`com.personal.launcher.weather`)
- WeatherPanel.kt — pantalla Clima: principal, detalle de día, pronóstico extendido y búsqueda de ubicación.
- WeatherModel.kt / WeatherApi.kt — modelo, textos en español y Open-Meteo (pronóstico + búsqueda de ciudades, sin clave). Caché y ubicación en archivos propios.
- WeatherBackground.kt, WxTheme.kt (cristal), WxArt.kt (iconos), WxSphere.kt (esfera 3D).
- res: iconos vectoriales wx_ic_* e ic_weather.

## Cambios MÍNIMOS en archivos existentes
- NavConfig.kt: `PageId.WEATHER` («Clima») y orden: Clima va antes de Inicio (también con ajustes guardados antes).
- NavBar.kt: mezcla de color azul/violeta que solo se activa cerca de la pestaña Clima (en las demás, idéntica a antes).
- MainActivity.kt: crea el panel, lo coloca en `pageView`, start/stop según visibilidad, atrás, insets.
- AndroidManifest.xml: permiso INTERNET.
No se tocaron Inicio, Aplicaciones, Recursos, Ajustes ni Prefs.
